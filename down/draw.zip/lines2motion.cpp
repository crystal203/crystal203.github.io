#include <windows.h>
#include <bits/stdc++.h>
#include <conio.h>
using namespace std;
#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
signed main(){
	while (1){
		printf("1.AA72 2&0.Hana 3.Priscilla 4.Erina 5.Yuze 6.Mayreel 7.Mk99 8.Lilith\n");
		printf("Press F2 to start!\n");
		while (!press(VK_F2));
		while (1){
			if (press('1')){freopen("res1.txt","r",stdin);break;}
			else if (press('2')){freopen("res2.txt","r",stdin);break;}
			else if (press('3')){freopen("res3.txt","r",stdin);break;}
			else if (press('4')){freopen("res4.txt","r",stdin);break;}	
			else if (press('5')){freopen("res5.txt","r",stdin);break;}
			else if (press('6')){freopen("res6.txt","r",stdin);break;}	
			else if (press('7')){freopen("res7.txt","r",stdin);break;}
			else if (press('8')){freopen("res8.txt","r",stdin);break;}	
			else if (press('9')){freopen("res9.txt","r",stdin);break;}	
			else if (press('0')){freopen("res0.txt","r",stdin);break;}	
		}
		printf("READY!!!\n");
		int n,a,b,c,d;
		scanf("%d",&n);
		Sleep(2000);
		//int width=GetSystemMetrics(SM_CXSCREEN);
		//int height=GetSystemMetrics(SM_CYSCREEN);
		int height=1280,width=1920;
		for (int i=1;i<=n;++i){
			scanf("%d %d %d %d",&a,&b,&c,&d);
			a=a/2+1051;b=b/2+316;
			c=c/2+1051;d=d/2+316;
			a=a*65536.0/width;
			b=b*65536.0/height;
			c=c*65536.0/width;
			d=d*65536.0/height;
			if (press('D')) Sleep(5);
			else Sleep(45);
			mouse_event(MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_MOVE,a,b,0,0);
			mouse_event(MOUSEEVENTF_LEFTDOWN,0,0,0,0);
			mouse_event(MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_MOVE,c,d,0,0);
			mouse_event(MOUSEEVENTF_LEFTUP,0,0,0,0);
		}
		fclose(stdin);
		Sleep(5000);
		system("pause");
	}
}