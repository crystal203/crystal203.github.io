#include <bits/stdc++.h>
using namespace std;
#include <easyx.h>
#include <winsock2.h>
#include "console4.h"
struct MKMsg{
	int x,y,type;
	short val;
	MKMsg(int _x=0,int _y=0,int _type=0,short _val=0){
		x=_x;y=_y;type=_type;val=_val;
	}
};
class Server{
	#define DEBUG 2
	#define MSG_LEN 200
	WSAData wsa;
	SOCKET soc;
	int port;
	string ip;
	string version="v1.0";
	bool init(){
		tellraw("&f��Ļ�������� �����&b"+version+"\n");
		tellraw("&a������...\n");
		tellraw("&f���ڼ������绷��...");
		if (WSAStartup(MAKEWORD(2,2),&wsa)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f���ڴ����׽���...");
		soc=socket(AF_INET,SOCK_STREAM,0);
		if (soc==INVALID_SOCKET){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		if (DEBUG==1) port=7999,ip="127.0.0.1";
		else if (DEBUG==2) port=7999,ip="192.168.137.1";
		else{
			tellraw("&f������������� ip ��ַ��");setColor(0xb); 
			cin>>ip;
			tellraw("&f������������˶˿ڣ�");setColor(0xb);
			cin>>port;			
		}
		sockaddr_in addr;
		addr.sin_family=AF_INET;
		addr.sin_port=htons(port);
		addr.sin_addr.s_addr=inet_addr(ip.c_str());
		int len=sizeof(sockaddr_in);
		tellraw("&f���ڰ󶨷����� ip ���˿�...");
		if (bind(soc,(SOCKADDR*)&addr,len)==SOCKET_ERROR){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f�������ü���״̬...");
		if (listen(soc,5)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		return 1;
	}
	void checkError(int r){
		if (r==SOCKET_ERROR || r==0){
			tellraw("&c�շ���Ϣʱ������");
			getch();
			exit(0);
		}
	}
	vector <string> solve(string s){
		string tmp="";
		vector <string> v;
		if (s[0]!='$'){
			v.push_back(s);
			return v;
		}
		for (int i=1;i<(int)s.size();++i){
			if (s[i]=='$'){
				v.push_back(tmp);tmp="";
			}else{
				tmp=tmp+s[i];
			}
		}
		return v;
	}
	char sbuf[64];
	#define bag_size 1024
	char pbuf[bag_size];
	void transImage(SOCKET c,SOCKET d){
		int r=recv(d,sbuf,64,0);
		checkError(r);
		r=send(c,sbuf,64,0);
		checkError(r);
		int size=stoi(string(sbuf)),cnt=0;
		while (1){
			int nb=recv(d,pbuf,bag_size,0);
			checkError(nb);
			cnt+=nb;
			nb=send(c,pbuf,nb,0);
			checkError(nb);
			if (cnt>=size) break;
		}
	}
	map <int,SOCKET> wait;
	char tbuf[64];
	char cbuf[64];
	vector <string> v;
	void work(SOCKET c){
		srand((unsigned)time(NULL));
		int r=recv(c,tbuf,64,0);
		if (r!=INVALID_SOCKET){
			if (string(tbuf)=="1"){
				int rid=0;
				do{
					rid=rand()%9000+1000;
				}while (wait.count(rid));
				wait[rid]=c;
				send(c,to_string(rid).c_str(),64,0);
				while (wait.count(rid)){
					Sleep(1000);
				}
			}else if (string(tbuf)=="2"){
				int rid;
				while (1){
					recv(c,tbuf,64,0);
					rid=stoi(string(tbuf));
					if (!wait.count(rid)){
						send(c,"fail",64,0);
					}else{
						send(c,"succ",64,0);
						break;
					}
				}
				SOCKET d=wait[rid];
				wait.erase(rid);
				swap(c,d);
				while (1){
					int r=recv(c,cbuf,64,0);
					send(d,cbuf,64,0);
					v=solve(string(cbuf));
					if (v[0]=="require"){
						transImage(c,d);
					}
				}		
			} 
		}
	}
public:
	vector <thread*> threadPool; 
	void run(){
		if (!init()){
			tellraw("&c����������ʱ�������⣡\n");
		}else{
			tellraw("&a�����������ɹ���\n");			
			sockaddr_in caddr;
			int len=sizeof(caddr);
			while (1){
				SOCKET c=accept(soc,(sockaddr*)&caddr,&len);
				if (c==INVALID_SOCKET){
					tellraw("&r����ʧ�ܣ�\n");
				}else{
					thread* tmp=new thread(&Server::work,this,c);
					threadPool.push_back(tmp);
					tmp->detach();
				}
			}
		}
		closesocket(soc);
		WSACleanup();
	}
}server;
int main(){
	server.run();
	while (1);
}

