#include <bits/stdc++.h>
#include <windows.h>
#include <gdiplus.h> 
#include <tchar.h>
#include "console4.h"
#include <winsock2.h>
#include <string.h>
using namespace std; 
class ScreenShot{
	int iScreenWidth,iScreenHeight;
	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	RECT rc;
	ULONG_PTR gdiplusToken;
	HDC hCurrScreen,hCmpDC;
	LPCWSTR s2l(string str){
		int len=str.length();
		int lenbf=MultiByteToWideChar(CP_ACP,0,str.c_str(),len,0,0);
		wchar_t* buffer=new wchar_t[lenbf];
		MultiByteToWideChar(CP_ACP,0,str.c_str(),len,buffer,sizeof(wchar_t)*lenbf);
		buffer[len]=0;
		return buffer;
	}
	int GetEncoderClsid(const WCHAR* format,CLSID* pClsid){
	    UINT num=0;
	    UINT size=0;
	    Gdiplus::GetImageEncodersSize(&num,&size);
	    if (size==0) return -1;
		Gdiplus::ImageCodecInfo* pImageCodecInfo=(Gdiplus::ImageCodecInfo*)(malloc(size));
	    if (pImageCodecInfo==NULL) return -1;
	    GetImageEncoders(num,size,pImageCodecInfo);
	    for (UINT j=0;j<num;++j){
	        if (wcscmp(pImageCodecInfo[j].MimeType, format)==0){
	            *pClsid=pImageCodecInfo[j].Clsid;
	            free(pImageCodecInfo);
	            return j;
	        }
	    }
	    free(pImageCodecInfo);
	    return -1;  
	}
public:
	ScreenShot(double rate=1.5){
	    Gdiplus::GdiplusStartup(&gdiplusToken,&gdiplusStartupInput,NULL);
	    GetClientRect(GetDesktopWindow(),&rc);
	  	hCurrScreen=GetDC(NULL);
	  	hCmpDC=CreateCompatibleDC(hCurrScreen);
	  	iScreenWidth=GetDeviceCaps(hCurrScreen,HORZRES)*1.25;
	  	iScreenHeight=GetDeviceCaps(hCurrScreen,VERTRES)*1.25;
	}
	~ScreenShot(){
		Gdiplus::GdiplusShutdown(gdiplusToken);
	}
	void takeShot(string fileName,POINT a,POINT b){
	    int w=b.x-a.x;
	    int h=b.y-a.y;
	    if (w<=0 || h<=0) return;
	    HDC hScreen=GetDC(HWND_DESKTOP);
	    HDC hDc=CreateCompatibleDC(hScreen);
	    HBITMAP hBitmap=CreateCompatibleBitmap(hScreen,w, h);
	    HGDIOBJ old_obj=SelectObject(hDc,hBitmap);
	    BitBlt(hDc,0,0,w,h,hScreen,a.x,a.y,SRCCOPY);
	    Gdiplus::Bitmap bitmap(hBitmap,NULL);
	    CLSID clsid;
	    GetEncoderClsid(L"image/jpeg",&clsid);
	    Gdiplus::EncoderParameters ep;
	    ep.Count=1;ep.Parameter[0].Guid=Gdiplus::EncoderQuality;
	    ep.Parameter[0].Type=Gdiplus::EncoderParameterValueTypeLong;
	    ep.Parameter[0].NumberOfValues=1;
	    int quality=25;
	    ep.Parameter[0].Value=&quality;
	    bitmap.Save(s2l(fileName),&clsid,&ep);
	    SelectObject(hDc,old_obj);
	    DeleteDC(hDc);
	    ReleaseDC(HWND_DESKTOP, hScreen);
	    DeleteObject(hBitmap);
	}
	void takeShot(string fileName){
		takeShot(fileName,{0,0},{iScreenWidth,iScreenHeight});
	}
};
class Client2{
	#define DEBUG 2
	string version="v1.0";
	WSAData wsa;
	SOCKET soc;
	int port;
	string ip;
	ScreenShot ss;
	bool init(){
		tellraw("&f��Ļ�������� &b"+version+"\n");
		tellraw("&a������...\n");
		tellraw("&f���ڼ������绷��...");
		if (WSAStartup(MAKEWORD(2,2),&wsa)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f���ڴ����׽���...");
		soc=socket(AF_INET,SOCK_STREAM,0);
		if (soc==INVALID_SOCKET){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		if (DEBUG==1) port=7999,ip="127.0.0.1";
		else if (DEBUG==2) port=7999,ip="122.51.81.168";
		else{
			tellraw("&f���������� ip ��ַ��");setColor(0xb); 
			cin>>ip;
			tellraw("&f���������˶˿ڣ�");setColor(0xb);
			cin>>port;
			string trush;getline(cin,trush);
		}
		sockaddr_in addr;
		addr.sin_family=AF_INET;
		addr.sin_port=htons(port);
		addr.sin_addr.s_addr=inet_addr(ip.c_str());
		int len=sizeof(sockaddr_in);
		tellraw("&f�������ӷ���� ip ���˿�...");
		if (connect(soc,(SOCKADDR*)&addr,len)==SOCKET_ERROR){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		return 1;
	}
	#define bag_size 1024
	char pbuf[bag_size];
	void checkError(int r){
		if (r==SOCKET_ERROR || r==0){
			tellraw("&c�շ���Ϣʱ������");
			getch();
			exit(0);
		}
	}
	void sendImage(string fileName){
		FILE *pic;
		pic=fopen(fileName.c_str(),"rb");
		fseek(pic,0,SEEK_END);
		int size=ftell(pic);
		fclose(pic);
		pic=fopen(fileName.c_str(),"rb");
		int r=send(soc,to_string(size).c_str(),64,0);
		checkError(r);
		int nb=fread(pbuf,1,sizeof(pbuf),pic);
		while (nb!=0){
			int r=send(soc,pbuf,nb,0);
			checkError(r);
			nb=fread(pbuf,1,sizeof(pbuf),pic);
		}
		fclose(pic);
	}
	vector <string> solve(string s){
		string tmp="";
		vector <string> v;
		if (s.size()==0 || s[0]!='$'){
			v.push_back(s);
			return v;
		}
		for (int i=1;i<(int)s.size();++i){
			if (s[i]=='$'){
				v.push_back(tmp);tmp="";
			}else{
				tmp=tmp+s[i];
			}
		}
		return v;
	}
public:
	vector <string> v;
	void run(){
		if (!init()){
			tellraw("&c�����ͻ���ʱ�������⣡\n");
			return;
		}else{
			tellraw("&a�����ͻ��˳ɹ���\n");
			send(soc,"2",64,0);
			while (1){
				tellraw("&f����������ƶ���ͬ�� id��");
				int id;cin>>id;
				send(soc,to_string(id).c_str(),64,0);
				char tbuf[64];
				recv(soc,tbuf,64,0);
				if (string(tbuf)=="succ") break;
				tellraw("&cδ�ҵ���Ӧ id\n");
			}
			char buf[128];
			while (1){
				int r=recv(soc,buf,64,0);
				checkError(r);
				v=solve(string(buf));
				if (v[0]=="require"){
					ss.takeShot("sc.jpeg");
					sendImage("sc.jpeg");
				}else if (v[0]=="move"){
					int x=stoi(v[1])*65536/1920,y=stoi(v[2])*65536/1280;
					mouse_event(MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_MOVE,x,y,0,0);
				}else if (v[0]=="mouse"){
					int x=stoi(v[1])*65536/1920,y=stoi(v[2])*65536/1280,val=stoi(v[4]);
					mouse_event(MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_MOVE,x,y,0,0);
					switch (stoi(v[3])){
						case 1:{
							mouse_event(MOUSEEVENTF_LEFTUP,0,0,0,0);
							break;
						}
						case 2:{
							mouse_event(MOUSEEVENTF_LEFTDOWN,0,0,0,0);
							break;
						}
						case 3:{
							mouse_event(MOUSEEVENTF_RIGHTUP,0,0,0,0);
							break;
						}
						case 4:{
							mouse_event(MOUSEEVENTF_RIGHTDOWN,0,0,0,0);
							break;
						}
						case 5:{
							mouse_event(MOUSEEVENTF_MIDDLEUP,0,0,0,0);
							break;
						}
						case 6:{
							mouse_event(MOUSEEVENTF_MIDDLEDOWN,0,0,0,0);
							break;
						}
						case 7:{
							mouse_event(MOUSEEVENTF_WHEEL,0,0,val,0);
							break;
						}
						case 8:{
							keybd_event(val,0,KEYEVENTF_KEYUP,0);  
							break;
						}
						case 9:{
							keybd_event(val,0,0,0); 
							break;
						}
					}
				}
			}
		}
		getch();
	}
}client2;
int main(){
	client2.run();
}
