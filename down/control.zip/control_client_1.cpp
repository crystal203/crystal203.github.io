#include <bits/stdc++.h>
using namespace std;
#include <easyx.h>
#include <winsock2.h>
#include "console4.h"
struct MKMsg{
	int x,y,type;
	short val;
	MKMsg(int _x=0,int _y=0,int _type=0,short _val=0){
		x=_x;y=_y;type=_type;val=_val;
	}
};
class Client1{
	#define DEBUG 0
	#define MSG_LEN 200
	WSAData wsa;
	SOCKET soc;
	int port;
	string ip;
	string version="v1.0";
	bool init(){
		tellraw("&f��Ļ�������� ���ƶ�&b"+version+"\n");
		tellraw("&a������...\n");
		tellraw("&f���ڼ������绷��...");
		if (WSAStartup(MAKEWORD(2,2),&wsa)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f���ڴ����׽���...");
		soc=socket(AF_INET,SOCK_STREAM,0);
		if (soc==INVALID_SOCKET){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		if (DEBUG==1) port=7999,ip="127.0.0.1";
		else if (DEBUG==2) port=7999,ip="122.51.81.168";
		else{
			tellraw("&f���������� ip ��ַ��");setColor(0xb); 
			cin>>ip;
			tellraw("&f���������˶˿ڣ�");setColor(0xb);
			cin>>port;
			string trush;getline(cin,trush);
		}
		sockaddr_in addr;
		addr.sin_family=AF_INET;
		addr.sin_port=htons(port);
		addr.sin_addr.s_addr=inet_addr(ip.c_str());
		int len=sizeof(sockaddr_in);
		tellraw("&f�������ӷ���� ip ���˿�...");
		if (connect(soc,(SOCKADDR*)&addr,len)==SOCKET_ERROR){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		return 1;
	}
	#define bag_size 1024
	char pbuf[bag_size];
	void checkError(int r){
		if (r==SOCKET_ERROR || r==0){
			tellraw("&c�շ���Ϣʱ������");
			getch();
			exit(0);
		}
	}
	char sbuf[64];
	void recvImage(string fileName,SOCKET c){
		int r=recv(c,sbuf,64,0);
		int size=stoi(sbuf);
		FILE *img=fopen(fileName.c_str(),"wb");
		int cnt=0,st=clock();
		while (1){
			int nb=recv(c,pbuf,bag_size,0);
			checkError(nb);
			cnt+=nb;
			fwrite(pbuf,1,nb,img);
			if (cnt>=size) break;
		}
		fclose(img);
	}
public:
	#define DELAY 1000
	char idbuf[64];
	void run(){
		if (!init()){
			tellraw("&c�����ͻ���ʱ�������⣡\n");
			return;
		}else{
			tellraw("&a�����ͻ��˳ɹ���\n");
			SOCKET c=soc;
			send(c,"1",64,0);
			recv(c,idbuf,64,0);
			tellraw("&f��Ŀ��� id Ϊ &a"+string(idbuf)+"&f�����ڵȴ����ض˼���...\n");
			double rate=1.5;
			initgraph(1920/rate,1280/rate,EX_SHOWCONSOLE);
			queue <MKMsg> q;
			BeginBatchDraw();
			IMAGE img;
			int st=clock(),fps=0;
			while (1){
				int r=send(c,"$require$",64,0);
				checkError(r);
				recvImage("sc_tmp.jpeg",c);
				fps++;
				if (1.0*(clock()-st)/CLOCKS_PER_SEC>5.0){
					cerr<<"fps: "<<fps/5.0<<endl;
					fps=0;st=clock();
				}
				loadimage(&img,_T("sc_tmp.jpeg"),1920/rate,1280/rate);
				putimage(0,0,&img);
				FlushBatchDraw();
				ExMessage m;
				int xpos=-1,ypos=-1;
				while (peekmessage(&m,EX_MOUSE|EX_KEY)){
					switch (m.message){
						case WM_MOUSEMOVE:{
							xpos=m.x;ypos=m.y;
							break;
						}
						case WM_LBUTTONUP:{
							q.push(MKMsg(m.x,m.y,1));
							break;
						}
						case WM_LBUTTONDOWN:{
							q.push(MKMsg(m.x,m.y,2));
							break;
						}
						case WM_RBUTTONUP:{
							q.push(MKMsg(m.x,m.y,3));
							break;
						}
						case WM_RBUTTONDOWN:{
							q.push(MKMsg(m.x,m.y,4));
							break;
						}
						case WM_MBUTTONUP:{
							q.push(MKMsg(m.x,m.y,5));
							break;
						}
						case WM_MBUTTONDOWN:{
							q.push(MKMsg(m.x,m.y,6));
							break;
						}
						case WM_MOUSEWHEEL:{
							q.push(MKMsg(m.x,m.y,7,m.wheel));
							break;
						}
						case WM_KEYUP:{
							q.push(MKMsg(0,0,8,m.vkcode));
							break;
						}
						case WM_KEYDOWN:{
							q.push(MKMsg(0,0,9,m.vkcode));
							break;
						}
					}
				}
				while (!q.empty()){
					MKMsg cur=q.front();q.pop();
					r=send(c,("$command$"+to_string(int(cur.x*rate))+"$"+to_string(int(cur.y*rate))+"$"+to_string(cur.type)+"$"+to_string(cur.val)+"$").c_str(),64,0);
				}
				if (xpos!=-1) r=send(c,("$move$"+to_string(int(xpos*rate))+"$"+to_string(int(ypos*rate))+"$").c_str(),64,0);
			}
			EndBatchDraw();
		} 
		closesocket(soc);
		WSACleanup();
	}
}client1;
int main(){
	client1.run();
}

