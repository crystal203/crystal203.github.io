#pragma once
class MusicPlayer{
public:
	bool playBGM;
	bool playSE;
	MusicPlayer(){
		playBGM=playSE=1;
	}
	void playThread(string s){
		mciSendString(("play ./sound/"+s+".wav wait").c_str(),0,0,0);	
	}
	void play(string s){
		if (s=="bgm"){
			if (playBGM) mciSendString("play ./sound/bgm.mp3 repeat",0,0,0);		
		}else{
			if (!playSE) return;
			thread mp(&MusicPlayer::playThread,this,s);
			mp.detach();
		}
	}
	~MusicPlayer(){}
};
