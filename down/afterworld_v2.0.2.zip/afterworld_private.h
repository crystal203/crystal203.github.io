/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef AFTERWORLD_PRIVATE_H
#define AFTERWORLD_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"2.0.2.5"
#define VER_MAJOR	2
#define VER_MINOR	0
#define VER_RELEASE	2
#define VER_BUILD	5
#define COMPANY_NAME	""
#define FILE_VERSION	"2.0.2.5"
#define FILE_DESCRIPTION	"GuardianTales x MagicTower"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Adventure in AfterWorld Inc."
#define PRODUCT_VERSION	"2.0.2.5"

#endif /*AFTERWORLD_PRIVATE_H*/
