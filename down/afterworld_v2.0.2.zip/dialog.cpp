#include "game.h"
using namespace std;
void DialogText::showDialog(Game* game,string cur,int _character,int _emotion){
	visible=1;text=&cur;character=_character;emotion=_emotion;game->refresh();
}
void DialogText::hideDialog(Game* game){
	visible=0;game->refresh();
}
void DialogText::printDialog(Game* game){ // �Ի���ӡ
	game->mp.play("page");
	settextstyle(16*game->rate,0,game->font.c_str());
	settextcolor(BLACK);
	setbkmode(TRANSPARENT);
	int width=(int)(textwidth(text->c_str())/game->rate+15)/16*16-16;
	game->uiList.draw(character!=-1?0:4,400,160);
	for (int i=0;i<width/16;++i){
		game->uiList.draw(1,400,160+32+i*16);
	}
	game->drawText(400+16,160+16,*text);
	game->uiList.draw(2,400,160+32+width);
	if (character!=-1){	
		settextcolor(WHITE);
		game->drawText(372,88,characterName[character]);
		game->emotionList.draw(emotion,390+8,65+12);
		game->uiList.draw(3,390,65);
	}
}
