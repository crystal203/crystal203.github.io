#pragma once

#ifndef MAX
		// 多写点括号总没坏处
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif // !MAX

