#pragma once
#include <vector>
#include <string>
#include "shitCString.h"
#include "stdafx.h"
using namespace std;
enum GTYPE { // GItem Ԫ��������
	G_NULL, G_GROUP, G_CAMERA,
	G_LINE, G_CIRCLE, G_ELLIPSE, G_TEXT, G_RECT,
	G_PEN, G_FILL, G_FONT,
	G_CLRSCR
};
class G_Bin { // ����Ͱ�������ݴ���ƹ������޷���ʱ���ٵ�GDIԪ�ء��Ա����һ�����١�
public:
	vector <HPEN> G_BadHPen = {};
	vector <HBRUSH> G_BadHBrush = {};
	vector <HFONT> G_BadHFont = {};
	void G_ClearBad() {
		for (auto item : G_BadHPen) DeleteObject(item);
		for (auto item : G_BadHBrush) DeleteObject(item);
		for (auto item : G_BadHFont) DeleteObject(item);
		G_BadHPen.clear();
		G_BadHBrush.clear();
		G_BadHFont.clear();
	}
};
static G_Bin globalBin; // ȫ������Ͱ
class GItem {
public:
	GTYPE type = G_NULL; // ������
	int height = 0, width = 0, top = 0, left = 0; // �ߴ���Ϣ
	bool visible; // �Ƿ��ǿɼ��Ļ�ͼԪ��
	virtual void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {} // ����
	virtual void calcSize() { // ����ߴ�
		height = width = left = top = 0; visible = 0;
	}
	virtual void erase() { // ����
		delete this;
	}
	GItem() { type = G_NULL; calcSize(); }
	~GItem() {}
};
class G_Line :public GItem { // ֱ��
public:
	int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	void calcSize() {
		height = abs(y2 - y1); width = abs(x2 - x1); left = min(x1, x2); top = min(y1, y2);
	}
	G_Line(int x_1 = 0, int y_1 = 0, int x_2 = 0, int y_2 = 0) :x1(x_1), y1(y_1), x2(x_2), y2(y_2) {
		type = G_LINE; calcSize(); visible = 1;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		::MoveToEx(pad, (x1 + rx) * rate, (y1 + ry) * rate, NULL);
		LineTo(pad, (x2 + rx) * rate, (y2 + ry) * rate);
	}
};
class G_Ellipse :public GItem { // ��Բ
public:
	int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	void calcSize() {
		height = y2 - y1; width = x2 - x1; left = x1; top = y1;
	}
	G_Ellipse(int x_1 = 0, int y_1 = 0, int x_2 = 0, int y_2 = 0) :x1(x_1), y1(y_1), x2(x_2), y2(y_2) {
		type = G_ELLIPSE; calcSize(); visible = 1;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		Ellipse(pad, (x1 + rx) * rate, (y1 + ry) * rate, (x2 + rx) * rate, (y2 + ry) * rate);
	}
};
class G_Circle :public GItem { // Բ
public:
	int x = 0, y = 0, r = 0;
	void calcSize() {
		height = width = r * 2; left = x - r; top = y - r;
	}
	G_Circle(int x_0 = 0, int y_0 = 0, int r_0 = 0) :x(x_0), y(y_0), r(r_0) {
		type = G_CIRCLE; calcSize(); visible = 1;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		Ellipse(pad, (x - r + rx) * rate, (y - r + ry) * rate, (x + r + rx) * rate, (y + r + ry) * rate);
	}
};
class G_Rect :public GItem { // ����
public:
	int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
	void calcSize() {
		height = y2 - y1; width = x2 - x1; left = x1; top = y1;
	}
	G_Rect(int x_1 = 0, int y_1 = 0, int x_2 = 0, int y_2 = 0) :x1(x_1), y1(y_1), x2(x_2), y2(y_2) {
		type = G_RECT; calcSize(); visible = 1;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		Rectangle(pad, (x1 + rx) * rate, (y1 + ry) * rate, (x2 + rx) * rate, (y2 + ry) * rate);
	}
};
inline CSize GetTextSize(LPCTSTR lpszText) { // ��ȡ���ִ�С
	CDC memDC;
	memDC.CreateCompatibleDC(NULL);
	CSize textSize = memDC.GetTextExtent(lpszText);
	return textSize;
}
class G_Text :public GItem { // ����
public:
	string text = "";
	int x0 = 0, y0 = 0;
	void calcSize() {
		CSize size = GetTextSize(string2cstring(text));
		height = size.cy; width = size.cx; left = x0; top = y0;
	}
	G_Text(string _text = "", int x_0 = 0, int y_0 = 0) :text(_text), x0(x_0), y0(y_0) {
		type = G_TEXT; calcSize(); visible = 1;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		CString s0 = string2cstring(text);
		TextOutW(pad, (x0 + rx) * rate, (y0 + ry) * rate, s0.GetBuffer(0), s0.GetLength());
	}
};
class G_Pen :public GItem { // �޸Ļ���
public:
	int type = 0, width = 0;
	COLORREF col = RGB(0, 0, 0);
	G_Pen(int _type = PS_SOLID, int _width = 1, COLORREF _col = RGB(0, 0, 0)) :type(_type), width(_width), col(_col) {
		type = G_PEN; visible = 0;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		HPEN hpen_new = CreatePen(type, width, col);
		HPEN oldpen = (HPEN)SelectObject(pad, hpen_new);
		DeleteObject(oldpen);
		globalBin.G_BadHPen.push_back(hpen_new);
	}
};
class G_Fill :public GItem { // �޸����
public:
	bool transparent = 0;
	COLORREF col = RGB(0, 0, 0);
	G_Fill(bool _transparent = 0, COLORREF _col = RGB(0, 0, 0)) :transparent(_transparent), col(_col) {
		type = G_FILL; visible = 0;
	}
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		HBRUSH hbrush_new = CreateSolidBrush(col);
		if (transparent) hbrush_new = (HBRUSH)GetStockObject(NULL_BRUSH);
		HBRUSH oldbrush = (HBRUSH)SelectObject(pad, hbrush_new);
		DeleteObject(oldbrush);
		globalBin.G_BadHBrush.push_back(hbrush_new);
	}
};
class G_Font :public GItem { // �޸�����
public:
	int size = 0;
	LPCTSTR font = L"";
	COLORREF col = RGB(0, 0, 0);
	bool transbk = 0;
	G_Font(COLORREF _col = RGB(0, 0, 0), int _size = 40, bool _transbk = 0, LPCTSTR _font = _T("Arial")) : col(_col), size(_size), transbk(_transbk), font(_font) {
		type = G_FONT; visible = 0;
	};
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		CFont font_new;
		font_new.CreateFontW(max(1, size * rate), 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, font);
		CFont* font_old = (CFont*)SelectObject(pad, font_new);
		SetTextColor(pad, col);
		DeleteObject(font_old);
		if (transbk) SetBkMode(pad, transbk);
		globalBin.G_BadHFont.push_back(font_new);
	}
};
class G_Group :public GItem { // ��ͼԪ����
public:
	vector <GItem*> group = {};
	bool doBatch = 0; // �Ƿ���Ҫʹ��˫������������
	int xOffset = 0, yOffset = 0; // ����ƫ����
	double grate = 1; // ���ű���
	void calcSize() {
		if (group.empty()) {
			left = top = width = height = 0;
			return;
		}
		int right = -1e9, bottom = -1e9; left = 1e9, top = 1e9;
		for (auto item : group) {
			if (!item->visible) continue;
			item->calcSize();
			left = min(left, item->left);
			top = min(top, item->top);
			right = max(right, item->left + item->width);
			bottom = max(bottom, item->top + item->height);
		}
		height = bottom - top;
		width = right - left;
	}
	void erase() {
		for (auto item : group) {
			item->erase();
		}
	}
	void reset() { // ����
		for (auto item : group) {
			item->erase();
		}
		group.clear();
		group.push_back(new G_Pen());
		group.push_back(new G_Fill());
		group.push_back(new G_Font());
	}
	void push(GItem* item) { // �����ͼԪ��
		group.push_back(item);
	}
	G_Group(bool _doBatch = 0, int x_offset = 0, int y_offset = 0, double _rate = 1) :doBatch(_doBatch) {
		xOffset = x_offset; yOffset = y_offset; grate = _rate;
		height = width = top = left = 0;
		type = G_GROUP; visible = 1;
	}
	~G_Group() { erase(); }
	void draw(HDC pad, int rx = 0, int ry = 0, double rate = 1) {
		if (doBatch) { // ˫�������
			CRect rect;
			HWND hwnd = WindowFromDC(pad);
			GetClientRect(hwnd, &rect);
			int w = rect.Width(), h = rect.Height();
			HDC memDC = CreateCompatibleDC(pad);
			HBITMAP memBMP = CreateCompatibleBitmap(pad, w, h);
			HBITMAP* oldBMP = (HBITMAP*)SelectObject(memDC, memBMP);
			HBRUSH brush = CreateSolidBrush(GetBkColor(pad));
			FillRect(memDC, rect, brush);
			for (auto item : group) item->draw(memDC, rx + xOffset * rate, ry + yOffset * rate, rate * grate);
			BitBlt(pad, 0, 0, w, h, memDC, 0, 0, SRCCOPY);
			DeleteObject(brush);
			SelectObject(memDC, oldBMP);
			DeleteObject(memBMP);
			DeleteDC(memDC);
			globalBin.G_ClearBad();
		}
		else {
			for (auto item : group) item->draw(pad, rx + xOffset * rate, ry + yOffset * rate, rate * grate);
		}
	}
};
class G_Camera :public G_Group { // ����ͷ
public:
	G_Camera(bool _doBatch = 0, int x_offset = 0, int y_offset = 0, double _rate = 1) {
		reset();
		xOffset = -x_offset; yOffset = -y_offset;
		grate = _rate;
		doBatch = _doBatch;
		type = G_CAMERA; visible = 1;
	}
	~G_Camera() { erase(); }
};
class G_Clrscr :public GItem { // ����
public:
	bool useBkColor = 0;
	COLORREF col = RGB(0, 0, 0);
	G_Clrscr(bool _useBkColor = 1, COLORREF _col = RGB(255, 255, 255)) :useBkColor(_useBkColor), col(_col) {
		type = G_CLRSCR; visible = 0;
	}
	void draw(HDC pad) {
		CRect rect;
		HWND hwnd = WindowFromDC(pad);
		GetClientRect(hwnd, &rect);
		int w = rect.Width(), h = rect.Height();
		HBRUSH brush = CreateSolidBrush(useBkColor ? GetBkColor(pad) : col);
		FillRect(pad, rect, brush);
		DeleteObject(brush);
	}
};