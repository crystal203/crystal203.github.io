﻿#include <iostream>
#include <algorithm>
#include <functional>
#include <vector>
using namespace std;
/* 经过封装的 qsort */
template <typename T>
void qsort(T* l, T* r, function <bool(T, T)> cmp = ([](T x, T y) { return x < y; })) {
	typedef T* iter;
	if (l >= r - 1) return;
	iter i = l, j = r - 1, m = l;
	T x = *m;
	while (i < j) {
		while (i < j && !cmp(*j, x)) j--;
		if (i < j) *(i++) = *j;
		while (i < j && cmp(*i, x)) i++;
		if (i < j) *(j--) = *i;
	}
	*i = x;
	qsort(l, i, cmp);
	qsort(i + 1, r, cmp);
}
/* 用于测试的 qsort */
const int N = 1000010;
int a[N];
void qsort(int l, int r) {
	if (l >= r) return;
	int i = l, j = r, m = (l + r) / 2, x = a[m];
	while (i < j) {
		while (i < j && a[j] >= x) j--;
		if (i < j) a[i++] = a[j];
		while (i < j && a[i] < x) i++;
		if (i < j) a[j--] = a[i];
	}
	a[i] = x;
	qsort(l, i - 1);
	qsort(i + 1, r);
}
/* 返回中间过程的 qsort */
struct Step {
	int l, r, x, y;
};
vector <Step> stp;
void qsort_step(int l, int r) {
	if (l >= r) return;
	int i = l, j = r, m = (l+r)/2, x = a[m];
	while (i <= j) {
		while (a[i] < x) i++;
		while (a[j] > x) j--;
		if (i <= j) {
			stp.push_back(Step{ l,r,i,j });
			swap(a[i], a[j]); i++; j--;
		}
	}
	if (l < j) qsort_step(l, j);
	if (i < r) qsort_step(i, r);
}
int b[N];
int main() {
	for (int i = 1; i <= 10; ++i) a[i] = b[i] = 10-i+1;
	for (int i = 1; i <= 10; ++i) cout << a[i] << " ";
	puts("");
	qsort_step(1, 10);
	for (int i = 0; i < stp.size(); ++i) {
		swap(b[stp[i].x], b[stp[i].y]);
		for (int i = 1; i <= 10; ++i) cout << b[i] << " ";
		puts("");
	}
	for (int i = 1; i <= 10; ++i) cout << a[i] << " ";
	puts("");
}