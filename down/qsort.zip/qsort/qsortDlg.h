﻿#pragma once
#include <vector>
#include <mutex>
class CqsortDlg : public CDialogEx{
public:
	CqsortDlg(CWnd* pParent = nullptr);
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_QSORT_DIALOG };
#endif
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
protected:
	HICON m_hIcon;
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
private:
	std::mutex mu;
	bool animRun = 0;
	bool speedUp = 0;
	bool pause = 0;
	bool stop = 0;
	void drawBar(std::vector <int> a, std::vector <COLORREF> col);
	void animate(std::vector <int> a);
public:
	afx_msg void OnBnClickedOk2();
	afx_msg void OnBnClickedOk3();
	afx_msg void OnBnClickedOk4();
};
