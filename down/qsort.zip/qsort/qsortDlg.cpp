﻿#include "pch.h"
#include "framework.h"
#include "qsort.h"
#include "qsortDlg.h"
#include "afxdialogex.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif
CqsortDlg::CqsortDlg(CWnd* pParent) : CDialogEx(IDD_QSORT_DIALOG, pParent) {
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}
void CqsortDlg::DoDataExchange(CDataExchange* pDX) {
	CDialogEx::DoDataExchange(pDX);
}
BEGIN_MESSAGE_MAP(CqsortDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CqsortDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CqsortDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK2, &CqsortDlg::OnBnClickedOk2)
	ON_BN_CLICKED(IDOK3, &CqsortDlg::OnBnClickedOk3)
	ON_BN_CLICKED(IDOK4, &CqsortDlg::OnBnClickedOk4)
END_MESSAGE_MAP()
BOOL CqsortDlg::OnInitDialog() {
	CDialogEx::OnInitDialog();
	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
	CString s0 = L"3 7 1 6 2 8 9 4 5 10";
	GetDlgItem(IDC_EDIT1)->SetWindowTextW(s0);
	GetDlgItem(IDC_EDIT2)->SetWindowTextW(L"10");
	return TRUE;
}
void CqsortDlg::OnPaint() {
	if (IsIconic()) {
		CPaintDC dc(this);
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
		DeleteObject(dc);
	}
	else {
		CDialogEx::OnPaint();
	}
}
#include "myGraphics.h"
HCURSOR CqsortDlg::OnQueryDragIcon() {
	return static_cast<HCURSOR>(m_hIcon);
}
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
vector <int> splitString(const string& s) {
	istringstream iss(s);
	vector <int> tokens;
	std::string token;
	while (iss >> token) tokens.push_back(stoi(token));
	return tokens;
}
struct Step {
	int l, r, x, y;
};
vector <Step> stp;
void qsort_step(vector <int> a, int l, int r) {
	if (l >= r) return;
	int i = l, j = r, m = (l + r) / 2, x = a[m];
	stp.push_back(Step{ l,r, m, -1 });
	while (i <= j) {
		while (a[i] < x) i++;
		while (a[j] > x) j--;
		if (i <= j) {
			stp.push_back(Step{ l,r,i,j });
			swap(a[i], a[j]); i++; j--;
		}
	}
	if (l < j) qsort_step(a, l, j);
	if (i < r) qsort_step(a, i, r);
}
#include <thread>
#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
void CqsortDlg::animate(vector <int> a) {
	mu.lock(); animRun = 1; stop = 0; mu.unlock();
	vector <COLORREF> c;
	for (int i = 0; i < a.size(); ++i) c.push_back(RGB(0, 255, 0));
	drawBar(a, c);
	vector <int> b;
	for (int i = 0; i < a.size(); ++i) b.push_back(a[i]);
	stp.clear();
	qsort_step(a, 0, a.size() - 1);
	for (int i = 0; i < stp.size(); ++i) {
		for (int j = 0; j < a.size(); ++j) c[j] = RGB(0, 255, 0);
		if (stop) break;
		int delay = speedUp ? 10 : 500;
		if (stp[i].y == -1) {
			for (int j = stp[i].l; j <= stp[i].r; ++j) {
				c[j] = RGB(0, 255, 255);
			}
			c[stp[i].x] = RGB(255, 0, 255);
		}
		else {
			for (int j = stp[i].l; j <= stp[i].r; ++j) {
				c[j] = RGB(0, 255, 255);
			}
			drawBar(b, c);
			Sleep(delay);
			c[stp[i].x] = c[stp[i].y] = RGB(255, 0, 0);
			drawBar(b, c);
			Sleep(delay);
			swap(b[stp[i].x], b[stp[i].y]);
		}
		drawBar(b, c);
		Sleep(delay);
	}
	for (int j = 0; j < a.size(); ++j) c[j] = RGB(0, 255, 0);
	drawBar(b, c);
	mu.lock(); animRun = 0; mu.unlock();
}
void CqsortDlg::OnBnClickedOk() {
	CString s0;
	GetDlgItem(IDC_EDIT1)->GetWindowTextW(s0);
	string s = CT2A(s0);
	vector <int> a = splitString(s);
	if (!animRun) {
		thread anim(&CqsortDlg::animate, this, a);
		anim.detach();
	}
}
void CqsortDlg::drawBar(vector <int> a, vector <COLORREF> col) {
	HDC myhdc = ::GetDC(GetDlgItem(IDC_STATIC)->GetSafeHwnd());
	G_Group* g = new G_Group();
	g->push(new G_Pen(0, 2, RGB(0, 0, 0)));
	g->push(new G_Fill(0, RGB(0, 255, 0)));
	CStatic* pStaticPic = reinterpret_cast<CStatic*>(GetDlgItem(IDC_STATIC));
	CRect rect;
	pStaticPic->GetWindowRect(&rect);
	int windowW = rect.Width(), windowH = rect.Height();
	DeleteObject(pStaticPic);
	DeleteObject(rect);
	int maxH = a.size() * 20 * windowH / windowW, maxa = 1;
	for (int i = 0; i < a.size(); ++i) {
		maxa = max(maxa, a[i]);
	}
	for (int i = 0; i < a.size(); ++i) {
		g->push(new G_Fill(0, col[i]));
		g->push(new G_Rect(i * 20, -1.0 * a[i] / maxa * maxH, (i + 1) * 20, 0));
	}
	G_Camera* camera = new G_Camera(1); camera->push(g);
	camera->calcSize();
	int top = camera->top, left = camera->left, width = camera->width, height = camera->height;
	int cameraX = left, cameraY = top;
	camera->xOffset = -cameraX; camera->yOffset = -cameraY;
	double cameraR = min(1.0 * windowW / width, 1.0 * windowH / height);
	camera->grate = cameraR;
	camera->draw(myhdc);
	camera->erase();
	::ReleaseDC(GetDlgItem(IDC_STATIC)->GetSafeHwnd(), myhdc);
}
void CqsortDlg::OnBnClickedCancel() {
	CDialogEx::OnCancel();
}
void CqsortDlg::OnBnClickedOk2() {
	CString s0;
	GetDlgItem(IDC_EDIT2)->GetWindowTextW(s0);
	string s = CT2A(s0);
	int n = stoi(s);
	string res = "";
	for (int i = 0; i < n; ++i) {
		res = res + to_string(rand() % 50 + 1) + " ";
	}
	GetDlgItem(IDC_EDIT1)->SetWindowTextW(string2cstring(res));
}
void CqsortDlg::OnBnClickedOk3() {
	if (!speedUp) {
		GetDlgItem(IDOK3)->SetWindowTextW(L"减速");
		mu.lock(); speedUp = 1; mu.unlock();
	}
	else {
		GetDlgItem(IDOK3)->SetWindowTextW(L"加速");
		mu.lock(); speedUp = 0; mu.unlock();
	}
}
void CqsortDlg::OnBnClickedOk4() {
	mu.lock(); stop = 1; mu.unlock();
}
