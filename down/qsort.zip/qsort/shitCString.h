#pragma once
#include <string>
using namespace std;
#include "stdafx.h"
#pragma optimize("g", off)
#pragma warning(disable : 4996)
inline string tchars2string(TCHAR* STR) {
	int iLen = WideCharToMultiByte(CP_ACP, 0, STR, -1, NULL, 0, NULL, NULL);
	char* chRtn = new char[iLen * sizeof(char)];
	WideCharToMultiByte(CP_ACP, 0, STR, -1, chRtn, iLen, NULL, NULL);
	return chRtn;
}
inline CString string2cstring(string text) {
	CString s0;
	wstring wtext; wtext.resize(text.size());
	mbstowcs(&wtext[0], text.c_str(), text.size());
	s0.Format(wtext.c_str());
	return s0;
}
inline string tchar2string(TCHAR ch) {
	if (is_same<TCHAR, wchar_t>::value) {
		int len = 1;
		char mbstr[2];
		mbstr[1] = '\0';
		::wcstombs(mbstr, &ch, len);
		return string(mbstr);
	}
	else {
		return string(1, static_cast<char>(ch));
	}
}
