#pragma once

#include "console4.h"

class Tile{
private:
	
public:
	int x,y,z,orgx,orgy,orgz;
	bool enable,invis,rmv;
	int col;
	Tile(int _x=0,int _y=0,int _z=0,bool _en=false,int _col=0,bool _in=false){
		orgx=x=_x;orgy=y=_y;orgz=z=_z;enable=_en;col=_col;invis=_in;rmv=0;
	}
	~Tile(){}
	void printFile(ofstream &lvl){
		lvl<<x<<" "<<y<<" "<<z<<endl;
	}
	void readFile(ifstream &lvl){
		lvl>>x>>y>>z;orgx=x;orgy=y;orgz=z;
	}
	void refresh(){
		x=orgx;y=orgy;z=orgz;enable=0;rmv=0;invis=0;
	}
};
class Level{
private:
	
public:
	string name,pic;
	vector <Tile*> mp,wt;int rem;
	vector <int> solu;
	Level(string _name="Noname",string _pic="noname"){
		name=_name;pic=_pic;mp.clear();wt.clear();
	}
	~Level(){}
	void printFile(){
		ofstream lvl("./dat/"+name+".dat");
		lvl<<pic<<endl<<mp.size()<<endl;
		for (int i=0;i<(int)mp.size();++i){
			mp[i]->printFile(lvl);
		}
		lvl.close();
	}
	void readFile(){
		ifstream lvl("./dat/"+name+".dat");
		int n;lvl>>pic>>n;
		for (int i=1;i<=n;++i){
			mp.push_back(new Tile);mp.back()->readFile(lvl);
		}
		lvl.close();
	}
	void sortTiles(){
		sort(mp.begin(),mp.end(),[](Tile *a,Tile *b){return a->z<b->z;});
		for (int i=0;i<(int)mp.size();++i){
			mp[i]->enable=1;
			for (int j=i;j<(int)mp.size();++j){
				if (!mp[i]->invis && !mp[j]->invis && mp[i]->z<mp[j]->z && abs(mp[i]->x-mp[j]->x)<=1 && abs(mp[i]->y-mp[j]->y)<=1){
					mp[i]->enable=0;
				}
			}
		}
	}
	bool canPlace(int x,int y){
		for (int i=0;i<(int)mp.size();++i){
			if (mp[i]->x==x && mp[i]->y==y && mp[i]->enable) return 0;
		}
		return 1;
	}
	void restart(){
		wt.clear();
		for (int i=0;i<(int)mp.size();++i) mp[i]->refresh();
		sortTiles();
		rem=mp.size();
	}
};
