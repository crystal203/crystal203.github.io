#include "console4.h"
#include <graphics.h>
#include <conio.h>
#include "item.h"
const string version="1.0";
const int LBOUND=320,WIDTH=640,HEIGHT=960,TILE=40,HTILE=TILE/2,TPOSX=140,TPOSY=180,TX=(TPOSX-LBOUND)/HTILE,TY=TPOSY/HTILE;
int MAXTOOL=3;
bool DEBUG=1;
bool BAN_AUTO=0;
bool CAN_SOLVE=1;
bool isChosen(int x,int y,int px,int py){
	return (x-px==1 || x-px==0) && (y-py==1 || y-py==0);
}
bool isAutoSolve=0;
int gameStatus=0;
int tools=MAXTOOL,rcnt=0;
void gainColor(Level &cur){
	srand((unsigned)time(NULL));
	if (CAN_SOLVE){
		cur.rem=cur.mp.size();
		int n=(int)cur.mp.size()/3;
		vector <int> stk;stk.clear();
		int now=0;
		while (now<cur.mp.size()){
			int r=rand()%2;
			if (n && r==0 && stk.size()<=4){
				int p=rand()%15+1;
				stk.push_back(p);
				stk.push_back(p);
				cur.mp[now]->col=p;
				cur.solu.push_back(now++);
				n--;
			}else if (r==1 && stk.size()>=1){
				int p=rand()%(stk.size());
				cur.mp[now]->col=stk[p];
				cur.solu.push_back(now++);
				stk.erase(stk.begin()+p);
			}
		}		
	}else{
		for (int i=0;i<(int)cur.mp.size();++i) cur.mp[i]->col=rand()%15+1;
	}
}
void printGUI(Level &cur){
	setlinecolor(0x00ff00);setlinestyle(PS_ENDCAP_FLAT,3);
	rectangle(TPOSX-2,TPOSY-2,TPOSX+TILE+2,TPOSY+7*TILE+2); 
	settextcolor(0xffffff);
	outtextxy(120,60,cur.name.c_str());	
	settextcolor(0x00ff00);
	outtextxy(120,120,(to_string(cur.rem)+" Remaining").c_str());settextcolor(0xffffff);
	switch (gameStatus){
		case 1:{
			settextcolor(0x00ff00);
			outtextxy(120,660,"YOU WIN!!!");
			settextcolor(0xffffff);	
			outtextxy(120,680,"Press F4 to return.");	
			break;
		}
		case 2:{
			settextcolor(0x0000ff);
			outtextxy(120,660,"YOU LOSE.");
			settextcolor(0xffffff);	
			outtextxy(120,680,"Press F4 to return.");	
			outtextxy(120,700,"Or F5 to retry.");			
			break;
		}
		default:{
			if (!isAutoSolve){
				settextcolor(0xffff00);
				outtextxy(120,660,"Game Running...");				
			}else{
				settextcolor(0x00ffff);
				outtextxy(120,660,"Auto Solving... (F8 to Break)");					
			}
			settextcolor(0xffffff);	
			outtextxy(120,680,"F4       Return");
			outtextxy(120,700,"F5       Retry");
			if (!BAN_AUTO && CAN_SOLVE){
				outtextxy(120,720,"F9       Auto Solve");
				outtextxy(120,740,"F10     Fast Auto Solve");				
			}
			outtextxy(120,760,"Q        Remove Tool");
			outtextxy(140,780,(to_string(tools)+" chance(s) left").c_str());
			break;
		}
	}
}
void gameRefresh(Level &cur){
	cleardevice();
	IMAGE bg;
	loadimage(&bg,_T(("./pic/"+cur.pic+".png").c_str()));
	putimage(LBOUND,0,&bg);	
	IMAGE tl,tlc,tlh;
	loadimage(&tl,_T("./pic/tile.bmp"));
	loadimage(&tlc,_T("./pic/tile_c.bmp"));
	loadimage(&tlh,_T("./pic/tile_h.bmp"));
	cur.sortTiles();
	POINT pt;getpos(pt);
	int nowx=(pt.x-LBOUND)/HTILE,nowy=pt.y/HTILE;
	for (int i=0;i<(int)cur.mp.size();++i){
		Tile* now=cur.mp[i];
		if (now->invis) continue; 
		if (now->enable){
			if (isChosen(nowx,nowy,now->x,now->y)) putimage(now->x*HTILE+LBOUND,now->y*HTILE,&tlh);
			else putimage(now->x*HTILE+LBOUND,now->y*HTILE,&tl);
		}else putimage(now->x*HTILE+LBOUND,now->y*HTILE,&tlc);
		outtextxy(now->x*HTILE+LBOUND,now->y*HTILE,to_string(now->col).c_str());
	}
	for (int i=0;i<(int)cur.wt.size();++i){
		Tile* now=cur.wt[i];now->x=TX;now->y=TY+i*2;
		putimage(now->x*HTILE+LBOUND,now->y*HTILE,&tl);
		outtextxy(now->x*HTILE+LBOUND,now->y*HTILE,to_string(now->col).c_str());
	}
	printGUI(cur);
	FlushBatchDraw();		
}
void refresh(Level &cur){
	for (int i=0;i<(int)cur.wt.size();++i) cur.wt[i]->rmv=0;
	for (int i=0;i<(int)cur.wt.size();++i){
		int cnt=1;
		for (int j=i+1;j<(int)cur.wt.size();++j){
			if (cur.wt[j]->col==cur.wt[i]->col) cnt++;
		}
		if (cnt==3){
			for (int j=i;j<(int)cur.wt.size();++j){
				if (cur.wt[j]->col==cur.wt[i]->col) cur.wt[j]->rmv=1;
			}			
		}
	}
	vector <Tile*> tmp;
	for (int i=0;i<(int)cur.wt.size();++i){
		if (!cur.wt[i]->rmv) tmp.push_back(cur.wt[i]);
	}
	cur.wt=tmp;
}
void restart(Level &cur){
	cur.restart();
	isAutoSolve=gameStatus=rcnt=0;tools=MAXTOOL;
	gameRefresh(cur);
}
void autosolve(Level &cur,bool fastmode=0){
	restart(cur);
	isAutoSolve=1;
	gameRefresh(cur);
	for (int i=(int)cur.solu.size()-1;i>=0;--i){
		if (!fastmode){
			while (!press(VK_LBUTTON) && !press(VK_F8));dpress(VK_LBUTTON);
		}
		if (press(VK_F8)){
			isAutoSolve=0;return;
		}
		int x=cur.solu[i];
		Tile *now=cur.mp[x];
		cur.wt.push_back(now);now->invis=1;cur.rem--;
		refresh(cur);
		gameRefresh(cur);
	}
	isAutoSolve=0;gameStatus=1;
	gameRefresh(cur);
}
void playGame(string name){
	Level cur(name);cur.readFile();
	gainColor(cur);
	initgraph(LBOUND+WIDTH,HEIGHT/*,EX_SHOWCONSOLE*/);BeginBatchDraw();
	restart(cur);
	gameRefresh(cur);
	int lsx=0,lsy=0;
	while (1){
		if (cur.rem==0){
			gameStatus=1;
			gameRefresh(cur);
		}
		POINT pt;getpos(pt);
		int nowx=(pt.x-LBOUND)/HTILE,nowy=pt.y/HTILE;
		if (lsx!=nowx || lsy!=nowy){
			lsx=nowx;lsy=nowy;gameRefresh(cur);
		}  
		if (press(VK_F4)) break;
		else if (press(VK_LBUTTON) && !gameStatus){
			for (int i=0;i<(int)cur.mp.size();++i){
				Tile* now=cur.mp[i];
				if (now->enable && isChosen(nowx,nowy,now->x,now->y)){
					cur.wt.push_back(now);now->invis=1;cur.rem--;
					refresh(cur);
					if (cur.wt.size()>=7) gameStatus=2;
					break;
				}
			}
			gameRefresh(cur);
			dpress(VK_LBUTTON);
		}else if (press(VK_F5)){
			restart(cur);dpress(VK_F5);
		}else if (!BAN_AUTO && CAN_SOLVE && press(VK_F9)){
			autosolve(cur);dpress(VK_F9);
		}else if (!BAN_AUTO && CAN_SOLVE && press(VK_F10)){
			autosolve(cur,1);dpress(VK_F10);
		}else if (press('Q') && cur.wt.size()>=3 && tools>0){
			tools--;
			reverse(cur.wt.begin(),cur.wt.end());
			for (int i=1;i<=3;++i){
				Tile* now=cur.wt.back();cur.wt.pop_back();
				rcnt++;now->invis=0;
				now->x=1+rcnt%10*2;
				now->y=1+rcnt/10*2;
				now->z=cur.mp.size();cur.mp.push_back(now);
			}
			reverse(cur.wt.begin(),cur.wt.end());
			gameRefresh(cur);
			dpress('Q');
		}
	}
	EndBatchDraw();
	closegraph();	
}
void startGame(){
	while (1){
		clrscr();
		string tmp="&f>>> &eCHOOSE LEVEL&f <<<@&cExit&f@";
		ifstream info("level.ini");
		int n;info>>n;
		vector <string> levels;
		for (int i=1;i<=n;++i){
			string s;info>>s;levels.push_back(s);
			tmp=tmp+s+"@";
		}tmp=tmp+"^&fGame Version &a"+version;
		info.close();
		int c=chosenbox(tmp);
		if (c==1) break;
		else playGame(levels[c-2]);
	}
}
void editRefresh(Level &cur){
	cleardevice();
	IMAGE bg;
	loadimage(&bg,_T(("./pic/"+cur.pic+".png").c_str()));
	putimage(LBOUND,0,&bg);	
	IMAGE tl,tlc;
	loadimage(&tl,_T("./pic/tile.bmp"));
	loadimage(&tlc,_T("./pic/tile_c.bmp"));
	cur.sortTiles();
	for (int i=0;i<(int)cur.mp.size();++i){
		Tile* now=cur.mp[i];
		if (now->enable) putimage(now->x*HTILE+LBOUND,now->y*HTILE,&tl);
		else putimage(now->x*HTILE+LBOUND,now->y*HTILE,&tlc);
	}
	POINT pt;getpos(pt);
	int nowx=(pt.x-LBOUND)/HTILE,nowy=pt.y/HTILE;
	if (nowx>=0 && nowy>=0 && nowx<=WIDTH/HTILE-2 && nowy<=HEIGHT/HTILE-2){
		if (cur.canPlace(nowx,nowy)) setlinecolor(0x00ff00);
		else setlinecolor(0x0000ff);
		setlinestyle(PS_DASH|PS_ENDCAP_FLAT,3);
		rectangle(nowx*HTILE+LBOUND,nowy*HTILE,nowx*HTILE+LBOUND+TILE,nowy*HTILE+TILE);	
	}
	if (cur.mp.size()%3==0) settextcolor(0x00ff00);
	else settextcolor(0x0000ff);
	outtextxy(120,120,(to_string(cur.mp.size())).c_str());
	FlushBatchDraw();		
}
void levelEdit(string name){
	Level cur(name);cur.readFile();
	initgraph(LBOUND+WIDTH,HEIGHT/*,EX_SHOWCONSOLE*/);BeginBatchDraw();
	editRefresh(cur);
	int lsx=0,lsy=0;
	while (1){
		POINT pt;getpos(pt);
		int nowx=(pt.x-LBOUND)/HTILE,nowy=pt.y/HTILE;
		if (lsx!=nowx || lsy!=nowy){
			lsx=nowx;lsy=nowy;editRefresh(cur);
			FlushBatchDraw();
		}  
		if (press('X') && ((int)cur.mp.size())%3==0) break;
		else if (press('R')) editRefresh(cur),dpress('R');
		else if (press(VK_LBUTTON)){
			if (nowx>=0 && nowy>=0 && nowx<=WIDTH/HTILE-2 && nowy<=HEIGHT/HTILE-2 && cur.canPlace(nowx,nowy)){
				cur.mp.push_back(new Tile(nowx,nowy,(int)cur.mp.size()));
				editRefresh(cur);
				dpress(VK_LBUTTON);				
			}
		}else if (press('Z')){
			if (cur.mp.size()!=0) cur.mp.pop_back();
			editRefresh(cur);
			dpress('Z');
		}else if (press('S')){
			cur.printFile();dpress('S');
		}
	}
	cur.printFile();
	EndBatchDraw();
	closegraph();
}
void levelEditor(){
	while (1){
		clrscr();
		string tmp="&f>>> &eCHOOSE LEVEL&f <<<@&aCreate&f@&cExit&f@";
		ifstream info("level.ini");
		int n;info>>n;
		vector <string> levels;
		for (int i=1;i<=n;++i){
			string s;info>>s;levels.push_back(s);
			tmp=tmp+s+"@";
		}tmp=tmp+"^";
		info.close();
		int c=chosenbox(tmp);
		if (c==1){
			clrscr();showCursor();
			tellraw("&aLevel Name:&f\n");string name;cin>>name;
			tellraw("&aPicture Name:&f\n");string pic;cin>>pic;
			Level cur(name,pic);cur.printFile();
			levels.push_back(name);
			hideCursor();
			levelEdit(name);
		}else if (c==2){
			break;
		}else{
			levelEdit(levels[c-3]);
		}
		ofstream _info("level.ini");
		_info<<levels.size()<<endl;
		for (int i=0;i<(int)levels.size();++i) _info<<levels[i]<<endl;
		_info.close();		
	}
}
void initSettings(){
	ifstream info("setting.ini");
	info>>DEBUG>>CAN_SOLVE>>MAXTOOL>>BAN_AUTO;
	info.close();
}
void updateSettings(){
	ofstream info("setting.ini");
	info<<DEBUG<<endl<<CAN_SOLVE<<endl<<MAXTOOL<<endl<<BAN_AUTO;
	info.close();
}
void settings(){
	while (1){
		clrscr();
		switch (chosenbox("&f>>> &eSETTINGS&f <<<@&cExit@&eSet Max Tool@&eSet Solvability@&eSet AutoSolve Enability@^")){
			case 1:return;break;
			case 2:tellraw("&eTool Limit Set:");puts("");showCursor();cin>>MAXTOOL;hideCursor();break;
			case 3:CAN_SOLVE=chosenbox("&bIs the puzzle must be solvable?@&cNO@&aYES@^")-1;break;
			case 4:BAN_AUTO=chosenbox("&bDoes the autosolve be banned?@&cNO@&aYES@^")-1;break;
		}			
		updateSettings();
	}	
}
int main(){
	initSettings();
	hideCursor();
	if (DEBUG){
		while (1){
			clrscr();
			switch (chosenbox("&f>>> &eDEBUG OPTION&f <<<@&aLevel Editor@&bStart Game@&cSettings@^")){
				case 1:levelEditor();break;
				case 2:startGame();break;
				case 3:settings();break;
			}			
		}
	}else startGame();
	showCursor();
	return 0;
}