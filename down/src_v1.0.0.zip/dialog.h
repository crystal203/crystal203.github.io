#pragma once
#include <bits/stdc++.h>
#include "game.h"
#include "Windows.h"
using namespace std;
class Game;
class dstring;
class DialogText{
public:
	bool visible;
	DialogText(){visible=0;}
	~DialogText(){}
	dstring* text;
	int character,emotion;
	void showDialog(Game* game,dstring cur,int _character=-1,int _emotion=-1);
	void hideDialog(Game* game);
	void printDialog(Game *game);
};