#include "game.h"
#include "easyx.h"
using namespace std;
void Game::refresh(){
	trig.work(this);
	cleardevice();
	if (gameEnd) cgList.draw(1,0,0);
	else cgList.draw(0,0,0);
	/*Draw Map*/
	if (visible==1 && !mbook) mapnow.floors[mapnow.floor]->draw(this);
	if (visible==0 && !gameEnd) uiList.draw(6,20,170);
	if (mbook){
		uiList.draw(5,20,170);
		mapnow.floors[mapnow.floor]->findMonster(this,1);
		int n=(mapnow.floors[mapnow.floor]->findMonster(this)-1)/6+1;
		string s=to_string(mpage+1)+"/"+to_string(n);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(s.c_str()),170+412-textwidth(s.c_str()),s);
	}
	if (tele){
		settextcolor(GREEN);
		setbkmode(TRANSPARENT);
		settextstyle(24*rate,0,font.c_str());
		drawText(20+412-32,170,ds({"W/S to teleport","W/S �л�¥��"}));		
	}
	if (chooseWeapon || chooseAccessory || chooseTool){
		uiList.draw(5,20,170);
	}
	/*Show Player*/
	if (tele!=2 && visible==1 && !mbook && !chooseWeapon && !chooseAccessory && !chooseTool) player->drawPlayer(this);
	/*Show Status*/
	if (visible==1){
		uiList.draw(9,20,20);
		int atk=player->calcAtk();
		int def=player->calcDef();
		int hp=player->hp;
		int mag=player->calcMag();
		
		settextstyle(24*rate,0,font.c_str());
		settextcolor(WHITE);
		drawText(30,30,ds({"Hp:","������"}));
		drawText(60,30,ds({"Atk:","������"}));
		drawText(90,30,ds({"Def:","������"}));
		drawText(120,30,ds({"Mag:","ħ����"}));
		drawText(280,30,ds({"Equipped:","װ����"}));
		if (trig.p[32]==1){
			drawText(400,30,ds({"Soul:","��꣺"}));
		}
		player->weapon->drawWeapon(this,310,30);
		player->accessory->drawAccessory(this,310,100);
		settextstyle(24*rate,0,"Arial");
		if (player->poison) settextcolor(LIGHTGREEN);
		else settextcolor(LIGHTMAGENTA);
		int stnum=30+textwidth(_T("������"))/rate+5;
		drawText(30,stnum,to_string(hp));
		settextcolor(LIGHTRED);
		drawText(60,stnum,to_string(atk)+(player->weakness?"��":""));
		settextcolor(RGB(145,200,225));
		drawText(90,stnum,to_string(def)+(player->fragile?"��":""));
		settextcolor(LIGHTGREEN);
		drawText(120,stnum,to_string(mag));
		blockList.draw(4,150,30,0,1);
		blockList.draw(4,180,30,1,1);
		blockList.draw(4,210,30,2,1);
		blockList.draw(4,240,30,3,1);
		settextcolor(RGB(255,128,0));
		drawText(150,stnum,to_string(player->ykey));
		settextcolor(RGB(145,200,225));
		drawText(180,stnum,to_string(player->bkey));
		settextcolor(LIGHTRED);
		drawText(210,stnum,to_string(player->rkey));
		settextcolor(LIGHTGREEN);
		drawText(240,stnum,to_string(player->gkey));
		if (trig.p[32]==1){
			settextcolor(RGB(145,200,225));
			drawText(400,stnum,to_string(player->soul));
		}
	}
	/*Show Dialog*/
	setbkmode(TRANSPARENT);
	settextcolor(BLACK);
	settextstyle(16*rate,0,font.c_str());
	drawText(460,170,info);
	if (dialog.visible){
		dialog.printDialog(this);
	}
	if (!chooseWeapon && !chooseAccessory && !chooseTool) FlushBatchDraw();	
}
#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
void Game::article(string s){
	bool event0=(s=="./text/event1.txt");
	bool event1=(s=="./text/end.txt");
	ifstream txt(s);
	int n;txt>>n;bool fast=0;
	for (int i=1;i<=n;++i){
		if (event0 && i==5){
			visible=0;
			player->wBag.clear();
			player->wBag.push_back(new Weapon(0,0,0,0));
			player->weapon=player->wBag.back();
			player->aBag.clear();
			player->aBag.push_back(new Accessory(0,0,0,0));
			player->accessory=player->aBag.back();
		}
		if (event0 && i==3){
			mapnow.floors[0]->block[3][6]=new BlockFloor(3,6,0);
			mapnow.floors[0]->block[3][7]=new Monster(3,7,0,1,MonAtk[1],MonDef[1],MonHp[1],MonSpc[1]);
		}
		if (event1 && i==7){
			visible=0;
			gameEnd=1;
			refresh();
		}
		int c,e=-1;string cn,en;
		txt>>c;if (c!=-1) txt>>e;
		getline(txt,cn);
		getline(txt,cn);
		getline(txt,en);
		dialog.showDialog(this,{en,cn},c,e);
		while (!debug && !fast && !press(' ') && !press(VK_ESCAPE));
		if (press(VK_ESCAPE)) fast=1;
		while (press(' '));
	}
	visible=1;
	if (event0){
		mapnow.floor=player->nowf=1;
		player->nowx=10;
		player->nowy=6;
		player->atk=10;player->def=10;player->mag=player->lvl=0;
		player->hp=1000;
		refresh();
		takeScreenShot();
		save("./save/quicksave.sav");
	}
	dialog.hideDialog(this);
	txt.close();
}
void Game::takeScreenShot(int tp){
	if (tp==0) getimage(&screenshot,170*rate,20*rate,412*rate,412*rate);
	else{
		saveimage(("./screenshot/"+getTime(1)+".png").c_str());
		info=ds({"Screenshot taken","�ѽ���"});
	}
}
void Game::loadAsset(){
	uiList.game=this;
	loadImage(&uiList,"./asset/dialogL.png",32,64,"./asset/dialogL_x.png");
	loadImage(&uiList,"./asset/dialogM.png",16,64,"./asset/dialogM_x.png");
	loadImage(&uiList,"./asset/dialogR.png",16,64,"./asset/dialogR_x.png");
	loadImage(&uiList,"./asset/frame.png",86,79,"./asset/frame_x.png");
	loadImage(&uiList,"./asset/dialogN.png",32,64,"./asset/dialogN_x.png");
	loadImage(&uiList,"./asset/book.png",416,416);
	loadImage(&uiList,"./asset/black.png",416,416);
	loadImage(&uiList,"./asset/choose.bmp",64,64);
	loadImage(&uiList,"./asset/unchoose.bmp",64,64);
	loadImage(&uiList,"./asset/sidebar.bmp",150,416);
	loadImage(&uiList,"./asset/score.bmp",250,250);
	
	emotionList.game=this;
	loadImage(&emotionList,"./emotion/hana_normal.png",64,64);
	loadImage(&emotionList,"./emotion/hana_angry.png",64,64);
	loadImage(&emotionList,"./emotion/hana_climax.png",64,64);
	loadImage(&emotionList,"./emotion/hana_confused.png",64,64);
	loadImage(&emotionList,"./emotion/hana_curious.png",64,64);
	loadImage(&emotionList,"./emotion/hana_embarrassed.png",64,64);
	loadImage(&emotionList,"./emotion/hana_evasive.png",64,64);
	loadImage(&emotionList,"./emotion/hana_excited.png",64,64);
	loadImage(&emotionList,"./emotion/hana_glad.png",64,64);
	loadImage(&emotionList,"./emotion/hana_happy.png",64,64);
	loadImage(&emotionList,"./emotion/hana_hot.png",64,64);
	loadImage(&emotionList,"./emotion/hana_insidious.png",64,64);
	loadImage(&emotionList,"./emotion/hana_love.png",64,64);
	loadImage(&emotionList,"./emotion/hana_sad.png",64,64);
	loadImage(&emotionList,"./emotion/hana_scared.png",64,64);
	loadImage(&emotionList,"./emotion/hana_shocked.png",64,64);
	loadImage(&emotionList,"./emotion/chief.png",64,64);
	loadImage(&emotionList,"./emotion/yuna_normal.png",64,64);
	loadImage(&emotionList,"./emotion/yuna_smile.png",64,64);
	
	charList.game=this;
	loadImage(&charList,"./character/left.bmp",32,34,"./character/left_x.bmp");
	loadImage(&charList,"./character/back.bmp",32,34,"./character/back_x.bmp");
	loadImage(&charList,"./character/right.bmp",32,34,"./character/right_x.bmp");
	loadImage(&charList,"./character/front.bmp",32,33,"./character/front_x.bmp");
	loadImage(&charList,"./character/yuna_left.bmp",32,38,"./character/yuna_left_x.bmp");
	loadImage(&charList,"./character/yuna_right.bmp",32,38,"./character/yuna_right_x.bmp");
	
	blockList.game=this;
	loadImage(&blockList,"./tier/floor.bmp",32,32,"",-1,32);
	loadImage(&blockList,"./tier/wall.bmp",128,32,"",-1,32);
	loadImage(&blockList,"./tier/gem.bmp",416,32,"./tier/gem_x.bmp",-1,32);
	loadImage(&blockList,"./tier/hp.bmp",128,32,"./tier/hp_x.bmp",-1,32);
	loadImage(&blockList,"./tier/key.bmp",128,32,"./tier/key_x.bmp",-1,32);
	loadImage(&blockList,"./tier/ydoor.bmp",128,32,"./tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./tier/bdoor.bmp",128,32,"./tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./tier/rdoor.bmp",128,32,"./tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./tier/gdoor.bmp",128,32,"./tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./tier/fdoor.bmp",128,32,"./tier/fdoor_x.bmp",-1,32);
	loadImage(&blockList,"./tier/idoor.bmp",128,32,"./tier/idoor_x.bmp",-1,32);
	loadImage(&blockList,"./tier/stair.bmp",224,32,"./tier/stair_x.bmp",-1,32);
	loadImage(&blockList,"./tier/button.bmp",64,32,"./tier/button_x.bmp",-1,32);
	loadImage(&blockList,"./tier/arrow.bmp",128,32,"./tier/arrow_x.bmp",-1,32);
	
	enemyList.game=this;
	loadImage(&enemyList,"./enemy/chief.bmp",64,39,"./enemy/chief_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/chief2.bmp",192,86,"./enemy/chief2_x.bmp",-1,96);
	loadImage(&enemyList,"./enemy/slime0.bmp",64,32,"./enemy/slime0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/slime1.bmp",64,32,"./enemy/slime1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/skeleton0.bmp",64,32,"./enemy/skeleton0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/guard0.bmp",64,32,"./enemy/guard0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/skeleton1.bmp",64,32,"./enemy/skeleton1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/bat0.bmp",64,32,"./enemy/bat0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/bat1.bmp",64,32,"./enemy/bat1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/mage0.bmp",64,32,"./enemy/mage0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/slime2.bmp",64,32,"./enemy/slime2_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/zombie0.bmp",64,32,"./enemy/zombie0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/skeleton2.bmp",64,32,"./enemy/skeleton2_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/stone.bmp",64,32,"./enemy/stone_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/zombie1.bmp",64,32,"./enemy/zombie1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/mage1.bmp",64,32,"./enemy/mage1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/guard1.bmp",64,32,"./enemy/guard1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/slime4.bmp",64,32,"./enemy/slime4_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/bat3.bmp",64,32,"./enemy/bat3_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/skeleton3.bmp",64,32,"./enemy/skeleton3_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/swordman.bmp",64,32,"./enemy/swordman_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/warrior0.bmp",64,32,"./enemy/warrior0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/warrior1.bmp",64,32,"./enemy/warrior1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/warrior2.bmp",64,32,"./enemy/warrior2_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/slime3.bmp",64,32,"./enemy/slime3_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/bat2.bmp",64,32,"./enemy/bat2_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/witch0.bmp",64,32,"./enemy/witch0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/witch1.bmp",64,32,"./enemy/witch1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/demon0.bmp",64,32,"./enemy/demon0_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/demon1.bmp",64,32,"./enemy/demon1_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/warrior3.bmp",64,32,"./enemy/warrior3_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/guard2.bmp",64,32,"./enemy/guard2_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/great.bmp",64,32,"./enemy/great_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/tower_red.bmp",64,58,"./enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/tower_blue.bmp",64,58,"./enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/tower_green.bmp",64,58,"./enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/tower_purple.bmp",64,58,"./enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./enemy/slime5.bmp",64,32,"./enemy/slime0_x.bmp",-1,32);
	
	cgList.game=this;
	loadImage(&cgList,"./cg/cover.png",640,480);
	loadImage(&cgList,"./cg/final.png",640,480);
	
	weaponList.game=this;
	loadImage(&weaponList,"./item/empty.bmp",64,64,"./item/empty_x.bmp");
	loadImage(&weaponList,"./item/weapon1.bmp",64,64,"./item/weapon_x.bmp");
	loadImage(&weaponList,"./item/weapon2.bmp",64,64,"./item/weapon_x.bmp");
	loadImage(&weaponList,"./item/weapon3.bmp",64,64,"./item/weapon_x.bmp");
	loadImage(&weaponList,"./item/weapon4.bmp",64,64,"./item/weapon4_x.bmp");
	loadImage(&weaponList,"./item/weapon5.bmp",64,64,"./item/weapon5_x.bmp");
	
	accessoryList.game=this;
	loadImage(&accessoryList,"./item/empty.bmp",64,64,"./item/empty_x.bmp");
	loadImage(&accessoryList,"./item/accessory1.bmp",64,64,"./item/accessory1_x.bmp");
	loadImage(&accessoryList,"./item/accessory2.bmp",64,64,"./item/accessory2_x.bmp");
	loadImage(&accessoryList,"./item/accessory3.bmp",64,64,"./item/accessory3_x.bmp");
	loadImage(&accessoryList,"./item/accessory4.bmp",64,64,"./item/accessory4_x.bmp");
	loadImage(&accessoryList,"./item/accessory5.bmp",64,64,"./item/accessory5_x.bmp");
	
	toolList.game=this;
	loadImage(&toolList,"./item/pickaxe.bmp",64,64,"./item/pickaxe_x.bmp");
	loadImage(&toolList,"./item/coin.bmp",64,64,"./item/coin_x.bmp");
	loadImage(&toolList,"./item/saint.bmp",64,64,"./item/saint_x.bmp");
	loadImage(&toolList,"./item/metal_red.bmp",64,64,"./item/metal_x.bmp");
	loadImage(&toolList,"./item/metal_blue.bmp",64,64,"./item/metal_x.bmp");
	loadImage(&toolList,"./item/potion.bmp",64,64,"./item/potion_x.bmp");
	loadImage(&toolList,"./item/immune.bmp",64,64,"./item/immune_x.bmp");
	
	itemList.game=this;
	loadImage(&itemList,"./item/empty.bmp",32,32,"./item/empty_x.bmp");
	loadImage(&itemList,"./item/weapon1.bmp",32,32,"./item/weapon_x.bmp");
	loadImage(&itemList,"./item/weapon2.bmp",32,32,"./item/weapon_x.bmp");
	loadImage(&itemList,"./item/weapon3.bmp",32,32,"./item/weapon_x.bmp");
	loadImage(&itemList,"./item/weapon4.bmp",32,32,"./item/weapon4_x.bmp");
	loadImage(&itemList,"./item/weapon5.bmp",32,32,"./item/weapon5_x.bmp");
	loadImage(&itemList,"./item/accessory1.bmp",32,32,"./item/accessory1_x.bmp");
	loadImage(&itemList,"./item/accessory2.bmp",32,32,"./item/accessory2_x.bmp");
	loadImage(&itemList,"./item/accessory3.bmp",32,32,"./item/accessory3_x.bmp");
	loadImage(&itemList,"./item/accessory4.bmp",32,32,"./item/accessory4_x.bmp");
	loadImage(&itemList,"./item/accessory5.bmp",32,32,"./item/accessory5_x.bmp");
	loadImage(&itemList,"./item/saint.bmp",32,32,"./item/saint_x.bmp");
	loadImage(&itemList,"./item/pickaxe.bmp",32,32,"./item/pickaxe_x.bmp");
	loadImage(&itemList,"./item/coin.bmp",32,32,"./item/coin_x.bmp");
	loadImage(&itemList,"./item/metal_red.bmp",32,32,"./item/metal_x.bmp");
	loadImage(&itemList,"./item/metal_blue.bmp",32,32,"./item/metal_x.bmp");
	loadImage(&itemList,"./item/potion.bmp",32,32,"./item/potion_x.bmp");
	loadImage(&itemList,"./item/immune.bmp",32,32,"./item/immune_x.bmp");
	
}
int Game::calcDamage(Player* player,Monster* enemy,int assume){
	int atk=assume==-1?player->calcAtk():assume;
	int imp=10000000;
	if ((enemy->spc>>9)&1) return (player->hp-1)*(player->immune?0.1:1);
	int me_to_enemy=atk-enemy->def;
	if (me_to_enemy>1 && ((enemy->spc>>0)&1)) me_to_enemy=1;
	if (me_to_enemy<=0) return imp;
	int enemy_to_me=enemy->atk-player->calcDef();
	if ((enemy->spc>>1)&1) enemy_to_me=enemy->atk;
	if (enemy_to_me<=0) return 0;
	int turn=(enemy->hp-1)/me_to_enemy;
	if ((enemy->spc>>2)&1) turn*=2;
	if ((enemy->spc>>3)&1) turn*=4;
	int dmg=turn*enemy_to_me-player->calcMag();
	if (dmg<0) dmg=0;
	return dmg;
}
int Game::calcNextAtk(Player* player,Monster* enemy){
	int org=Game::calcDamage(player,enemy);
	if (org==0) return 0;
	int imp=10000000,l=player->calcAtk(),r=imp,ans=imp;
	while (l<=r){
		int mid=(l+r)/2;
		if (Game::calcDamage(player,enemy,mid)<org){
			ans=mid;r=mid-1;
		}else l=mid+1;
	}
	if (ans==imp) return imp;
	else return ans-player->calcAtk();
}
string getrar(string s){
	if (s=="") return "_";
	for (int i=0;i<(int)s.size();++i){
		if (s[i]==' ') s[i]='_';
	}
	return s;
}
string derar(string s){
	if (s=="_") return "";
	for (int i=0;i<(int)s.size();++i){
		if (s[i]=='_') s[i]=' ';
	}
	return s;
}
string Game::getTime(int tp){
	time_t now=time(0);
	tm *ltm=localtime(&now);
	string res;
	if (tp==0){
		res=to_string(1900+ltm->tm_year)+"/"+to_string(1+ltm->tm_mon)+"/"+to_string(ltm->tm_mday)+"-"+
				   to_string(ltm->tm_hour)+":"+to_string(ltm->tm_min)+":"+to_string(ltm->tm_sec);		
	}else{
		res=to_string(1900+ltm->tm_year)+"-"+to_string(1+ltm->tm_mon)+"-"+to_string(ltm->tm_mday)+"-"+
				   to_string(ltm->tm_hour)+"-"+to_string(ltm->tm_min)+"-"+to_string(ltm->tm_sec);		
	}
	return res;
}
int getmax(int x,int y){
	return x>y?x:y;
}
int getmin(int x,int y){
	return x<y?x:y;
}
void Game::workTool(){
	vector <string> txt;txt.clear();
	vector <int> tid;tid.clear();
	vector <int> num;num.clear();
	vector <string> name;name.clear();
	if (player->pickaxe){
		txt.push_back(ds({"Press 1 to break a wall in front of you","�� 1 �Ƴ���ǰ��һ��ǽ"}));
		tid.push_back(0);
		num.push_back(player->pickaxe);
		name.push_back(ds({"Pickaxe","��ǽ��"}));
	}
	if (player->gold){
		txt.push_back(ds({"You can always gain double soul","��ʼ�տ��Ի��˫�������"}));
		tid.push_back(1);
		num.push_back(-1);
		name.push_back(ds({"Soul Coin","�����"}));
	}
	if (player->saint){
		txt.push_back(ds({"Press 5 to double your HP","�� 5 ʹ�������ֵ����"}));
		tid.push_back(2);
		num.push_back(player->saint);
		name.push_back(ds({"Holy Water","ʥˮ"}));
	}
	if (player->metal){
		txt.push_back(ds({"Press 2 to upgrade your final-weapon","�� 2 ���������������"}));
		tid.push_back(3);
		num.push_back(player->metal);
		name.push_back(ds({"Magic Metal","ħ������"}));
	}
	if (player->crystal){
		txt.push_back(ds({"Press 3 to upgrade your final-accessory","�� 3 �������������Ʒ"}));
		tid.push_back(4);
		num.push_back(player->crystal);
		name.push_back(ds({"Magic Crystal","ħ��ˮ��"}));
	}
	if (player->potion){
		txt.push_back(ds({"Press 4 to remove any negative affect","�� 4 ������и���Ч��"}));
		tid.push_back(5);
		num.push_back(player->potion);
		name.push_back(ds({"Great Potion","���ܽ�ҩ"}));		
	}
	if (player->immune){
		txt.push_back(ds({"Any pinch/field/poison damage will reduce by 90%","���мл�/����/�綾�˺�����90%"}));
		tid.push_back(6);
		num.push_back(-1);
		name.push_back(ds({"Earth Necklace","�������"}));		
	}
	if (tid.empty()){
		info=ds({"You do not have any tools","��û���κε���"});
		return;
	}
	int nsave=tid.size();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		refresh();
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			if (i==msave) uiList.draw(7,xpos,ypos);
			toolList.draw(tid[i],xpos,ypos,-1,1);
			settextstyle(16*rate,0,font.c_str());
			settextcolor(WHITE);
			setbkmode(TRANSPARENT);
			int h=textheight(_T("����"));
			drawText(xpos,ypos+110,name[i]+(num[i]!=-1?" ("+to_string(num[i])+")":""));
			drawText(xpos+h,ypos+110,txt[i]);
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE) || press('T')) break;
		}
		if (press(VK_ESCAPE) || press(' ') || press('T')) return;
	}	
}
void Game::workWeapon(){
	int nsave=player->wBag.size();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		refresh();
		for (int i=0;i<nsave;++i){
			if (player->wBag[i]==player->weapon) msave=i,mpage=i/5;
		}
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			player->wBag[i]->drawWeapon(this,xpos,ypos,1);
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE) || press('Q')) break;
		}
		player->weapon=player->wBag[msave];
		if (press(VK_ESCAPE) || press(' ') || press('Q')) return;
	}	
}
void Game::workAccessory(){
	int nsave=player->aBag.size();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		refresh();
		for (int i=0;i<nsave;++i){
			if (player->aBag[i]==player->accessory) msave=i,mpage=i/5;
		}
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			player->aBag[i]->drawAccessory(this,xpos,ypos,1);
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE) || press('E')) break;
		}
		player->accessory=player->aBag[msave];
		if (press(VK_ESCAPE) || press(' ') || press('E')) return;
	}	
}
void Game::workSave(){
	takeScreenShot();
	ifstream all("./save/savelist.ini");
	int nsave;all>>nsave;
	vector <string> saves;saves.resize(nsave);
	vector <string> times;times.resize(nsave);
	for (int i=0;i<nsave;++i){
		all>>saves[i];
		ifstream cur(saves[i]);
		cur>>times[i];
		cur.close();
	}
	saves[0]="./save/save"+to_string(nsave)+".sav";
	times[0]="?/?/?-??:??:??";
	all.close();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		cleardevice();
		cgList.draw(0,0,0);
		uiList.draw(5,20,170);
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			if (msave==i) uiList.draw(7,xpos,ypos);
			else uiList.draw(8,xpos,ypos);
			IMAGE tmp;
			if (i!=0){
				loadimage(&tmp,(saves[i]+".png").c_str(),60*rate,60*rate);
				putimage((ypos+2)*rate,(xpos+2)*rate,&tmp);				
			}
			settextstyle(24*rate,0,font.c_str());
			settextcolor(WHITE);
			setbkmode(TRANSPARENT);
			int h=textheight(_T("����"));
			drawText(xpos,ypos+110,times[i]);
			if (i==0){
				settextcolor(LIGHTGREEN);
				drawText(xpos+h,ypos+110,ds({"Create New","�½��浵"}));
			}
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE)) break;
		}
		if (press(VK_ESCAPE)) return;
		if (press(' ')){
			ofstream all("./save/savelist.ini");
			all<<nsave+(msave==0)<<endl;
			all<<"./save/quicksave.sav"<<endl;
			for (int i=(msave!=0);i<nsave;++i){
				all<<saves[i]<<endl;
			}
			all.close();
			save(saves[msave]);
			return;
		}
	}	
}
void Game::workLoad(){
	ifstream all("./save/savelist.ini");
	int nsave;all>>nsave;
	vector <string> saves;saves.resize(nsave);
	vector <string> times;times.resize(nsave);
	for (int i=0;i<nsave;++i){
		all>>saves[i];
		ifstream cur(saves[i]);
		cur>>times[i];
		cur.close();
	}
	all.close();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		cleardevice();
		cgList.draw(0,0,0);
		uiList.draw(5,20,170);
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			if (msave==i) uiList.draw(7,xpos,ypos);
			else uiList.draw(8,xpos,ypos);
			IMAGE tmp;
			loadimage(&tmp,(saves[i]+".png").c_str(),60*rate,60*rate);
			putimage((ypos+2)*rate,(xpos+2)*rate,&tmp);
			settextstyle(24*rate,0,font.c_str());
			settextcolor(WHITE);
			setbkmode(TRANSPARENT);
			int h=textheight(_T("����"));
			drawText(xpos,ypos+110,times[i]);
			if (i==0){
				settextcolor(LIGHTGREEN);
				drawText(xpos+h,ypos+110,ds({"Load Autosave","��ȡ���ٴ浵"}));
			}
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE)) break;
		}
		if (press(VK_ESCAPE)) return;
		if (press(' ')){
			load(saves[msave]);
			return;
		}
	}	
}
int Game::load(string s){
	mapnow.loadMap(this);
	ifstream dat(s);
	if (!dat.is_open()){
		cerr<<"Load Failed"<<endl;
		return 0;
	}
	string times;dat>>times;
	int ver;dat>>ver;
	dat>>player->atk>>player->def>>player->hp>>player->mag;
	dat>>player->lvl>>player->star;
	dat>>player->nowf>>player->nowx>>player->nowy>>player->dir;
	dat>>player->ykey>>player->bkey>>player->rkey>>player->gkey;
	dat>>player->metal>>player->crystal>>player->upgrade;
	if (ver>=5) dat>>player->soul>>shopCost; else player->soul=0,shopCost=1;
	if (ver>=6) dat>>player->gold>>player->pickaxe; else player->gold=player->pickaxe=0;
	if (ver>=7) dat>>player->saint; else player->saint=0;
	if (ver>=8) dat>>player->poison>>player->weakness>>player->fragile; else player->poison=player->weakness=player->fragile=0;
	if (ver>=9) dat>>player->potion>>player->immune; else player->potion=player->immune=0;
		int wsize,asize,w,a;
		dat>>wsize;player->wBag.clear();player->wBag.resize(wsize);
		for (int i=0;i<wsize;++i){
			int id,atk,def,mag,lvl;string name;
			dat>>id>>name>>atk>>def>>mag>>lvl;name=derar(name);
			player->wBag[i]=new Weapon(id,atk,def,mag,name,lvl);
		}
		dat>>w;player->weapon=player->wBag[w];
		dat>>asize;player->aBag.clear();player->aBag.resize(asize);
		for (int i=0;i<asize;++i){
			int id,atk,def,mag,lvl;string name;
			dat>>id>>name>>atk>>def>>mag>>lvl;name=derar(name);
			player->aBag[i]=new Accessory(id,atk,def,mag,name,lvl);
		}	
		dat>>a;player->accessory=player->aBag[a];
	/*map*/
	int fsize;dat>>fsize;
	dat>>mapnow.floor;
	for (int i=0;i<fsize;++i){
		dat>>mapnow.floors[i]->explored;
		for (int j=0;j<13;++j){
			for (int k=0;k<13;++k){
				int id;dat>>id;
				mapnow.floors[i]->setBlock(this,j,k,id);
			}
		}
	}
	/*event*/
	int esize;dat>>esize;
	for (int i=0;i<esize;++i) dat>>trig.p[i];
	dat.close();
	info=ds({"Load sucessfully","�ɹ�����"});
	return 1;
}
void Game::save(string s){
	ofstream dat(s);
	dat<<getTime()<<endl;
	int ver=9;
	dat<<ver<<endl;;
	/*player*/
	dat<<player->atk<<" "<<player->def<<" "<<player->hp<<" "<<player->mag<<endl;
	dat<<player->lvl<<" "<<player->star<<endl;
	dat<<player->nowf<<" "<<player->nowx<<" "<<player->nowy<<" "<<player->dir<<endl;
	dat<<player->ykey<<" "<<player->bkey<<" "<<player->rkey<<" "<<player->gkey<<endl;
	dat<<player->metal<<" "<<player->crystal<<" "<<player->upgrade<<endl;
	dat<<player->soul<<" "<<shopCost<<endl;
	dat<<player->gold<<" "<<player->pickaxe<<endl;
	dat<<player->saint<<endl;
	dat<<player->poison<<" "<<player->weakness<<" "<<player->fragile<<endl;
	dat<<player->potion<<" "<<player->immune<<endl;
		/*weapon*/
		int wsize=player->wBag.size(),w=0,a=0;
		dat<<wsize<<endl;
		for (int i=0;i<wsize;++i){
			dat<<player->wBag[i]->id<<" "<<getrar(player->wBag[i]->name)<<" "<<player->wBag[i]->atk<<" "<<player->wBag[i]->def<<" "<<player->wBag[i]->mag<<" "<<player->wBag[i]->lvl<<endl;
			if (player->wBag[i]==player->weapon) w=i;
		}
		dat<<w<<endl;
		int asize=player->aBag.size();
		dat<<asize<<endl;
		for (int i=0;i<asize;++i){
			dat<<player->aBag[i]->id<<" "<<getrar(player->aBag[i]->name)<<" "<<player->aBag[i]->atk<<" "<<player->aBag[i]->def<<" "<<player->aBag[i]->mag<<" "<<player->aBag[i]->lvl<<endl;
			if (player->aBag[i]==player->accessory) a=i;
		}	
		dat<<a<<endl;
	/*map*/
	int fsize=mapnow.floors.size();
	dat<<fsize<<endl;
	dat<<mapnow.floor<<endl;
	for (int i=0;i<fsize;++i){
		dat<<mapnow.floors[i]->explored<<endl;
		for (int j=0;j<13;++j){
			for (int k=0;k<13;++k){
				dat<<mapnow.floors[i]->block[j][k]->getid()<<" ";
			}
			dat<<endl;
		}
	}
	/*event*/
	int esize=trig.p.size();
	dat<<esize<<endl;
	for (int i=0;i<esize;++i) dat<<trig.p[i]<<" ";
	dat<<endl;
	dat.close();
	saveimage((s+".png").c_str(),&screenshot);
	info=ds({"Saved","�Ѵ浵"});
}
bool Game::canUseTele(){
	if (trig.p[6]==1 && trig.p[7]==0) return 0;
	if (trig.p[35]==1 && trig.p[36]==0) return 0;
	if (trig.p[40]==1 && trig.p[41]==0) return 0;
	return 1;
}
void Game::calcScore(){
	settextstyle(16*rate,0,font.c_str());
	settextcolor(BLACK);
	setbkmode(TRANSPARENT);
	cleardevice();
	cgList.draw(1,0,0);
	int xpos=240-125,ypos=320-125;
	uiList.draw(10,xpos,ypos);
	string diff=ds({"Very Easy","����"});
	if (player->gkey==1) diff=ds({"Easy","��"});
	if (player->gkey==2) diff=ds({"Normal","��ͨ"});
	drawText(xpos+20,ypos+20,ds({"Diff: "+diff,"�Ѷȣ�"+diff}));
	string dat=to_string(player->hp);
	drawText(xpos+50,ypos+20,ds({"Hp: "+dat,"������"+dat}));
	dat=to_string(player->calcAtk())+"/"+to_string(player->calcDef())+"/"+to_string(player->calcMag());
	drawText(xpos+80,ypos+20,ds({"A/D/M: "+dat,"��/��/ħ��"+dat}));
	string key=to_string(player->ykey)+"/"+to_string(player->bkey)+"/"+to_string(player->rkey);
	drawText(xpos+110,ypos+20,ds({"Key Y/B/R: "+key,"Կ�� ��/��/�죺"+key}));
	string ending="NE";
	drawText(xpos+140,ypos+20,ds({"Ending: "+ending,"��֣�"+ending}));
	string version="Beta v1.0";
	drawText(xpos+170,ypos+20,ds({"Version: "+version,"�汾��"+version}));
	FlushBatchDraw();
	while (1);
}