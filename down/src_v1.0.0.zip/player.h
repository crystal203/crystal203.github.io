#pragma once
#include <bits/stdc++.h>
#include "game.h"
using namespace std;
class Game;
class Weapon{
public:
	int id;
	string name;
	int atk,def,mag,lvl;
	Weapon(int _id=0,int _atk=0,int _def=0,int _mag=0,string _name="",int _lvl=0){
		id=_id;atk=_atk;def=_def;mag=_mag;name=_name;lvl=_lvl;
	}
	void drawWeapon(Game *game,int xpos,int ypos,int tp=0);
	void calc();
};
class Accessory{
public:
	int id;
	string name;
	int atk,def,mag,lvl;
	Accessory(int _id=0,int _atk=0,int _def=0,int _mag=0,string _name="",int _lvl=0){
		id=_id;atk=_atk;def=_def;mag=_mag;name=_name;lvl=_lvl;
	}
	void drawAccessory(Game *game,int xpos,int ypos,int tp=0);
	void calc();
};
class Player{
public:
	int hp,atk,def,mag; //��������������������������ħ��
	int lvl,star; //�ȼ����Ǽ�
	
	int nowf,nowx,nowy; //λ��
	
	int ykey,bkey,rkey,gkey; //Կ��
	
	int metal,crystal; //ħ��������ħ��ˮ��
	int upgrade; //ͻ��
	
	int dir; //���� 0,1,2,3 ��������
	int soul; //���
	
	Weapon* weapon; //����
	vector <Weapon*> wBag; //��������
	Accessory* accessory; //��Ʒ
	vector <Accessory*> aBag; //��Ʒ����
	
	int pickaxe;
	int gold,saint;
	int potion,immune;
	
	int poison,fragile,weakness;
	
	Player(int _nowf=0,int _nowx=9,int _nowy=6,int _hp=65536,int _atk=1024-200,int _def=1024-200,int _mag=4096-500){
		hp=_hp;atk=_atk;def=_def;mag=_mag;
		lvl=1;nowf=_nowf;nowx=_nowx;nowy=_nowy;
		ykey=bkey=rkey=gkey=metal=crystal=upgrade=0;star=3;
		dir=1;
		wBag.push_back(new Weapon());
		weapon=wBag.back();
		aBag.push_back(new Accessory());
		accessory=aBag.back();
		gold=0;pickaxe=saint=0;potion=immune=0;
		poison=fragile=weakness=0;
	}
	void drawPlayer(Game *game);
	int calcAtk(){
		return (atk+weapon->atk+accessory->atk)*(weakness?0.7:1);	
	}
	int calcDef(){
		return (def+weapon->def+accessory->def)*(fragile?0.7:1);
	}
	int calcMag(){
		return mag+weapon->mag+accessory->mag;
	}
	void lvlup(int x){
		lvl+=x;
		atk+=3*x;def+=3*x;hp+=500*x;
	}
};