#include <bits/stdc++.h>
#include "game.h"
#include "console.h"

void Block::draw(Game *game){
	if (transp) game->blockList.drawBlock(0,xpos,ypos,0);
	game->blockList.drawBlock(id,xpos,ypos,tp);
}
int Block::encounter(Game *game){
	return crossable;
}	
int Block::getid(){
	return id*100+tp;
}
Monster::Monster(int _xpos,int _ypos,int _fpos,int _idx,int _atk,int _def,int _hp,int _spc){
	xpos=_xpos;ypos=_ypos;fpos=_fpos;id=99;crossable=3;tp=_idx;transp=1;
	atk=_atk;def=_def;hp=_hp;spc=_spc;idx=_idx;frame=0;
}
void Monster::draw(Game *game){
	game->blockList.drawBlock(0,xpos,ypos,0);
	game->enemyList.drawBlock(idx,xpos,ypos,frame);
	if (game->showTag){
		int dmg=game->calcDamage(game->player,this);
		string sdmg=to_string(dmg);
		if (dmg==10000000) sdmg="?";
		setbkmode(TRANSPARENT);
		settextstyle(12*game->rate,0,"Arial");
		LOGFONT f;gettextstyle(&f);f.lfWeight=900;settextstyle(&f);
		if (sdmg=="?") settextcolor(LIGHTRED);
		else if (dmg==0) settextcolor(LIGHTGREEN);
		else if (dmg>=game->player->hp) settextcolor(LIGHTRED);
		else if (dmg>=game->player->hp/2) settextcolor(RGB(255,128,0));
		else if (dmg>=game->player->hp/5) settextcolor(YELLOW);
		else settextcolor(WHITE);
		game->drawText(20+32*(xpos+1)-textheight(sdmg.c_str())/game->rate,170+32*(ypos+1)-textwidth(sdmg.c_str())/game->rate,sdmg.c_str());
		settextcolor(WHITE);
		int natk=game->calcNextAtk(game->player,this);
		string snatk=to_string(natk);
		if (natk==10000000) snatk="?";
		game->drawText(20+32*(xpos+1)-2*textheight(snatk.c_str())/game->rate,170+32*(ypos+1)-textwidth(snatk.c_str())/game->rate,snatk.c_str());
	
		gettextstyle(&f);f.lfWeight=0;settextstyle(&f);		
	}
}
void Monster::animate(Game *game,int x){
	frame=!frame;
}
void Monster::special(Game *game,int arg){
	game->enemyList.drawBlock(idx,arg*2-1,1,frame,1);
	settextcolor(WHITE);
	setbkmode(TRANSPARENT);
	int xpos=20+32*(arg*2-1),ypos=170+96;
	settextstyle(12*game->rate,0,game->font.c_str());
	int h=textheight(_T("����"));
	game->drawText(xpos,ypos,game->ds(MonName[idx]));
	game->drawText(xpos+h,ypos,game->ds({"Hp","����"}));
	game->drawText(xpos,ypos+110,game->ds({"Atk","����"}));
	game->drawText(xpos+h,ypos+110,game->ds({"Def","����"}));
	string sspc="";
	if ((spc>>0)&1) sspc=sspc+game->ds({"Firm","��� "});
	if ((spc>>1)&1) sspc=sspc+game->ds({"Magic","ħ�� "});
	if ((spc>>2)&1) sspc=sspc+game->ds({"Double","������ "});
	if ((spc>>3)&1) sspc=sspc+game->ds({"Quad","������ "});
	if ((spc>>4)&1) sspc=sspc+game->ds({"Pinch","�л� "});
	if ((spc>>5)&1) sspc=sspc+game->ds({"Field","���� "});
	if ((spc>>6)&1) sspc=sspc+game->ds({"Weakness","���� "});
	if ((spc>>7)&1) sspc=sspc+game->ds({"Fragile","���� "});
	if ((spc>>8)&1) sspc=sspc+game->ds({"Poison","�綾 "});
	if ((spc>>9)&1) sspc=sspc+game->ds({"Explode","�Ա� "});
	game->drawText(xpos,ypos+220,sspc);
	game->drawText(xpos+h,ypos+220,game->ds({"Dmg","�˺�"}));
	settextstyle(14*game->rate,0,"Arial");
	LOGFONT f;gettextstyle(&f);f.lfWeight=900;settextstyle(&f);
	settextcolor(LIGHTMAGENTA);
	game->drawText(xpos+h,ypos+45,to_string(hp));
	settextcolor(LIGHTRED);
	game->drawText(xpos,ypos+155,to_string(atk));
	settextcolor(RGB(145,199,215));
	game->drawText(xpos+h,ypos+155,to_string(def));
	int dmg=game->calcDamage(game->player,this);
	string sdmg=to_string(dmg);
	if (dmg==10000000) sdmg="?";
	if (sdmg=="?") settextcolor(RGB(200,0,0));
	else if (dmg==0) settextcolor(LIGHTGREEN);
	else if (dmg>=game->player->hp) settextcolor(RGB(200,0,0));
	else if (dmg>=game->player->hp/2) settextcolor(RGB(181,125,38));
	else if (dmg>=game->player->hp/5) settextcolor(YELLOW);	
	else settextcolor(WHITE);
	game->drawText(xpos+h,ypos+265,sdmg);
	gettextstyle(&f);f.lfWeight=0;settextstyle(&f);
}
int Monster::encounter(Game *game){
	int dmg=game->calcDamage(game->player,this);
	if (dmg<game->player->hp){
		game->player->hp-=dmg;
		if (game->trig.p[1]==0){
			hp=0;game->trig.p[1]=1;
			return 0;
		}
		if (idx==0 && game->trig.p[55]==0){
			hp=0;game->trig.p[55]=1;
			return 0;
		}
		if (game->language==1) game->info="�������"+MonName[idx].cn+"��ʧȥ"+to_string(dmg)+"����ֵ��";
		else game->info="You defeated "+MonName[idx].en+", losing "+to_string(dmg)+" Hp.";
		if ((spc>>6)&1) game->player->weakness=1;
		if ((spc>>7)&1) game->player->fragile=1;
		if ((spc>>8)&1) game->player->poison=1;
		if (fpos>=11) game->player->soul+=1+game->player->gold;
		game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
		return 1;
	}else{
		game->info=game->ds({"You can not defeat it.","���޷���������"});return 0;
	}
}
int BlockGem::encounter(Game *game){
	if (col==0){
		if (lvl==0) game->player->atk+=1;
		if (lvl==1) game->player->atk+=3;
		if (lvl==2) game->player->atk+=5;
		game->info=game->ds({"Attack Point improved!","����˹�������ʯ������������"});
	}else if (col==1){
		if (lvl==0) game->player->def+=1;
		if (lvl==1) game->player->def+=3;
		if (lvl==2) game->player->def+=5;
		game->info=game->ds({"Defence Point improved!","����˷�������ʯ������������"});
	}else if (col==2){
		if (lvl==0) game->player->mag+=5;
		if (lvl==1) game->player->mag+=15;
		if (lvl==2) game->player->mag+=25;
		game->info=game->ds({"Magic Defence Point improved!","�������������ʯ��ħ��������"});
	}else if (col==3){
		if (lvl==0) game->player->lvlup(1);
		if (lvl==1) game->player->lvlup(2);
		if (lvl==2) game->player->lvlup(3);
		game->info=game->ds({"Level up!","������λþ���ʯ���ȼ�������"});
	}else game->player->lvlup(5),game->info=game->ds({"Level up!","����˴�˵����ʯ���ȼ������������"});
	game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
	return 1;
}
int BlockHp::encounter(Game *game){
	if (tp==0) game->player->hp+=200;
	else if (tp==1) game->player->hp+=500;
	else if (tp==2) game->player->hp+=1500;
	else game->player->hp+=3000;
	game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
	game->info=game->ds({"Hp Recovered!","����������ᾧ���ظ�������"});
	return 1;
}
int BlockKey::encounter(Game *game){
	if (tp==0) game->player->ykey++,game->info=game->ds({"You get a Yellow Key!","����˻�Կ��"});
	else if (tp==1) game->player->bkey++,game->info=game->ds({"You get a Blue Key!","�������Կ��"});
	else if (tp==2) game->player->rkey++,game->info=game->ds({"You get a Red Key!","����˺�Կ��"});
	else game->player->gkey++,game->info=game->ds({"You get a Green Key!","�������Կ��"});
	game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
	return 1;
}
void BlockDoor::draw(Game *game){
	game->blockList.drawBlock(0,xpos,ypos,0);
	game->blockList.drawBlock(id,xpos,ypos,frame);
}
void BlockDoor::animate(Game *game,int x){
	if (x==0){
		frame=0;
		for (int i=0;i<3;++i){
			frame++;game->refresh();Sleep(50);
		}		
	}else{
		frame=3;
		for (int i=0;i<3;++i){
			frame--;game->refresh();Sleep(50);
		}		
	}
}
int BlockDoor::encounter(Game *game){
	switch (id){
		case 5:{
			if (game->player->ykey){
				game->player->ykey--;
				animate(game);
				game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
				game->info=game->ds({"You opened a Yellow Door.","�����һ�Ȼ��š�"});
			}	
			break;
		}
		case 6:{
			if (game->player->bkey){
				game->player->bkey--;
				animate(game);
				game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
				game->info=game->ds({"You opened a Blue Door.","�����һ�����š�"});
			}	
			break;
		}
		case 7:{
			if (game->player->rkey){
				game->player->rkey--;
				animate(game);
				game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
				game->info=game->ds({"You opened a Red Door.","�����һ�Ⱥ��š�"});
			}		
			break;
		}
		case 8:{
			if (game->player->gkey){
				game->player->gkey--;
				animate(game);
				game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
				game->info=game->ds({"You opened a Green Door.","�����һ�����š�"});
			}		
			break;
		}
	}
	return 0;
}
void BlockButton::special(Game *game,int arg){
	if (tp==0) tp=1;
}
int BlockButton::encounter(Game *game){
	game->info=game->ds({"You pushed a button.","��ȵ���һ����ť��"});
	return 1;
}
int BlockNPC::getid(){
	return 9700+id;
}
void BlockNPC::draw(Game *game){
	game->blockList.drawBlock(0,xpos,ypos,0);
	game->charList.drawBlock(id,xpos,ypos);	
}	
int BlockNPC::encounter(Game *game){
	switch (id){
		case 4:{
			if (game->trig.p[18]==0){
				game->trig.p[18]=1;
				game->article("./text/event8.txt");
				game->mapnow.floors[6]->block[2][4]->animate(game);
				game->mapnow.floors[6]->block[2][4]=new BlockFloor(2,4,6);
			}else if (game->trig.p[31]==0){
				game->trig.p[31]=1;
				game->article("./text/event11.txt");
				game->mapnow.floors[1]->block[11][6]=new BlockDoor(11,6,1,7);
				game->mapnow.floors[1]->block[12][6]=new BlockStair(12,6,1,5);
				game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
				game->mapnow.floors[11]->setBlock(game,3,7,9704);
			}else{
				if (game->shopCost>game->player->soul){
					game->dialog.showDialog(game,{"I need "+to_string(game->shopCost)+" Soul to strengthen you","����Ҫ"+to_string(game->shopCost)+"��������Ϊ����������"},YUNA,YUNA_NORMAL);
					while (!press(' '));
					game->dialog.hideDialog(game);
					while (press(' '));
				}else{
					game->dialog.showDialog(game,{"Cost "+to_string(game->shopCost)+"=[1]3 Atk [2]3 Def [3]1200 Hp [0]Cancel",to_string(game->shopCost)+"���=[1]3���� [2]3���� [3]1200���� [0]ȡ��"},YUNA,YUNA_SMILE);
					while (1){
						if (press('1')){
							game->player->soul-=game->shopCost;
							game->player->atk+=3;
							game->shopCost++;
							break;
						}
						if (press('2')){
							game->player->soul-=game->shopCost;
							game->shopCost++;
							game->player->def+=3;
							break;
						}
						if (press('3')){
							game->player->soul-=game->shopCost;
							game->shopCost++;
							game->player->hp+=1200;
							break;
						}
						if (press(' ') || press('0') || press(VK_ESCAPE)){
							break;
						}
					}
					game->dialog.hideDialog(game);
					while (press(' ') || press('0') || press(VK_ESCAPE) || press('1') || press('2') || press('3'));
				}
			}
			break;
		}
	}
	return 0;
}
int BlockItem::getid(){
	return 9800+id;
}
void BlockItem::draw(Game *game){
	game->blockList.drawBlock(0,xpos,ypos,0);
	game->itemList.drawBlock(id,xpos,ypos);	
}
int BlockItem::encounter(Game *game){
	switch (id){
		case 1:{
			game->player->wBag.push_back(new Weapon(1,10,0,0,game->ds({"Scythe","����"})));
			game->info=game->ds({"You get a new weapon. Press Q to equip.","������һ���������� Q ��������װ��ҳ�档"});
			break;
		}
		case 2:{
			game->player->wBag.push_back(new Weapon(2,20,5,0,game->ds({"Gold Scythe","�ƽ�����"})));
			game->info=game->ds({"You get a new weapon. Press Q to equip.","������һ���������� Q ��������װ��ҳ�档"});
			break;		
		}
		case 3:{
			game->player->wBag.push_back(new Weapon(3,40,10,0,game->ds({"Diamond Scythe","��ʯ����"})));
			game->info=game->ds({"You get a new weapon. Press Q to equip.","������һ���������� Q ��������װ��ҳ�档"});
			break;		
		}
		case 4:{
			game->player->wBag.push_back(new Weapon(4,80,20,80,game->ds({"Soul Scythe","�������"})));
			game->info=game->ds({"You get a new weapon. Press Q to equip.","������һ���������� Q ��������װ��ҳ�档"});
			break;		
		}
		case 5:{
			game->player->wBag.push_back(new Weapon(5,160,40,250,game->ds({"Unchained","���ƽ���"})));
			game->info=game->ds({"You get a new weapon. Press Q to equip.","������һ���������� Q ��������װ��ҳ�档"});
			break;		
		}
		case 6:{
			game->player->aBag.push_back(new Accessory(1,0,10,0,game->ds({"Obsidian Necklace","����ʯ����"})));
			game->info=game->ds({"You get a new accessory. Press E to equip.","������һ����Ʒ���� E ������Ʒװ��ҳ�档"});
			break;
		}
		case 7:{
			game->player->aBag.push_back(new Accessory(2,5,20,0,game->ds({"Necklace of Desire","��������"})));
			game->info=game->ds({"You get a new accessory. Press E to equip.","������һ����Ʒ���� E ������Ʒװ��ҳ�档"});
			break;
		}
		case 8:{
			game->player->aBag.push_back(new Accessory(3,10,40,0,game->ds({"Frost Flower Ring","˪��ָ��"})));
			game->info=game->ds({"You get a new accessory. Press E to equip.","������һ����Ʒ���� E ������Ʒװ��ҳ�档"});
			break;
		}
		case 9:{
			game->player->aBag.push_back(new Accessory(4,20,80,80,game->ds({"Earring of Worship","��ݶ���"})));
			game->info=game->ds({"You get a new accessory. Press E to equip.","������һ����Ʒ���� E ������Ʒװ��ҳ�档"});
			break;
		}
		case 10:{
			game->player->aBag.push_back(new Accessory(5,40,160,250,game->ds({"Ice Queen Ring","��ѩŮ��ָ��"})));
			game->info=game->ds({"You get a new accessory. Press E to equip.","������һ����Ʒ���� E ������Ʒװ��ҳ�档"});
			break;
		}
		case 11:{
			game->player->saint++;
			game->info=game->ds({"You get the Holy Water.","������ʥˮ��"});
			break;
		}
		case 12:{
			game->player->pickaxe++;
			game->info=game->ds({"You get the Pickaxe.","�����˸��ӡ�"});
			break;
		}
		case 13:{
			game->player->gold=1;
			game->info=game->ds({"You get the Soul Coin. You can gain double soul.","����������ң�֮���õ���귭����"});
			break;
		}
		case 14:{
			game->player->metal++;
			game->info=game->ds({"You get a Magic Metal.","������һ��ħ��������"});
			break;
		}
		case 15:{
			game->player->crystal++;
			game->info=game->ds({"You get a Magic Crystal.","������һ��ħ��ˮ����"});
			break;
		}
		case 16:{
			game->player->potion++;
			game->info=game->ds({"You get the Great Potion.","���������ܽ�ҩ��"});
			break;
		}
		case 17:{
			game->player->immune=1;
			game->info=game->ds({"You get the Earth Necklace.","�����˴��������"});
			break;
		}
	}
	game->mapnow.floors[fpos]->block[xpos][ypos]=new BlockFloor(xpos,ypos,fpos);
	return 1;
}
void Floor::calcPinch(Game *game){
	for (int i=0;i<13;++i){
		for (int j=0;j<13;++j){
			block[i][j]->pinch=block[i][j]->dmg=0;
		}
	}
	for (int i=1;i<12;++i){
		for (int j=1;j<12;++j){
			if (block[i][j]->id==99){
				int spc=MonSpc[block[i][j]->tp];
				if ((spc>>4)&1){
					block[i-1][j]->pinch+=1;
					block[i+1][j]->pinch+=2;
					block[i][j-1]->pinch+=4;
					block[i][j+1]->pinch+=8;
				}
				if ((spc>>5)&1){
					int dmg=0;
					if (block[i][j]->tp==26) dmg=100;
					if (block[i][j]->tp==27) dmg=300;
					block[i-1][j]->dmg+=dmg;
					block[i+1][j]->dmg+=dmg;
					block[i][j-1]->dmg+=dmg;
					block[i][j+1]->dmg+=dmg;
					if (block[i][j]->tp==27){
						block[i-1][j-1]->dmg+=dmg;
						block[i+1][j-1]->dmg+=dmg;
						block[i-1][j+1]->dmg+=dmg;
						block[i+1][j+1]->dmg+=dmg;
					}
				}
			}
		}
	}
	for (int i=0;i<13;++i){
		for (int j=0;j<13;++j){
			int pinch=0;
			if (((block[i][j]->pinch>>0)&1) && ((block[i][j]->pinch>>1)&1)) pinch++;
			if (((block[i][j]->pinch>>2)&1) && ((block[i][j]->pinch>>3)&1)) pinch++;
			if (pinch==1) block[i][j]->dmg+=game->player->hp/2;
			if (pinch==2) block[i][j]->dmg+=game->player->hp*3/4;
		}
	}
}
void Floor::draw(Game *game){
	calcPinch(game);
	setbkmode(TRANSPARENT);
	for (int i=0;i<13;++i){
		for (int j=0;j<13;++j){
			block[i][j]->draw(game);
			settextstyle(12*game->rate,0,"Arial");
			LOGFONT f;gettextstyle(&f);f.lfWeight=900;settextstyle(&f);
			int pinch=0;
			if (((block[i][j]->pinch>>0)&1) && ((block[i][j]->pinch>>1)&1)) pinch++;
			if (((block[i][j]->pinch>>2)&1) && ((block[i][j]->pinch>>3)&1)) pinch++;
			int dmg=block[i][j]->dmg;
			if (game->player->immune) dmg*=0.1;
			if (dmg==0) continue;
			
			string sdmg=to_string(dmg);
			if (dmg==0) settextcolor(LIGHTGREEN);
			else if (dmg>=game->player->hp) settextcolor(RGB(200,0,0));
			else if (dmg>=game->player->hp/2) settextcolor(RGB(181,125,38));
			else if (dmg>=game->player->hp/5) settextcolor(YELLOW);	
			else settextcolor(WHITE);
			game->drawText(20+32*i+16-textheight(sdmg.c_str())/game->rate/2,170+32*j+16-textwidth(sdmg.c_str())/game->rate/2,sdmg.c_str());
		}
	}
	LOGFONT f;gettextstyle(&f);f.lfWeight=0;settextstyle(&f);
	settextcolor(WHITE);
	setbkmode(TRANSPARENT);
	settextstyle(24*game->rate,0,game->font.c_str());
	game->drawText(20,170,name);
}
void Floor::doAnimate(Game *game){
	for (int i=0;i<13;++i){
		for (int j=0;j<13;++j){
			if (block[i][j]->id==99){
				block[i][j]->animate(game);
			}
		}
	}
}
int Floor::findMonster(Game *game,int tp){
	int cnt=0;
	map <int,int> mp;
	for (int i=0;i<13;++i){
		for (int j=0;j<13;++j){
			if (block[i][j]->id==99 && !mp.count(block[i][j]->tp)){
				mp[block[i][j]->tp]=1;
				if (tp==1 && game->mpage==cnt/6) block[i][j]->special(game,cnt-game->mpage*6+1);
				cnt++;
			}
		}
	}
	return cnt;
}
void Floor::setBlock(Game *game,int i,int j,int id){
	int idx=id/100,idy=id%100;
	switch (idx){
		case 0:{ //floor
			block[i][j]=new BlockFloor(i,j,floor);
			break;
		}
		case 1:{ //wall
			block[i][j]=new BlockWall(i,j,floor,idy);
			break;
		}
		case 2:{ //gem
			block[i][j]=new BlockGem(i,j,floor,idy);
			break;
		}
		case 3:{ //hp
			block[i][j]=new BlockHp(i,j,floor,idy);
			break;
		}
		case 4:{ //key
			block[i][j]=new BlockKey(i,j,floor,idy);
			break;
		}
		case 5:case 6:case 7:case 8:case 9:case 10:{ //door
			block[i][j]=new BlockDoor(i,j,floor,idx);
			break;
		}
		case 11:{ //stair
			block[i][j]=new BlockStair(i,j,floor,idy);
			break;
		}
		case 12:{ //button
			block[i][j]=new BlockButton(i,j,floor,idy);					
			break;
		}
		case 13:{ //arrow
			block[i][j]=new BlockArrow(i,j,floor,idy);					
			break;
		}
		case 97:{ //npc
			block[i][j]=new BlockNPC(i,j,floor,idy);
			break;
		}
		case 98:{ //item
			block[i][j]=new BlockItem(i,j,floor,idy);
			break;
		}
		case 99:{ //monster
			block[i][j]=new Monster(i,j,floor,idy,MonAtk[idy],MonDef[idy],MonHp[idy],MonSpc[idy]);
			break;
		}
	}
}
void Floor::loadFloor(Game* game,string s){
	ifstream mp(s);
	string cn,en;
	getline(mp,cn);getline(mp,en);
	if (game->language==0) name=en;
	else name=cn;
	for (int i=0;i<13;++i){
		for (int j=0;j<13;++j){
			int id;mp>>id;
			setBlock(game,i,j,id);
		}
	}
}
void Map::loadMap(Game* game,int _floor){
	floor=_floor;
	floors.clear();
	floors.push_back(new Floor(0,9,6,0));floors[0]->loadFloor(game,"./map/0.map");
	floors.push_back(new Floor(1,10,6,1));floors[1]->loadFloor(game,"./map/1.map");
	floors.push_back(new Floor(2,11,6,1));floors[2]->loadFloor(game,"./map/2.map");
	floors.push_back(new Floor(3,6,11,1));floors[3]->loadFloor(game,"./map/3.map");
	floors.push_back(new Floor(4,6,1,1));floors[4]->loadFloor(game,"./map/4.map");
	floors.push_back(new Floor(5,11,6,1));floors[5]->loadFloor(game,"./map/5.map");
	floors.push_back(new Floor(6,1,7,1));floors[6]->loadFloor(game,"./map/6.map");
	floors.push_back(new Floor(7,2,4,1));floors[7]->loadFloor(game,"./map/7.map");
	floors.push_back(new Floor(8,10,4,1));floors[8]->loadFloor(game,"./map/8.map");
	floors.push_back(new Floor(9,11,1,1));floors[9]->loadFloor(game,"./map/9.map");
	floors.push_back(new Floor(10,10,6,1));floors[10]->loadFloor(game,"./map/10.map");
	floors.push_back(new Floor(11,1,6,1));floors[11]->loadFloor(game,"./map/11.map");
	floors.push_back(new Floor(12,1,6,1));floors[12]->loadFloor(game,"./map/12.map");
	floors.push_back(new Floor(13,6,11,1));floors[13]->loadFloor(game,"./map/13.map");
	floors.push_back(new Floor(14,6,1,1));floors[14]->loadFloor(game,"./map/14.map");
	floors.push_back(new Floor(15,11,6,1));floors[15]->loadFloor(game,"./map/15.map");
	floors.push_back(new Floor(16,2,6,1));floors[16]->loadFloor(game,"./map/16.map");
	floors.push_back(new Floor(17,10,1,1));floors[17]->loadFloor(game,"./map/17.map");
	floors.push_back(new Floor(18,2,6,1));floors[18]->loadFloor(game,"./map/18.map");
	floors.push_back(new Floor(19,11,2,1));floors[19]->loadFloor(game,"./map/19.map");
	floors.push_back(new Floor(20,10,6,1));floors[20]->loadFloor(game,"./map/20.map");
	floors.push_back(new Floor(21,11,6,1));floors[21]->loadFloor(game,"./map/21.map");
	floors.push_back(new Floor(22,11,6,1));floors[22]->loadFloor(game,"./map/22.map");
	floors.push_back(new Floor(23,6,11,1));floors[23]->loadFloor(game,"./map/23.map");
	floors.push_back(new Floor(24,6,1,1));floors[24]->loadFloor(game,"./map/24.map");
	floors.push_back(new Floor(25,11,6,1));floors[25]->loadFloor(game,"./map/25.map");
	floors.push_back(new Floor(26,10,6,1));floors[26]->loadFloor(game,"./map/26.map");
	floors.push_back(new Floor(27,2,6,1));floors[27]->loadFloor(game,"./map/27.map");
	floors.push_back(new Floor(28,9,6,1));floors[28]->loadFloor(game,"./map/28.map");
	floors.push_back(new Floor(29,1,6,1));floors[29]->loadFloor(game,"./map/29.map");
	floors.push_back(new Floor(30,11,6,1));floors[30]->loadFloor(game,"./map/30.map");
	floors.push_back(new Floor(31,11,6,0));floors[31]->loadFloor(game,"./map/31.map");
}