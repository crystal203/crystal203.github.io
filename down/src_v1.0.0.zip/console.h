#pragma once
#include <bits/stdc++.h>
using namespace std;
#include <easyx.h>
#include <windows.h>
#include <conio.h>

#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
const int STRICT_MODE=0;
const int SLEEP_TIME=125;
enum OBJECT_TYPE{
	OBJECT,FORM,BUTTON,LABEL,OPTION,CHECKBOX,PROGRESS_BAR,LABEL_VAL,LIST,INPUTBOX
};
enum DATA_TYPE{
	_INT,_DOUBLE,_STRING
};

class Form;
class Object{
public:
	bool visible,chosen,enable;
	int xpos,ypos;
	Form* faObject;
	OBJECT_TYPE id;
	
	Object();
	virtual void print(){}
	void remove();
	void hide();
	void show();
	~Object(){}
};
struct RawText{
	string text;
	vector <int> numBuf;
	vector <string> strBuf;
	vector <double> dblBuf;	
	
	RawText(string _text="",vector <int> numBuf={},vector <string> strBuf={},vector <double> dblBuf={});
	void print(int backColor=0); 
	~RawText(); 
};
void showCursor();
void hideCursor();
void setColor(int colorID);
void clrscr();
pair <int,int> getxy();
int toHex(char c);
void getpos(POINT &pt);
void tellraw(RawText s);
void tellraw(string s);
RawText toRaw(string s);
void gotoxy(int x,int y);
void setWindowSize(string name,int width,int height);
class Form:public Object{
public:
	int width,height;
	int bgColor;
	vector <Object*> sonObjects;
	
	Form(int _xpos=0,int _ypos=0,int _width=0,int _height=0,Form* _faObject=nullptr,int _bgColor=0);
	void print();
	~Form();
};
class Button:public Object{
public:
	int width,bgColor,bgPressColor;
	bool isPress;
	RawText text;
	
	Button(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int _bgColor=0,int _bgPressColor=0);
	void print();
	int preserve();
	~Button(){}
};
class Label:public Object{
public:
	RawText text;
	
	Label(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr);
	void print();
	~Label(){}
};
class Option:public Object{
public:
	int tickColor,width;
	RawText text;
	bool isPress;
	char tickChar;
	string blockChar;
	Option(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int _tickColor=10,char _tickChar='X',string _blockChar="()");
	Option(){}
	void print();
	virtual void set(int tp=-1);
	int preserve();
	~Option(){}
};
class CheckBox:public Option{
public:
	CheckBox(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int _tickColor=10,char _tickChar='O',string _blockChar="[]");
	void set(int tp=-1);
	~CheckBox(){}
};
class ProgressBar:public Object{
public:
	int width,barColor,style,maxVal,numLen;
	RawText text;
	int* value;
	ProgressBar(RawText _text,int _xpos=0,int _ypos=0,int _width=0,Form* _faObject=nullptr,int* _value=nullptr,int _maxVal=100,int _barColor=12,int _style=0);
	void print();
	~ProgressBar(){}
};
class LabelVal:public Object{
public:
	RawText text;
	void** value;
	int maxVal;
	DATA_TYPE dataType;
	int valCol,numLen;
	
	void basicInit(RawText _text,int _xpos,int _ypos,Form* _faObject,int _valCol,int maxVal);
	LabelVal(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int* _value=nullptr,int _valCol=14,int _maxVal=-1);
	LabelVal(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,double* _value=nullptr,int _valCol=14,int _maxVal=-1);
	LabelVal(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,string* _value=nullptr,int _valCol=14,int _maxVal=-1);
	void print();
	~LabelVal(){}
};
class List:public Object{
public:
	RawText text;
	vector <RawText>* items;
	int perPage,width,isChosen,bgPressColor,nowPage;
	string pageFormat; 
	
	List(RawText _text,int _xpos=0,int _ypos=0,int _width=0,Form* _faObject=nullptr,vector <RawText>* _items=nullptr,int _perPage=5,int _bgPressColor=7,string _pageFormat="Page %d&7//%d");
	void print();
	int preserve();
	void nextPage();
	void prevPage();
	~List(){}
};
class InputBox:public Object{
public:
	RawText text;
	int width,position;
	int textColor,colorLoseFocus,newx,newy;
	string nowText;
	char pwdChar;
	bool hasFocus;
	
	InputBox(RawText _text,int _xpos=0,int _ypos=0,int _width=0,int _position=0,Form* _faObject=nullptr,int _textColor=0x8f,int _colorLoseFocus=0x7f,char _pwdChar=' ');
	void print();
	void preserve();
	~InputBox(){}
};
