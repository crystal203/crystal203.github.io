#pragma once
#include <bits/stdc++.h>
#include "dialog.h"
#include "player.h"
#include "easyx.h"
#include "block.h"
#include "event.h"
enum Character{
	HANA,CHIEF,YUNA
};
enum Emotion{
	HANA_NORMAL,
	HANA_ANGRY,HANA_CLIMAX,HANA_CONFUSED,HANA_CURIOUS,HANA_EMBARRASSED,
	HANA_EVASIVE,HANA_EXCITED,HANA_GLAD,HANA_HAPPY,HANA_HOT,
	HANA_INSIDIOUS,HANA_LOVE,HANA_SAD,HANA_SCARED,HANA_SHOCKED,
	CHIEF_NORMAL,
	YUNA_NORMAL,YUNA_SMILE
};
class dstring{
public:
	string en,cn;
	dstring(string _en="",string _cn=""){
		en=_en;cn=_cn;
	}
	~dstring(){}
};
const dstring characterName[3]={{"Hana","����"},{"Chief","����"},{"Yuna","���"}};
const int MonNum=38;
const int MonAtk[MonNum]={2048,20480,12,14,18,45,28,35,55,22,40,52,48,42,62,38,205,55,190,115,185,235,135,105,190,220,200,220,250,375,330,420,1,0,0,0,99999,1};
const int MonDef[MonNum]={512,5120,6,8,10,17,18,5,12,15,25,35,38,65,45,25,132,52,50,90,105,80,106,120,150,150,140,150,170,262,160,280,1,250,250,250,250,1};
const int MonHp[MonNum]={32768,327680,80,160,100,400,180,60,120,90,320,280,260,20,380,220,650,640,2700,520,330,375,440,440,550,380,650,700,800,2000,550,2000,1,500,500,500,150,1};
const int MonSpc[MonNum]={0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,2,0,0,0,0,8,0,4,2|4,0,0,32,32|2,16,0,8,0,0,64,128,256,2,512};
const dstring MonName[MonNum]={{"District Chief","����"},{"District Chief","����"},{"Blue Ghost Slime","��ɫ����ʷ��ķ"},
							   {"Purple Ghost Slime","��ɫ����ʷ��ķ"},{"Ghost Skeleton","��������"},{"Ghost Guard","��������"},
							   {"Ghost Armored Skeleton","������������"},{"Ghost Bat","��������"},{"Ghost Big Bat","���������"},
							   {"Ghost Mage","���鷨ʦ"},{"Magenta Ghost Slime","Ʒ������ʷ��ķ"},{"Ghost Zombie","��������"},
							   {"Ghost Captain Skeleton","�������öӳ�"},{"Ghost Stone","�����ʯ"},{"Ghost Armored Zombie","����������ʿ"},
							   {"Ghost Grand Mage","�����ʦ"},{"Ghost Advanced Guard","�����������"},{"Ghost Slimeman","����ʷ��ķ��"},
							   {"Ghost Vampire","������Ѫ��"},{"Ghost Ultimate Skeleton","�����ռ�����"},{"Ghost Swordsman","���齣ʿ"},
							   {"Ghost Warrior","�����սʿ"},{"Ghost Knight","������ʿ"},{"Ghost Advanced Knight","����߽���ʿ"},
							   {"Ghost Slime King","����ʷ��ķ��"},{"Ghost Blood Bat","����Ѫ����"},{"Ghost Witch","������ʦ"},
							   {"Ghost Great Witch","�������ʦ"},{"Ghost Bishop","��������"},{"Ghost Great Bishop","���������"},
							   {"Ghost Ultimate Knight","�����ռ���ʿ"},{"Ghost Ultimate Guard","�����ռ�����"},{"Ghost ArchMage","�����ռ���ʦ"},
							   {"Tower of Weakness","����֮��"},{"Tower of Fragile","����֮��"},{"Tower of Poisonous","�綾֮��"},
							   {"Tower of Thunder","�׵�֮��"},{"Stella Ghost Slime","�ǹ�����ʷ��ķ"}};

using namespace std;
class Game{
public:
	double rate;
	string font;
	string info;
	int language;
	Game(double _rate=1.0){
		rate=_rate;
	}
	/*assets*/
	class Image{
	public:
		IMAGE img,ximg;
		bool isTransp;
		int len;
		Image(IMAGE _img,IMAGE _ximg,bool _isTransp=0,int _len=-1){
			img=_img;
			ximg=_ximg;
			isTransp=_isTransp;
			len=_len;
		}
		~Image(){}
	};
	class ImageList{
	public:
		vector <Image*> list;
		Game* game;
		void draw(int id,int xpos,int ypos,int pid=-1,bool noBlack=0){
			if (game==nullptr){
				cerr<<"Error: No Game binding!"<<endl;
			}else if (id>=list.size()){
				cerr<<"Warn: Image ID too big!"<<endl;
			}else{
				int h,l;
				if (pid==-1){
					h=list[id]->img.getheight(),l=list[id]->img.getwidth();pid=0;
				}else{
					h=list[id]->img.getheight(),l=list[id]->len*game->rate;
				}
				if (noBlack) h--,l--;
				if (list[id]->isTransp){
					putimage((int)ypos*game->rate,(int)xpos*game->rate,l,h,&list[id]->ximg,pid*l,0,SRCERASE);
					putimage((int)ypos*game->rate,(int)xpos*game->rate,l,h,&list[id]->img,pid*l,0,SRCINVERT);
				}else{
					putimage((int)ypos*game->rate,(int)xpos*game->rate,l,h,&list[id]->img,pid*l,0);
				}
			}
		}
		void drawBlock(int id,int xpos,int ypos,int pid=-1,bool noBlack=0){
			if (game==nullptr){
				cerr<<"Error: No Game binding!"<<endl;
			}else if (id>=list.size()){
				cerr<<"Warn: Image ID too big!"<<endl;
			}else{
				xpos=20+32*(xpos+1)-list[id]->img.getheight()/game->rate;
				if (pid==-1) ypos=170+32*(ypos+1)-list[id]->img.getwidth()/game->rate;
				else ypos=170+32*(ypos+1)-list[id]->len;
				draw(id,xpos,ypos,pid,noBlack);
			}			
		}
	}uiList,emotionList,charList,blockList,enemyList,cgList,itemList,weaponList,accessoryList,toolList;
	void loadImage(ImageList* vec,string img="",int height=0,int width=0,string ximg="",int id=-1,int len=-1){
		IMAGE cimg,cximg;
		if (ximg!="") loadimage(&cximg,_T(ximg.c_str()),height*rate,width*rate);
		else loadimage(&cximg,_T("./asset/empty.bmp"));
		loadimage(&cimg,_T(img.c_str()),height*rate,width*rate);
		vec->list.push_back(new Image(cimg,cximg,ximg!="",len));
	}
	void drawText(int x,int y,string text){
		LOGFONT f;
		gettextstyle(&f);f.lfQuality=ANTIALIASED_QUALITY;settextstyle(&f);
		outtextxy(y*rate,x*rate,text.c_str());
	}
	string ds(dstring* x){
		if (language==0) return x->en;
		else return x->cn;
	}
	string ds(dstring x){
		if (language==0) return x.en;
		else return x.cn;
	}
	/*function*/
	string getTime(int tp=0);
	void refresh();
	void loadAsset();
	void save(string s);
	void workSave();
	int load(string s);
	void workLoad();
	bool canUseTele();
	void workWeapon();
	void workAccessory();
	void workTool();
	void calcScore();
	DialogText dialog;
	/*character*/
	Player* player;
	Map mapnow;
	int visible=1,mbook=0,chooseWeapon=0,chooseAccessory=0,chooseTool=0,mpage=0,tele=0,shopCost=1;
	Trigger trig;
	bool debug=0,pause=0;
	bool showTag=1;
	bool gameEnd=0;
	int calcDamage(Player* player,Monster* monster,int assume=-1);
	int calcNextAtk(Player* player,Monster* monster);
	void article(string s);
	IMAGE screenshot;
	void takeScreenShot(int tp=0);
	
	~Game(){}
};