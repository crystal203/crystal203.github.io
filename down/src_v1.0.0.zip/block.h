#pragma once
#include <bits/stdc++.h>
#include "game.h"
using namespace std;
class Game;
class dstring;
class Block{
public:
	int xpos,ypos,fpos;
	int id,tp;
	int crossable;
	int dmg,pinch;
	/*
		0=������ͨ�� 
		1=����ͨ��
		2=������ͨ��
		3=������ͨ��
	*/
	bool transp=0;
	virtual void draw(Game* game);
	virtual int encounter(Game *game);
	virtual void animate(Game *game,int x=0){}
	virtual void special(Game *game,int arg=0){}
	virtual int getid();
	Block(int _xpos=0,int _ypos=0,int _fpos=0,int _id=0,int _crossable=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=_id;crossable=_crossable;tp=0;transp=0;
	}
	~Block(){}
};
class Monster:public Block{
public:
	int atk,hp,def,spc;
	int idx,frame;
	Monster(int _xpos=0,int _ypos=0,int _fpos=0,int _idx=0,int _atk=0,int _def=0,int _hp=0,int _spc=0);
	void draw(Game *game);
	int encounter(Game *game);
	void animate(Game *game,int x=0);
	void special(Game *game,int arg=0);
	~Monster(){}
};
class BlockFloor:public Block{
public:
	BlockFloor(int _xpos=0,int _ypos=0,int _fpos=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=0;crossable=1;tp=0;transp=0;
	}
	~BlockFloor(){}
};
class BlockWall:public Block{
public:
	BlockWall(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=1;crossable=0;tp=_tp;transp=0;
	}
	~BlockWall(){}
};
class BlockGem:public Block{
public:
	int col,lvl;
	BlockGem(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=2;crossable=2;tp=_tp;transp=1;
		col=tp/3;lvl=tp%3;
	}
	int encounter(Game *game);
	~BlockGem(){}
};
class BlockHp:public Block{
public:
	BlockHp(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=3;crossable=2;tp=_tp;transp=1;
	}
	int encounter(Game *game);
	~BlockHp(){}
};
class BlockKey:public Block{
public:
	BlockKey(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=4;crossable=2;tp=_tp;transp=1;
	}
	int encounter(Game *game);
	~BlockKey(){}
};
class BlockDoor:public Block{
public:
	int frame;
	BlockDoor(int _xpos=0,int _ypos=0,int _fpos=0,int _id=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=_id;crossable=3;tp=0;transp=1;frame=0;
	}
	~BlockDoor(){}
	void draw(Game *game);
	int encounter(Game *game);
	void animate(Game *game,int x=0);
};
class BlockStair:public Block{
public:
	BlockStair(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=11;crossable=1;tp=_tp;transp=1;
	}
	~BlockStair(){}
};
class BlockButton:public Block{
public:
	BlockButton(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=12;crossable=1;tp=_tp;transp=1;
	}
	void special(Game *game,int arg=0);
	int encounter(Game *game);
	~BlockButton(){}
};
class BlockItem:public Block{
public:
	BlockItem(int _xpos=0,int _ypos=0,int _fpos=0,int _id=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=_id;crossable=3;tp=0;transp=1;
	}
	~BlockItem(){}
	void draw(Game *game);
	int encounter(Game *game);
	int getid();
};
class BlockNPC:public Block{
public:
	BlockNPC(int _xpos=0,int _ypos=0,int _fpos=0,int _id=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=_id;crossable=0;tp=0;transp=1;
	}
	~BlockNPC(){}
	void draw(Game *game);
	int encounter(Game *game);
	int getid();	
};
class BlockArrow:public Block{
public:
	BlockArrow(int _xpos=0,int _ypos=0,int _fpos=0,int _tp=0){
		xpos=_xpos;ypos=_ypos;fpos=_fpos;id=13;crossable=1;tp=_tp;transp=1;
	}
	~BlockArrow(){}
};
class Floor{
public:
	Block* block[13][13];
	string name;int floor;
	bool canTele;int spx,spy;
	bool explored;
	void setBlock(Game *game,int i,int j,int id);
	void loadFloor(Game* game,string s);
	void draw(Game *game);
	void doAnimate(Game *game);
	void calcPinch(Game *game);
	int findMonster(Game *game,int tp=0);
	Floor(int _floor=0,int _spx=0,int _spy=0,bool _canTele=1){
		floor=_floor;spx=_spx;spy=_spy;canTele=_canTele;
	}
	~Floor(){}
};
class Map{
public:
	int floor;
	vector <Floor*> floors;
	Map(){}
	~Map(){}
	void loadMap(Game* game,int _floor=0);
};