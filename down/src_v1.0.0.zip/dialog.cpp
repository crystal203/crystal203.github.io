#include <bits/stdc++.h>
#include "game.h"
#include "console.h"
using namespace std;
void DialogText::showDialog(Game* game,dstring cur,int _character,int _emotion){
	visible=1;text=&cur;character=_character;emotion=_emotion;game->refresh();
}
void DialogText::hideDialog(Game* game){
	visible=0;game->refresh();
}
void DialogText::printDialog(Game* game){
	settextstyle(16*game->rate,0,game->font.c_str());
	settextcolor(BLACK);
	setbkmode(TRANSPARENT);
	string text1="";
	if (game->language==0){
		for (int i=0;i<(int)text->en.size();++i){
			if (text->en[i]=='|'){
				text1=text->en.substr(i+1,text->en.size()-1);
				text->en=text->en.substr(0,i-1);
				break;
			}
		}
	}
	int width=(int)(textwidth(game->ds(text).c_str())/game->rate+15)/16*16-16;
	game->uiList.draw(character!=-1?0:4,400,160);
	for (int i=0;i<width/16;++i){
		game->uiList.draw(1,400,160+32+i*16);
	}
	if (text1!=""){
		game->drawText(400+6,160+16,game->ds(text));
		game->drawText(400+22,160+16,text1);
	}else game->drawText(400+16,160+16,game->ds(text));
	game->uiList.draw(2,400,160+32+width);
	if (character!=-1){	
		settextcolor(WHITE);
		game->drawText(372,88,game->ds(characterName[character]));
		game->emotionList.draw(emotion,390+8,65+12);
		game->uiList.draw(3,390,65);
	}
}
