#include "game.h"
#include "console.h"
using namespace std;
const int RESOLUTION_MAX=6,RESOLUTIONS[RESOLUTION_MAX][2]={{480,640},{600,800},{720,960},{840,1120},{960,1280},{1080,1460}};
const string RESOLUTION_NAME[RESOLUTION_MAX]={"   480 * 640   ",
											  "   600 * 800   ",
											  "   720 * 960   ",
											  "   840 * 1120  ",
											  "   960 * 1280  ",
											  "  1080 * 1460  "};
const string version="v1.0.0";
int HEIGHT,WIDTH;
void dpress(char c,int tp=0){
	int st=clock();
	while ((tp==0 || 1.0*(clock()-st)/CLOCKS_PER_SEC<0.15) && press(c));
}
void monsterBook(Game *game){
	if (press('X') && press(VK_CONTROL)){
		game->showTag=!game->showTag;
		game->refresh();
		dpress('X');dpress(VK_CONTROL);
		return;
	}
	if (press('X')){
		game->mbook=1;
		int n=(game->mapnow.floors[game->mapnow.floor]->findMonster(game)-1)/6+1;game->mpage=0;
		game->info=game->ds({"You opened the manual. Press X/ESC/SPACE to exit.","����˹����ֲᡣ�� X/ESC/�ո� ����"});
		game->refresh();
		dpress('X');
		while (!press('X') && !press(VK_ESCAPE) && !press(' ')){
			if ((press('A') || press(VK_LEFT)) && game->mpage>0){
				game->mpage--;game->refresh();dpress('A');dpress(VK_LEFT);
			}
			if ((press('D') || press(VK_RIGHT)) && game->mpage<n-1){
				game->mpage++;game->refresh();dpress('D');dpress(VK_RIGHT);
			}
		}
		game->mbook=0;
		game->info="";
		game->refresh();
		dpress('X');dpress(VK_ESCAPE);dpress(' ');
	}
}
signed main(){
	/* basic settings */
	setWindowSize("Game Launcher",90,35);
	hideCursor();
	Form mainForm(1,1,45,90,nullptr,0);
	Label infoLabel (toRaw("&fAdventure in &bAfterWorld Inc."),2,20,&mainForm);
	Label versionLabel(toRaw(version),3,30,&mainForm);
	Label titleLabel(toRaw("&e  Game Launcher - Settings"),4,20,&mainForm);
	ifstream settings("setting.ini");
	Form setResolution(5,5,14,20,&mainForm,0);
		vector <RawText> items1;
		for (int i=0;i<RESOLUTION_MAX;++i){
			items1.push_back(RawText(RESOLUTION_NAME[i]));
		}
		List resolution(toRaw("&e Set Resolution"),2,3,15,&setResolution,&items1,RESOLUTION_MAX,9,"");
		settings>>resolution.isChosen;resolution.print();
	Form setFont(7,22,14,37,&mainForm,0);
		vector <RawText> items2;items2.resize(3);
		items2[0]=toRaw("    ����    ");
		items2[1]=toRaw("    ����    ");
		items2[2]=toRaw(" New Custom ");
		List fontList(toRaw("&e  Set Font "),2,3,10,&setFont,&items2,4,9,"");
		settings>>fontList.isChosen;
		string myfont;settings>>myfont;
		if (myfont!="����") items2.push_back(toRaw(" My  Custom "));
		fontList.print();
	Form submitForm(16,35,2,10,&mainForm,0);
		Button start(toRaw("&f  Start  "),1,1,&submitForm,2,10);
	Form isDebugForm(6,24,1,20,&mainForm);
		CheckBox isDebug(toRaw("&fDebug Mode"),1,1,&isDebugForm);
		settings>>isDebug.chosen;
	Form languageForm(5,40,8,55,&mainForm,0);
		vector <RawText> items3;items3.resize(2);
		items3[0]=toRaw("  English  ");
		items3[1]=toRaw(" ���� ���� ");
		List languageList(toRaw("&eSet Language"),2,3,10,&languageForm,&items3,2,9,"");
		settings>>languageList.isChosen;languageList.print();
	Form saveForm(9,40,14,55,&mainForm,0);
		vector <RawText> items4;items4.resize(2);
		items4[0]=toRaw(" New  Game ");
		items4[1]=toRaw(" Load Game ");
		List saveList(toRaw(""),2,3,10,&saveForm,&items4,2,9,"");
		saveList.isChosen=0;saveList.print();
	settings.close();
	while (1){
		resolution.preserve();
		fontList.preserve();
		languageList.preserve();
		isDebug.preserve();
		saveList.preserve();
		if (start.preserve()==2 || press(VK_RETURN) || press(' ')) break;
	}
	HEIGHT=RESOLUTIONS[resolution.isChosen][0];WIDTH=RESOLUTIONS[resolution.isChosen][1];
	Game game(HEIGHT/480.0);
	clrscr();
	if (fontList.isChosen==0) game.font="����";
	else if (fontList.isChosen==1) game.font="����";
	else if (fontList.isChosen==2){
		tellraw("&e�������Զ����������ƣ�\n");
		showCursor();
		cin>>myfont;
		game.font=myfont;
	}else game.font=myfont;
	game.language=languageList.isChosen;
	
	/* save settings */
	ofstream _settings("setting.ini");
	_settings<<resolution.isChosen<<endl<<fontList.isChosen<<endl<<myfont<<endl<<isDebug.chosen<<endl;
	_settings<<languageList.isChosen<<endl;
	_settings.close();
	
	/* initial */
	game.loadAsset();
	game.player=new Player();game.player->dir=1;
	game.player->wBag.push_back(new Weapon(5,160,40,250,game.ds({"Unchained","���ƽ���"})));
	game.player->aBag.push_back(new Accessory(5,40,160,250,game.ds({"Ice Queen Ring","��ѩŮ��ָ��"})));
	game.player->weapon=game.player->wBag.back();
	game.player->accessory=game.player->aBag.back();
	game.trig.init();
	game.visible=0;
	game.gameEnd=0;
	game.debug=isDebug.chosen;
	initgraph(WIDTH,HEIGHT,isDebug.chosen?EX_SHOWCONSOLE:0);
	BeginBatchDraw();setbkcolor(WHITE);
	game.mapnow.loadMap(&game,0);
	
	/* let's begin */
	if (saveList.isChosen==0){
		game.visible=2;
		game.article("./text/start.txt");
		game.visible=1;		
	}else{
		game.visible=1;
		game.workLoad();
	}
	int st=clock();
	game.refresh();
	while (1){
		game.mapnow.floors[game.mapnow.floor]->explored=1;
		if (press(VK_CONTROL) && press('Z')){
			game.load("./save/quicksave.sav");
			game.refresh();
			dpress(VK_CONTROL);dpress('Z');
		}
		if (press(VK_CONTROL) && press('S')){
			game.workSave();
			game.refresh();
			dpress(VK_CONTROL);dpress('S');
		}
		if (press(VK_CONTROL) && press('L')){
			game.workLoad();
			game.refresh();
			dpress(VK_CONTROL);dpress('L');
		}
		if (press(VK_CONTROL) && press('A')){
			game.takeScreenShot(1);
			game.refresh();
			dpress(VK_CONTROL);dpress('A');	
		}
		if (!game.mbook && !press(VK_CONTROL)){
			char c[4]={'A','W','D','S'};
			char cc[4]={VK_LEFT,VK_UP,VK_RIGHT,VK_DOWN};
			int dx[4]={0,-1,0,1};
			int dy[4]={-1,0,1,0};
			for (int i=0;i<4;++i){
				if (!press(c[i]) && !press(cc[i])) continue;
				if (game.mapnow.floors[game.mapnow.floor]->block[game.player->nowx][game.player->nowy]->id==13 && 
					game.mapnow.floors[game.mapnow.floor]->block[game.player->nowx][game.player->nowy]->tp!=i) continue;
				game.info="";
				int newx=game.player->nowx+dx[i];
				int newy=game.player->nowy+dy[i];
				bool flag=1;
				if (newx>=0 && newx<=12 && newy>=0 && newy<=12){
					int sta=game.mapnow.floors[game.mapnow.floor]->block[newx][newy]->encounter(&game);
					if (sta==1){
						game.player->nowx=newx;
						game.player->nowy=newy;
						game.mapnow.floors[game.mapnow.floor]->calcPinch(&game);
						int dmg=game.mapnow.floors[game.mapnow.floor]->block[newx][newy]->dmg;
						if (game.player->poison) dmg+=10;
						if (game.player->immune) dmg*=0.1;
						game.player->hp-=dmg;
						if (dmg!=0) game.info=game.ds({"You lose "+to_string(dmg)+"HP due to Pinch/Field/Poison","���ܵ��˼л�/����/�綾�˺�"+to_string(dmg)+"��"});
						if (game.player->hp<0){
							game.visible=0;
							game.dialog.showDialog(&game,{"You Lose. Press SPACE to read the QuickSave.","�����ˡ����ո��ȡ���ٴ浵"});
							while (!press(' '));
							game.dialog.hideDialog(&game);
							while (press(' '));
							game.visible=1;flag=0;
							game.load("./save/quicksave.sav");
							game.refresh();
						}
					}
				}
				if (flag){
					game.player->dir=i;
					game.refresh();
				}
				dpress(c[i],1);dpress(cc[i],1);			
			}			
		}
		if (press('G')){
			if (press(VK_CONTROL)) game.tele=2;
			else game.tele=0;
			if (game.tele==2 || game.mapnow.floors[game.mapnow.floor]->canTele){
				if (game.tele==2 || game.canUseTele()){
					vector <int> cand;int now=0;
					for (int i=0;i<(int)game.mapnow.floors.size();++i){
						if (game.tele==2 || (game.mapnow.floors[i]->canTele && game.mapnow.floors[i]->explored)){
							cand.push_back(i);
							if (i==game.mapnow.floor){
								now=cand.size()-1;
							}
						}
					}
					int n=cand.size();
					int tmpf=game.mapnow.floor,tmpx=game.player->nowx,tmpy=game.player->nowy;
					if (game.tele==2){
						game.info=game.ds({"You are now browsing the map. ESC/G/SPACE to cancel","�����ͼ���� ESC/G/�ո� ȡ��"});
						game.player->nowx=game.player->nowy=-1;
					}else game.info=game.ds({"Press ESC/G to cancel, SPACE to Teleport!","�� ESC/G ȡ�����ո� ��ʼ���ͣ�"}),game.tele=1;
					game.refresh();
					dpress('G');
					while (1){
						if (press('W') || press(VK_UP) || press('S') || press(VK_DOWN)){
							if (press('W') || press(VK_UP)){
								if (now>=n-1) continue;
								now++;
							}
							if (press('S') || press(VK_DOWN)){
								if (now<=0) continue;
								now--;
							}
							game.mapnow.floor=game.player->nowf=cand[now];
							if (game.tele==1){
								game.player->nowx=game.mapnow.floors[cand[now]]->spx;
								game.player->nowy=game.mapnow.floors[cand[now]]->spy;								
							}
							game.refresh();
							dpress('W');dpress(VK_UP);dpress('S');dpress(VK_DOWN);
						}
						if (press('G') || press(VK_ESCAPE) || press(' ')) break;
						monsterBook(&game);
					}
					if (press('G') || press(VK_ESCAPE) || (game.tele==2 && press(' '))){
						game.player->nowf=game.mapnow.floor=tmpf;
						game.player->nowx=tmpx;
						game.player->nowy=tmpy;
						game.refresh();
					}
					game.tele=0;
				}else{
					game.info=game.ds({"You can not use teleport now","����ʱ�޷�ʹ�ô�����"});
					game.refresh();					
				}
			}else{
				game.info=game.ds({"You can not use teleport tool on this floor","�����޷�ʹ�ô�����"});
				game.refresh();
			}
			dpress('G');dpress(VK_ESCAPE);dpress(' ');dpress(VK_CONTROL);
		}
		monsterBook(&game);
		if (press('1') && game.player->pickaxe){
			int dx[4]={0,-1,0,1};
			int dy[4]={-1,0,1,0};
			int newx=game.player->nowx+dx[game.player->dir];
			int newy=game.player->nowy+dy[game.player->dir];
			if (newx<0 || newy<0 || newx>12 || newy>12) continue;
			if (game.mapnow.floors[game.mapnow.floor]->block[newx][newy]->id==1 && 
				game.mapnow.floors[game.mapnow.floor]->block[newx][newy]->tp==0 || game.mapnow.floors[game.mapnow.floor]->block[newx][newy]->tp==3){
				game.player->pickaxe--;
				game.mapnow.floors[game.mapnow.floor]->block[newx][newy]=new BlockFloor(newx,newy,game.mapnow.floor);
				game.info=game.ds({"You used the pickaxe","��ʹ���˸���"});
			}
			game.refresh();
			dpress('1');
		}
		if (press('2') && game.player->metal){
			if (game.player->weapon->id!=5){
				game.info=game.ds({"Please equip the final weapon","��װ����������"});
			}else{
				game.player->metal--;
				game.player->weapon->lvl++;
				game.player->weapon->calc();
				game.info=game.ds({"Your weapon get upgrated","��������õ���ǿ��"});
			}
			game.refresh();
			dpress('2');
		}
		if (press('3') && game.player->crystal){
			if (game.player->accessory->id!=5){
				game.info=game.ds({"Please equip the final accessory","��װ��������Ʒ"});
			}else{
				game.player->crystal--;
				game.player->accessory->lvl++;
				game.player->accessory->calc();
				game.info=game.ds({"Your accessory get upgrated","�����Ʒ�õ���ǿ��"});
			}
			game.refresh();
			dpress('3');
		}
		if (press('4') && game.player->potion){
			game.player->poison=game.player->fragile=game.player->weakness=0;
			game.info=game.ds({"Removed all negative affect","��������и���Ч��"});
			game.player->potion--;
			game.refresh();
			dpress('4');
		}
		if (press('5') && game.player->saint){
			game.player->saint--;game.player->hp*=2;
			game.info=game.ds({"You used the Holy Water","��ʹ����ʥˮ"});
			game.refresh();
			dpress('5');
		}
		if (press('V') && game.trig.p[32]){
			if (game.trig.p[44]) game.mapnow.floors[22]->block[10][7]->encounter(&game);
			else game.mapnow.floors[11]->block[3][7]->encounter(&game);
			dpress('V');
		}
		if (press('Z') && !press(VK_CONTROL)){
			game.player->dir=(game.player->dir+1)%4;
			game.refresh();
			dpress('Z');
		}
		if (press('P') && press(VK_CONTROL)){
			game.pause=1;game.info=game.ds({"Pause - Press Ctrl-P to continue","����ͣ���� Ctrl-P ���"});
			game.refresh();
			dpress('P');dpress(VK_CONTROL);
			while (!press('P') && !press(VK_CONTROL));
			game.pause=0;game.info="";
			game.refresh();
			dpress('P');
		}
		if (press('Q') && !game.mbook){
			game.chooseWeapon=1;
			game.info=game.ds({"W/S or Up/Down to choose weapon. Press Q/ESC/SPACE to exit.","W/S �� ����� ѡ���������� Q/ESC/�ո� ����"});
			dpress('Q');
			game.workWeapon();
			game.chooseWeapon=0;
			game.refresh();
			dpress('Q');
		}
		if (press('E') && !game.mbook){
			game.chooseAccessory=1;
			game.info=game.ds({"W/S or Up/Down to choose accessory. Press E/ESC/SPACE to exit.","W/S �� ����� ѡ����Ʒ���� E/ESC/�ո� ����"});
			dpress('E');
			game.workAccessory();
			game.chooseAccessory=0;
			game.refresh();
			dpress('E');
		}
		if (press('T') && !game.mbook){
			game.chooseTool=1;
			game.info=game.ds({"W/S or Up/Down to check tools. Press T/ESC/SPACE to exit.","W/S �� ����� �鿴���ߣ��� T/ESC/�ո� ����"});
			dpress('T');
			game.workTool();
			game.chooseTool=0;
			game.refresh();
			dpress('T');
		}
		if (1.0*(clock()-st)/CLOCKS_PER_SEC>0.3){
			st=clock();
			game.mapnow.floors[game.mapnow.floor]->doAnimate(&game);
			game.refresh();
		}
	}
	EndBatchDraw();
	return 0;
}
