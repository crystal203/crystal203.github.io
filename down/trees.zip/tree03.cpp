#include <bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
int calc(int x){
	int sum=0;
	for (int i=1;i*i<=x;++i){
		if (x%i==0){
			sum+=i;
			if (x/i!=i && i!=1) sum+=x/i;
		}
	}
	return sum;
}
const int N=110000;
int ea[N<<1],eb[N<<1],ec[N],etot;
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
int dp[N][3],maxs[N];
void dfs1(int x,int fa){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		dfs1(y,x);
		int dis=dp[y][0]+1;
		if (dis>=dp[x][0]){
			dp[x][1]=dp[x][0];
			dp[x][0]=dis;
			maxs[x]=y;
		}else if (dis>dp[x][1]) dp[x][1]=dis;
	}
}
void dfs2(int x,int fa){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		if (maxs[x]!=y) dp[y][2]=max(dp[x][0],dp[x][2])+1;
		else dp[y][2]=max(dp[x][1],dp[x][2])+1;
		dfs2(y,x);
	}
}
signed main(){
	int n=read();
	for (int i=2;i<=n;++i){
		int x=calc(i);
		if (x<i){
			addEdge(x,i);addEdge(i,x);
		}
	}
	dfs1(1,0);
	dfs2(1,0);
	int maxx=0;
	for (int i=1;i<=n;++i){
		maxx=max(maxx,max(dp[i][0],dp[i][2]));
	}
	cout<<maxx<<endl;
	return 0;
}