#include <bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
const int N=2010;
const int inf=0x3f3f3f3f;
int ea[N<<1],eb[N<<1],ec[N],etot;
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
int dp[N][3],w[N];
void dfs(int x,int fa){
	dp[x][2]=w[x];
	int sum=0;
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];if (y==fa) continue;dfs(y,x);
		dp[x][0]+=min(dp[y][1],dp[y][2]);
		dp[x][2]+=min(dp[y][0],min(dp[y][1],dp[y][2]));
		sum+=min(dp[y][1],dp[y][2]);
	}
	dp[x][1]=inf;
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];if (y==fa) continue;
		dp[x][1]=min(dp[x][1],sum-min(dp[y][1],dp[y][2])+dp[y][2]);
	}
}
signed main(){
	int n=read();
	for (int i=1;i<=n;++i){
		int x=read();w[x]=read();int m=read();
		for (int j=1;j<=m;++j){
			int y=read();
			addEdge(y,x);addEdge(x,y);
		}
	}
	dfs(1,0);
	cout<<min(dp[1][1],dp[1][2])<<endl;
	return 0;
}