#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=35;
int f[N][N],rt[N][N];
void dfs(int l,int r){
	if (l>r) return;
	printf("%lld ",rt[l][r]);
	dfs(l,rt[l][r]-1);
	dfs(rt[l][r]+1,r);
}
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
signed main(){
	int n=read();
	for (int i=1;i<=n;++i) f[i][i]=read();
	for (int i=1;i<=n+1;++i) f[i][i-1]=1;
	for (int i=1;i<=n;++i) rt[i][i]=i;
	for (int len=1;len<n;++len){
		for (int l=1;l<n;++l){
			int r=l+len;if (r>n) break;
			for (int i=l;i<=r;++i){
				if (f[l][r]<f[l][i-1]*f[i+1][r]+f[i][i]){
					f[l][r]=f[l][i-1]*f[i+1][r]+f[i][i];
					rt[l][r]=i;
				}
			}
		}
	}
	cout<<f[1][n]<<endl;
	dfs(1,n);
	return 0;
}