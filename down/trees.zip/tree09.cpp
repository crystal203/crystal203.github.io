#include <bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
const int N=10010;
const int inf=0x3f3f3f3f;
int ea[N<<1],eb[N<<1],ec[N],etot,n,m;
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
int f[N][3],c[N];
void dfs(int x,int fa){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		dfs(y,x);
		if (y<=n) f[y][!c[y]]=inf,f[y][2]=1;
		f[x][0]+=min(f[y][2],min(f[y][0]-1,f[y][1]));
		f[x][1]+=min(f[y][2],min(f[y][0],f[y][1]-1));
		f[x][2]+=min(f[y][2],min(f[y][0],f[y][1]));
	}
}
signed main(){
	m=read(),n=read();
	for (int i=1;i<=n;++i) c[i]=read();
	for (int i=1;i<=m-1;++i){
		int x=read(),y=read();
		addEdge(x,y);addEdge(y,x);
	}
	for (int i=1;i<=m;++i) f[i][0]=f[i][1]=1;
	dfs(n+1,-1);
	cout<<min(f[n+1][2],min(f[n+1][0],f[n+1][1]))<<endl;
	return 0;
}