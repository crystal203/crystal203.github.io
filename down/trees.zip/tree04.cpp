#include <bits/stdc++.h>
using namespace std;
const int N=2010;
int dp[N][2];
int ea[N<<1],eb[N<<1],ec[N],etot;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
void dfs(int x,int fa){
	dp[x][0]=0;dp[x][1]=1;
	for (int i=ec[x];~i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		dfs(y,x);
		dp[x][0]+=dp[y][1];
		dp[x][1]+=min(dp[y][0],dp[y][1]);
	}
}
signed main(){
	int n=read();
	memset(ec,-1,sizeof(ec));
	for (int i=1;i<=n;++i){
		int x=read(),m=read();
		for (int j=1;j<=m;++j){
			int y=read();
			addEdge(x,y);addEdge(y,x);
		}
	}
	dfs(0,-1);
	cout<<min(dp[0][0],dp[0][1])<<endl;
	return 0;
}