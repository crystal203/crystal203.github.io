#include <bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
const int N=110;
int dp[N][N],n,m,w[N];
int ea[N<<1],eb[N<<1],ec[N],etot;
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
void dfs(int x){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];dfs(y);
		for (int j=m;j>=0;--j){
			for (int k=0;k<=j;++k){
				dp[x][j]=max(dp[x][j],dp[y][k]+dp[x][j-k]);
			}
		}
	}
	for (int i=m;i>=1;--i) dp[x][i]=dp[x][i-1]+w[x];
}
signed main(){
	n=read(),m=read()+1;
	for (int i=1;i<=n;++i){
		int y=read();w[i]=read();
		addEdge(y,i);
	}
	dfs(0);
	cout<<dp[0][m]<<endl;
	return 0;
}