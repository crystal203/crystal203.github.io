#include <bits/stdc++.h>
using namespace std;
const int N=200010;
const int inf=0x3f3f3f3f;
int d1[N],d2[N],f[N],n,maxx=-1;
int ea[N<<1],eb[N<<1],ec[N],etot;
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
void dfs1(int x,int fa){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		dfs1(y,x);
		if (d1[y]+1>d1[x]){
			d2[x]=d1[x];d1[x]=d1[y]+1;
		}else if (d1[y]+1>d2[x]) d2[x]=d1[y]+1;
	}
	maxx=max(maxx,d1[x]+d2[x]);
}
void dfs2(int x,int fa){
	int ans=0;
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		if(d1[y]+1==d1[x]) ans++;
	}
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		if (d1[x]!=d1[y]+1 || (ans>1 && d1[x]==d1[y]+1)) f[y]=max(f[x],d1[x])+1;
		else f[y]=max(f[x],d2[x])+1;
		dfs2(y,x);
	}
}
signed main(){
	int n=read();
	for (int i=1;i<=n-1;++i){
		int x=read(),y=read();
		addEdge(x,y);addEdge(y,x);
	}
	dfs1(0,0);dfs2(0,0);
	for (int i=0;i<n;++i){
		if (d1[i]+max(d2[i],f[i])==maxx) printf("%d\n",i);
	}
	return 0;
}