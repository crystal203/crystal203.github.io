#include <bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
const int N=6010;
int ea[N<<1],eb[N<<1],ec[N],etot,fa[N],f[N][2];
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
void dfs(int x){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa[x]) continue;
		dfs(y);
		f[x][0]+=max(f[y][0],f[y][1]);
		f[x][1]+=f[y][0];
	}
}
signed main(){
	int n=read();
	for (int i=1;i<=n;++i) f[i][1]=read();
	for (int i=1;i<=n-1;++i){
		int x=read(),y=read();
		fa[x]=y;addEdge(x,y);addEdge(y,x);
	}
	int rt=0;
	for (int i=1;i<=n;++i){
		if (!fa[i]) rt=i;
	}
	dfs(rt);
	cout<<max(f[rt][0],f[rt][1])<<endl;
	return 0;
}