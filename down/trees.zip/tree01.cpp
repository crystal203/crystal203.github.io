#include <bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
const int N=110;
int dp[N][N],n,m;
int ea[N<<1],eb[N<<1],ec[N],ed[N<<1],etot;
void addEdge(int x,int y,int z){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;ed[etot]=z;
}
void dfs(int x,int fa){
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		dfs(y,x);
		for (int j=m;j>=1;--j){
			for (int k=0;k<=j-1;++k){
				dp[x][j]=max(dp[x][j],dp[y][k]+dp[x][j-k-1]+ed[i]);
			}
		}
	}
}
signed main(){
	n=read(),m=read();
	for (int i=2;i<=n;++i){
		int x=read(),y=read(),z=read();
		addEdge(x,y,z);
		addEdge(y,x,z);
	}
	dfs(1,0);
	cout<<dp[1][m]<<endl;
	return 0;
}