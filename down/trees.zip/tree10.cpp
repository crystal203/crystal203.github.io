#include <bits/stdc++.h>
using namespace std;
#define LL long long
const int N=1000010;
int read(){
	int x=0,f=1;char c=getchar();
	while (c<'0' || c>'9'){
		if (c=='-') f=-f;
		c=getchar();
	}
	while (c>='0' && c<='9'){
		x=x*10+c-48;c=getchar();
	}
	return x*f;
}
int ea[N<<1],eb[N<<1],ec[N],etot=1;
void addEdge(int x,int y){
	etot++;ea[etot]=y;eb[etot]=ec[x];ec[x]=etot;
}
bool vis[N],flag;
int p[N],siz[N],tot,L,R;
LL ans,f[N][2];
void dfs1(int x,int fa){
	vis[x]=1;siz[++tot]=x;
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y==fa) continue;
		if (!vis[y]) dfs1(y,x);
		else if (vis[y] && !flag){
			flag=1;L=x;R=y;
		}
	}
}
void dfs2(int x,int fa){
	f[x][0]=0;f[x][1]=p[x];
	for (int i=ec[x];i;i=eb[i]){
		int y=ea[i];
		if (y!=0 && y!=fa){
			dfs2(y,x);
			f[x][1]+=f[y][0];
			f[x][0]+=max(f[y][0],f[y][1]);
		}
	}
}
void solve(){
	if (!flag){
		int rt=siz[1];
		dfs2(rt,-1);
		ans+=max(f[rt][0],f[rt][1]);
	}else{
		LL maxx=-1e18;
		for (int i=ec[L];i;i=eb[i]){
			if (ea[i]==R){
				ea[i]=0;ea[i^1]=0;
				break;
			}
		}
		dfs2(L,-1);
		maxx=max(maxx,f[L][0]);
		dfs2(R,-1);
		maxx=max(maxx,f[R][0]);
		ans+=maxx;
	}
}
signed main(){
	int n=read();
	for (int i=1;i<=n;++i){
		p[i]=read();int x=read();addEdge(x,i);addEdge(i,x);
	}
	for (int i=1;i<=n;++i){
		if (!vis[i]){
			tot=0;flag=0;dfs1(i,-1);
			solve();
		}
	}
	cout<<ans<<endl;
	return 0;
}