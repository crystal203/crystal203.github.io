#include "console4.h"
#include <winsock2.h>
#include <iostream>
#include <easyx.h>
#include <map>
using namespace std;
void setWindowSize(){
	system("title �ı������");
	char cmd[30];
	sprintf(cmd,"mode con cols=%d lines=%d",80,20);
	system(cmd);
}
#define MSG_LEN 200
class Client{
	#define DEBUG 0
	WSAData wsa;
	SOCKET soc;
	int port;
	string ip;
	string name,password;
	mutex mu;
	vector <string> message; 
	stack <int> at_list;
	bool check_at_me(string s){
		int at_mode=0;int len=s.size();
		string at_buf="";
		for (int i=0;i<len;++i){
			if (s[i]=='@'){
				at_mode=1;
			}else if (s[i]==' ' && at_mode==1){
				at_mode=2;
			}else if (s[i]=='\r' || s[i]=='\n'){
				if (at_mode==1) at_mode=2;
			}else{
				if (at_mode==1) at_buf=at_buf+s[i];
			} 
			if (at_mode==2){
				if (at_buf==name) return 1;
				at_buf="";at_mode=0;
			}
		}
		return 0;
	}
	void easyx_tellraw(string s,int curx,int cury){
	    int len=s.size();settextcolor(WHITE);
	    string buf="";
	    int at_mode=0,col_change=0;
	    string at_buf=""; 
	    for (int i=0;i<len;++i){
	    	bool output=0;
	        if (s[i]=='&'){
	            output=1;col_change=hex2RGB(charToHex(s[i+1]));i++;
	        }else if (s[i]=='\r' || s[i]=='\n'){
	        	output=1;
	        	if (at_mode==1) at_mode=2;
			}else if (s[i]=='@'){
	            at_mode=1;output=1;
			}else if (at_mode==1 && s[i]==' '){
				at_mode=2;output=1;
			}else{
	        	if (at_mode==1) at_buf=at_buf+s[i];
				else buf=buf+s[i];
	        }
	        if (output){
	        	if (at_mode==2){
	        		settextcolor(hex2RGB(charToHex('b')));
	        		if (at_buf==name){
	        			setfillcolor(hex2RGB(charToHex('4')));
	        			solidrectangle(curx,cury,curx+textwidth(("@"+at_buf).c_str()),cury+textheight(("@"+at_buf).c_str()));
					}
		        	outtextxy(curx,cury,("@"+at_buf).c_str());
		        	curx+=textwidth(("@"+at_buf).c_str());
	        		at_mode=0;
	        		at_buf="";
	        		settextcolor(hex2RGB(charToHex('f')));
				}else{
		        	outtextxy(curx,cury,buf.c_str());
		        	curx+=textwidth(buf.c_str());	 
					buf="";					
				}
				if (col_change) settextcolor(col_change);
			}
	    }
	    settextcolor(WHITE);
	}
	string version="v1.0";
	bool init(){
		tellraw("&f�����ҿͻ��� &b"+version+"\n");
		tellraw("&a������...\n");
		tellraw("&f���ڼ������绷��...");
		if (WSAStartup(MAKEWORD(2,2),&wsa)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f���ڴ����׽���...");
		soc=socket(AF_INET,SOCK_STREAM,0);
		if (soc==INVALID_SOCKET){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		if (DEBUG==1) port=8000,ip="127.0.0.1";
		else if (DEBUG==2) port=8000,ip="122.51.81.168";
		else{
			tellraw("&f���������� ip ��ַ��");setColor(0xb); 
			cin>>ip;
			tellraw("&f���������˶˿ڣ�");setColor(0xb);
			cin>>port;
			string trush;getline(cin,trush);
		}
		sockaddr_in addr;
		addr.sin_family=AF_INET;
		addr.sin_port=htons(port);
		addr.sin_addr.s_addr=inet_addr(ip.c_str());
		int len=sizeof(sockaddr_in);
		tellraw("&f�������ӷ���� ip ���˿�...");
		if (connect(soc,(SOCKADDR*)&addr,len)==SOCKET_ERROR){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		return 1;
	}
	#define OUTPUT_REFRESH 50
	#define TEXT_HEIGHT 25
	int from=-1;
	int new_message=0;
	int online;
	void refresh(){
		cleardevice();
		int cur=440;
		for (int i=from;i>=0;--i){
			easyx_tellraw(message[i],25,cur);
			cur-=TEXT_HEIGHT;
			if (cur<TEXT_HEIGHT*2) break;
		}
		easyx_tellraw("&f��ӭ���������ң�&e"+name+"&f����ǰ����������&b"+to_string(online)+"\n",25,25);
		if (new_message!=0){
			easyx_tellraw("&b����Ϣ &f"+to_string(new_message)+" &b��\n",500,400);
		}
		if (!at_list.empty()){
			easyx_tellraw("&b���� @ ��\n",500,100);
		}
		FlushBatchDraw();
	}
	vector <string> solve(string s){
		string tmp="";
		vector <string> v;
		if (s[0]!='$'){
			v.push_back(s);
			return v;
		}
		for (int i=1;i<(int)s.size();++i){
			if (s[i]=='$'){
				v.push_back(tmp);tmp="";
			}else{
				tmp=tmp+s[i];
			}
		}
		return v;
	}
	bool invalid(int r){
		if (r==SOCKET_ERROR || r==0){
			tellraw("&c�շ���Ϣʱ������");
			return 1;
		}else return 0;
	}
	void c_recieve(SOCKET c){
		while (1){
			char buf[MSG_LEN]={0};
			int r=recv(c,buf,MSG_LEN,0);
			if (invalid(r)) return;
			string info=string(buf);
			if (info!=""){
				vector <string> vec=solve(info);
				if (vec[0]=="msg"){
					if (vec[1]==name){
						message.push_back(vec[2]);
						from=message.size()-1;						
					}else{
						if (from!=message.size()-1) new_message++;
						else from=message.size();
						message.push_back(vec[2]);						
					}
					if (check_at_me(vec[2])){
						at_list.push(message.size()-1);
					}
					refresh();
				}else if (vec[0]=="in" || vec[0]=="out"){
					if (vec[0]=="in") online++;
					else online--;
					if (from!=message.size()-1) new_message++;
					else from=message.size();
					if (from==-1) from=0,new_message=0;
					message.push_back(vec[1]);	
					refresh();
				}else if (vec[0]=="onl"){
					online=stoi(vec[1]);
				}
			}
		}
	} 
	void c_listen(){
		ExMessage m;
		while (1){
			m=getmessage(EX_MOUSE);
			switch (m.message){
				case WM_MOUSEWHEEL:{
					from-=m.wheel/120;
					if (from<0) from=0;
					if (from>message.size()-1) from=message.size()-1;
					refresh();
					break;
				}
				case WM_LBUTTONUP:{
					if (m.y>=390) from=message.size()-1,new_message=0;
					if (m.x>=450 && m.x<=550 && m.y>=70 && m.y<=130 && !at_list.empty()){
						from=at_list.top();at_list.pop();
					}
					refresh();
					break;
				}
			}
		}
	}
	bool str_valid(string s,int len_limit=MSG_LEN,bool space=1){
		if (s==""){
			tellraw("&c�ַ�������Ϊ�գ�\n");
			return 0;
		}
		if (s.size()>len_limit){
			tellraw("&c�ַ���������\n"); 
			return 0;
		}
		for (int i=0;i<(int)s.size();++i){
			if (s[i]=='$'){
				tellraw("&c�ַ������зǷ��ַ� $��\n"); 
				return 0; 
			}
			if (space==0 && s[i]==' '){
				tellraw("&c�ַ������зǷ��ַ��ո�\n"); 
				return 0; 
			}
		}
		return 1;
	}
	bool login(SOCKET c){
		do{
			tellraw("&f����������ǳƣ�");
			setColor(0xb);getline(cin,name);			
		}while (!str_valid(name,25,0));
		do{
			tellraw("&f������������룺");		
			password=pwd_input();puts("");
		}while (!str_valid(password,25));
		int r=send(c,("$login$"+name+"$"+password+"$").c_str(),MSG_LEN,0);
		if (invalid(r)) return 0;
		char info[MSG_LEN]={};
		r=recv(c,info,MSG_LEN,0);
		if (invalid(r)) return 0;
		if (string(info)[0]=='f'){
			tellraw("&c�û������������\n");
			return 0;
		}else if (string(info)[0]=='o'){
			tellraw("&c�����ظ���¼��\n");
			return 0;
		}
		return 1;
	}
	bool regis(SOCKET c){
		do{
			tellraw("&f����������ǳƣ�");
			setColor(0xb);getline(cin,name);			
		}while (!str_valid(name,25,0));
		do{
			tellraw("&f������������룺");		
			password=pwd_input();puts("");
		}while (!str_valid(password,25));
		int r=send(c,("$regis$"+name+"$"+password+"$").c_str(),MSG_LEN,0);
		if (invalid(r)) return 0;
		char info[MSG_LEN]={};
		r=recv(c,info,MSG_LEN,0);
		if (invalid(r)) return 0;
		if (string(info)[0]=='f'){
			tellraw("&cע��ʧ�ܣ��������û����ѱ�ע��\n");
			return 0;
		}
	}
public:
	void run(){
		if (!init()){
			tellraw("&c�����ͻ���ʱ�������⣡\n");
			return;
		}else{
			tellraw("&a�����ͻ��˳ɹ���\n");
			while (1){
				bool flag=0;
				switch (chosenbox("&f��¼ģʽ��@&e��¼@&bע��@^")){
					case 1:{
						flag=login(soc);
						break;
					}
					case 2:{
						flag=regis(soc);
						break;
					} 
					break;
				}
				if (flag) break;
			}
			initgraph(640,480,EX_SHOWCONSOLE);
			BeginBatchDraw();
			setbkmode(TRANSPARENT);
			thread t_recieve(&Client::c_recieve,this,soc);t_recieve.detach();
			thread t_listen(&Client::c_listen,this);t_listen.detach(); 
			while (1){
				clrscr();
				gotoxy(1,1);
				tellraw("&e������������������Ϣ��\n"); 
				string info="";
				do{
					getline(cin,info);
				}while (!str_valid(info,100));		
				int r=send(soc,info.c_str(),MSG_LEN,0);
				if (invalid(r)) return;
			}
			EndBatchDraw();
		}
		getch();
	}
}client;
int main(){
	client.run();
	while (1);
}
