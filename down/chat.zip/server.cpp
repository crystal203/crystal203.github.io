#include "console4.h"
#include <winsock2.h>
#include <iostream>
#include <map>
using namespace std;
class User{
public:
	string name;
	string password;
	bool online;
	User(string _name="",string _password=""){
		name=_name;password=_password;online=0;
	}
};
class Server{
	#define DEBUG 1
	#define MSG_LEN 200
	WSAData wsa;
	SOCKET soc;
	int port;
	string ip;
	map <SOCKET,string> client;
	map <string,User> users;
	mutex mu;
	vector <string> solve(string s){
		string tmp="";
		vector <string> v;
		for (int i=1;i<(int)s.size();++i){
			if (s[i]=='$'){
				v.push_back(tmp);tmp="";
			}else{
				tmp=tmp+s[i];
			}
		}
		return v;
	}
	string version="v1.0";
	bool init(){
		tellraw("&f�����ҷ������� &b"+version+"\n");
		tellraw("&a������...\n");
		tellraw("&f���ڼ������绷��...");
		if (WSAStartup(MAKEWORD(2,2),&wsa)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f���ڴ����׽���...");
		soc=socket(AF_INET,SOCK_STREAM,0);
		if (soc==INVALID_SOCKET){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		if (DEBUG==1) port=8000,ip="127.0.0.1";
		else if (DEBUG==2) port=8000,ip="10.0.16.7";
		else{
			tellraw("&f������������� ip ��ַ��");setColor(0xb); 
			cin>>ip;
			tellraw("&f������������˶˿ڣ�");setColor(0xb);
			cin>>port;			
		}
		sockaddr_in addr;
		addr.sin_family=AF_INET;
		addr.sin_port=htons(port);
		addr.sin_addr.s_addr=inet_addr(ip.c_str());
		int len=sizeof(sockaddr_in);
		tellraw("&f���ڰ󶨷����� ip ���˿�...");
		if (bind(soc,(SOCKADDR*)&addr,len)==SOCKET_ERROR){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f�������ü���״̬...");
		if (listen(soc,5)!=0){
			tellraw("&cʧ��\n");return 0;
		}else{
			tellraw("&a�ɹ�\n");
		}
		tellraw("&f���ڼ���ע���û���Ϣ...");
		ifstream f_user("user.txt");
		tellraw("&a�ɹ�\n");
		int user_cnt;f_user>>user_cnt;
		for (int i=1;i<=user_cnt;++i){
			string s;
			f_user>>s;
			vector <string> vec=solve(s);
			User tmp(vec[0],vec[1]);
			users[vec[0]]=tmp;
		}
		f_user.close();
		return 1;
	}
	void saveuser(){
		ofstream f_user("user.txt");
		f_user<<users.size()<<endl;
		for (auto user:users){
			f_user<<"$"<<user.second.name<<"$"<<user.second.password<<"$"<<endl;
		}
		f_user.close();
	}
	int online=0;
	void work(SOCKET c){
		char buf[MSG_LEN]={};
		string info,name,password;
		while (1){
			int r=recv(c,buf,MSG_LEN,0);
			if (r==SOCKET_ERROR || r==0) return;
			vector <string> com=solve(string(buf));
			name=com[1],password=com[2];
			if (com[0]=="login"){
				if (!users.count(name) || users[name].password!=password){
					send(c,"f",MSG_LEN,0);
				}else if (users[name].online==1){
					send(c,"o",MSG_LEN,0);
				}else{
					send(c,"s",MSG_LEN,0);
					break;
				}
			}else{
				if (users.count(name)){
					send(c,"f",MSG_LEN,0);
				}else{
					send(c,"s",MSG_LEN,0);
					users[name]=User(name,password);
					saveuser();
					break;
				}					
			}			
		}
		send(c,("$onl$"+to_string(online)+"$").c_str(),MSG_LEN,0);
		client[c]=name;
		info="$in$&a�û� &e"+name+" &a����������\n$";
		mu.lock();
		online++;
		mu.unlock();
		users[name].online=1;
		for (auto user:client){
			send(user.first,info.c_str(),MSG_LEN,0);
		}
		while (1){
			memset(buf,0,sizeof(buf));
			int r=recv(c,buf,MSG_LEN,0);
			if (r==SOCKET_ERROR || r==0) break;
			info="$msg$"+name+"$&f[&e"+name+"&f]: "+string(buf)+"\n$";
			for (auto user:client){
				send(user.first,info.c_str(),MSG_LEN,0);	
			}
		}
		info="$out$&c�û� &e"+name+" &c�뿪������\n$";
		mu.lock();
		online--;
		mu.unlock();
		client.erase(c);
		users[name].online=0;
		for (auto user:client){
			send(user.first,info.c_str(),MSG_LEN,0);	
		}
	}
public:
	void run(){
		if (!init()){
			tellraw("&c����������ʱ�������⣡\n");
			return;
		}else{
			tellraw("&a�����������ɹ���\n");
		}
		vector <thread*> threadPool;
		while (1){
			sockaddr_in caddr;
			int len=sizeof(caddr);
			SOCKET c=accept(soc,(sockaddr*)&caddr,&len);
			if (c==INVALID_SOCKET){
				tellraw("&c��ͻ�������ʧ�ܣ�\n");
			}else{
				thread* tmp=new thread(&Server::work,this,c);
				threadPool.push_back(tmp);
				tmp->detach();
			} 
		}
		closesocket(soc);
		WSACleanup();
	}
}server;
int main(){
	server.run();
	while (1);
}

