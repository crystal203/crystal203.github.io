#include <bits/stdc++.h>
using namespace std;
#include <windows.h>
#include <conio.h>

/*
	TEMPLATE OF CONSOLE 4.0
	Create by crystal302
*/

#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
void dpress(int c){
	while (press(c)){}
}
void setColor(int colorID){
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),colorID);
}
void clrscr(){
    setColor(0x0f);system("cls");
}
int charToHex(char c){
    if (c>='0' && c<='9') return c-'0';
    else return c-'a'+10;
}
void gotoxy(int x,int y){
    COORD pos;
    pos.X=y-1;
    pos.Y=x-1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
void clrline(int x,int from=1,int width=80,char p=' '){
	setColor(0x0f);gotoxy(x,from);
	for (int i=1;i<=width;++i) putchar(p);
}
pair <int,int> getxy(){
    HANDLE hStdout;
    CONSOLE_SCREEN_BUFFER_INFO pBuffer; 
    hStdout=GetStdHandle(STD_OUTPUT_HANDLE); 
    GetConsoleScreenBufferInfo(hStdout,&pBuffer); 
    return make_pair(pBuffer.dwCursorPosition.Y+1,pBuffer.dwCursorPosition.X+1);
}
void getpos(POINT &pt){
    HWND hwnd=GetForegroundWindow();
    GetCursorPos(&pt);
    ScreenToClient(hwnd,&pt);
    pt.y=pt.y;
    pt.x=pt.x;
}
void clearbuf(){
	while (kbhit()) getch();
}
int hex2RGB(int c){
	switch (c){
		case 0:return 0;
		case 1:return 0xAA0000;
		case 2:return 0x00AA00;
		case 3:return 0xAAAA00;
		case 4:return 0x0000AA;
		case 5:return 0xAA00AA;
		case 6:return 0x0055AA;
		case 7:return 0xAAAAAA;
		case 8:return 0x555555;
		case 9:return 0xFF5555;
		case 10:return 0x55FF55;
		case 11:return 0xFFFF55;
		case 12:return 0x5555FF;
		case 13:return 0xFF55FF;
		case 14:return 0x55FFFF;
		case 15:return 0xFFFFFF;
	}	
}
void tellraw(string s,...){
    va_list ap;va_start(ap,s);
    int len=s.size();setColor(0x0f);
    int foreColor=15,backColor=0,crlf=getxy().second;
    bool change=false;
    for (int i=0;i<len;++i){
        if (s[i]=='%'){
            if (change) setColor(foreColor+backColor*16),change=false;
            if (s[i+1]=='s') cout<<va_arg(ap,char*);
            else if (s[i+1]=='d') cout<<va_arg(ap,int);
            i++;
        }else if (s[i]=='&'){
            foreColor=charToHex(s[i+1]);
            change=true;i++;
        }else if (s[i]=='#'){
            backColor=charToHex(s[i+1]);
            change=true;i++;
        }else if (s[i]=='/'){
            if (s[i+1]=='/') putchar('/');
            else if (s[i+1]=='#') putchar('#');
            else if (s[i+1]=='%') putchar('%');
            else if (s[i+1]=='&') putchar('&');
            else if (s[i+1]=='n'){
                pair <int,int> tmp=getxy();
                gotoxy(tmp.first,crlf-1);
            }
            else if (s[i+1]=='c') clrscr(); 
            i++;
        }else{
            if (change) setColor(foreColor+backColor*16),change=false;
            putchar(s[i]);
        }
    }
    setColor(0x0f);va_end(ap);
}
string pwd_input(){
	string s="";
	int curx=getxy().first,cury=getxy().second;
	setColor(0xb);
	while (1){
		char c=getch();
		if (c=='\b'){
			if (s.size()==0) continue;
			s=s.substr(0,s.size()-1);
			cury--;
			gotoxy(curx,cury);
			putchar(' ');
			gotoxy(curx,cury);
			continue;
		}
		if (c=='\n' || c=='\r') break;
		s=s+c;cury++;putchar('*');
	}
	return s;
}
int chosenbox(string s){
    int len=s.size(),i=0;
    pair <int,int> tmp=getxy();
    string t="";
    while (s[i]!='@' && i<len) t=t+s[i],i++;
    tellraw(t);
    int j=i;
    t="";
    int item=0;
    for (int i=j+1;i<len;++i){
        if (s[i]=='^'){ 
            j=i;
            break;
        }else if (s[i]=='@'){
            item++;
            gotoxy(tmp.first+item,tmp.second);
            tellraw("    &b%d. &f"+t+"/n",item);
            t="";
        }else{
            t=t+s[i];
        }
    }
    t="";
    for (int i=j+1;i<len;++i){
        t=t+s[i];
    }
    gotoxy(tmp.first+item+1,tmp.second);
    tellraw(t);
    gotoxy(tmp.first+1,tmp.second);
    tellraw("&f-->");
    clearbuf();char c=getch();
    int chosen=1;
    while (c!=' '){
        if (c=='W' || c=='w'){
            if (chosen>1){
                gotoxy(tmp.first+chosen,tmp.second);
                chosen--;
                printf("   ");
                gotoxy(tmp.first+chosen,tmp.second);
                tellraw("&f-->");
            }
        }else if (c=='S' || c=='s'){
            if (chosen<item){
                gotoxy(tmp.first+chosen,tmp.second);
                chosen++;
                printf("   ");
                gotoxy(tmp.first+chosen,tmp.second);
                tellraw("&f-->");
            }           
        }else if (c>='1' && c<='9' && c-48<=item){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=c-48;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw("&f-->");           
        }else if (c=='A' || c=='a'){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=1;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw("&f-->");           
        }else if (c=='D' || c=='d'){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=item;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw("&f-->");           
        }
    	c=getch();
    }    	
    gotoxy(tmp.first+item+2,tmp.second);
    return chosen;
}
void hideCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=0;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
void showCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=1;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
