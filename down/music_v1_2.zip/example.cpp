#include <bits/stdc++.h>
using namespace std;
#include "music.h"
#include <conio.h>
signed main(){
	string s;cin>>s;
	BGM bgm(s+".txt",0x7f);
	bgm.play();
	puts("Please Input A & B");
	int a,b;scanf("%d %d",&a,&b);
	printf("A + B = %d\n",a+b);
	puts("Press Any Key to EXIT");
	getch();
	bgm.stop();
	return 0;
}