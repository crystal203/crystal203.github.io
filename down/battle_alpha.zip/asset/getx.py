from PIL import Image
f=open("content.ini","r")
s=open("size.ini","w")
content=f.readlines()
s.write(str(len(content))+"\n");
for line in content:
    print("working "+line)
    fname=line.split()[0]
    img=Image.open(fname+".png")
    s.write(str(img.width)+" "+str(img.height)+"\n")
s.close()
