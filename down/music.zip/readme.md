### 基于 `Windows API MIDI` 的 `music.h` 使用帮助

调用本头文件，能够在您的 c++ 程序中播放音色良好的自定义音乐。

下载链接：[music.zip](https://crystal203.github.io/down/music.zip)

版本号 `V1.0`

### 0. 环境要求

#### 0.1 软件/语言支持

+ x64 Windows 系统
+ C++

#### 0.2 编译器配置

+ 开启 C++11 `-std=c++11`
+ 连接器命令行 `-lwinmm` 

### 1. 如何自定义音乐

#### 1.1 简谱格式

在任意文本文档中，第一行输入一个整数，表示乐曲节奏进行的快慢（一个四分音符的延时，毫秒），之后若干行输入指定格式的字符串，表示音符集，即可完成创作。

**音符集格式规范**

任意两个音符/和弦间应用空格隔开。事实上，播放音符的判定**总**会在空格处执行。

高/低/升音号必须紧跟在音符后面，但这些符号内部的顺序不限。

延/分音号与音符间的顺序不限，但延/分音号内部将从左到右判读。和弦的延/分音号建议放在和弦外面。

| 字符  | 说明   | 使用示例                                               |
| ----- | ------ | ------------------------------------------------------ |
| `1~7` | 音符   | 如 `1 2 3 4 5` 表示播放 `do re mi fa sol` 五个音符     |
| `0`   | 休止符 | 略                                                     |
| `,`   | 低音   | 即音符向下附点，最多可以有三个低音号。如 `1,` `2,,` 等 |
| `^`   | 高音   | 类比低音                                               |
| `#`   | 升音   | 向上半音高。如 `4#`                                    |
| `-`   | 延音   | 每个延音号将为音符额外多出一个四分音符的延时           |
| `_`   | 分音   | 每个分音号将使音符的延时减半                           |
| `.`   | 附点   | 每个附点号将使音符的延时增半（×1.5）                   |
| `[]`  | 和弦   | 中括号内的音符将一次性演奏                             |
| `|`   | 小节线 | 程序将忽略这个符号                                     |

#### 1.2 `autopiano` 格式

将简谱格式的第一行的整数取负数，即自动判别为 `autopiano` 格式。

该格式复刻了 [autopiano](https://www.autopiano.cn/) 网站的格式要求，并在播放时自动转化为简谱格式。

### 2. 头文件解析

+ `string key2num(string s)`  将 `autopiano` 格式转化为简谱格式。

#### 2.1 `MusicPlayer` 类

音乐播放器。将连接相关的 `API` 进行音乐播放操作。

+ `void setVolume(int _vol)` 设置音量（`0x00` 至 `0x7f`）
+ `void setDelay(int _dctn)` 设置四分音符延时（毫秒）
+ `void play(string s)` 播放**简谱格式**的一行音符
+ `void playList(MusicList &m)` 播放歌曲

#### 2.2 `MusicList` 类

歌曲。可以将若干行音符整合，也可从文件中读取音符。

+ `void setDelay(int _dctn)` 设置四分音符延时（毫秒）——优先于播放器设置的延时
+ `void add(string s)` `void addk(string s)` 插入一行简谱格式或 `autopiano` 格式的音符
+ `void clear()` 清空歌曲
+ `void readFile(string s)` 从文件中读取音符集

#### 2.3 `BGM` 类

使用多线程，可使程序在运行同时播放歌曲。

+ `void setMusic(string s)` 从文件中读取音符集并绑定
+ `void play()` 开始循环播放此音乐
+ `void stop()` 停止播放此音乐

### 3. 程序使用范例

#### 3.1 播放指定乐曲

```cpp
#include <bits/stdc++.h>
using namespace std;
#include "music.h"
signed main(){
	MusicPlayer player;
	MusicList m;
	m.readFile("flower.txt"); //此处输入乐曲存放的文件名
	player.playList(m);
	return 0;
}
```

#### 3.2 BGM播放

```cpp
#include <bits/stdc++.h>
using namespace std;
#include "music.h"
#include <conio.h>
signed main(){
	BGM bgm("flower.txt",0x4f);
	bgm.play();
    //下面这部分可以换成需要的程序内容。音乐播放将不会妨碍程序运行。
	puts("Please Input A & B");
	int a,b;scanf("%d %d",&a,&b);
	printf("A + B = %d\n",a+b);
	puts("Press Any Key to EXIT");
	getch();
    
	bgm.stop();
	return 0;
}
```

### 4. 乐曲范例

包括程序使用范例中的 `flower.txt` 和若干首乐曲应已和 `music.h` 共同打包。

范例乐曲来源：《Little Princess》《On Your Way》《Town of Flowers Helena》











