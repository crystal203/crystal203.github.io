#pragma once
#include "game.h"
using namespace std;
class Game;
class Trigger{ // ���
public:
	vector <int> p;
	void work(Game *game);
	void init();
	Trigger(){
		init();
	}
};