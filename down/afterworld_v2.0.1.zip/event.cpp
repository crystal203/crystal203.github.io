#include "game.h"
using namespace std;
const int TNUM=128;
void Trigger::init(){
	p.resize(TNUM);
	for (int i=0;i<(int)p.size();++i) p[i]=0;
}
bool checkPos(int f,int x,int y,Game *game){ // �ж�λ��
	return game->player->nowf==f && game->player->nowx==x && game->player->nowy==y;
}
int getid(int f,int x,int y,Game *game){ // ��ȡͼ�� id
	return game->mapnow.floors[f]->block[x][y]->id;
}
void teleport(int f,int x,int y,int dir,Game *game){ // ���͵�ָ��λ��
	game->player->nowf=game->mapnow.floor=f;
	game->player->nowx=x;
	game->player->nowy=y;	
	game->player->dir=dir;
	game->mp.play("floor");
	game->refresh();
	game->takeScreenShot();
	game->save("./save/quicksave.sav");
}
void Trigger::work(Game *game){
	switch (game->mapnow.floor){ // ��¥���ܴ������¼�
		case 0:{
			if (checkPos(0,8,6,game) && p[0]==0){
				p[0]=1;
				game->article("./text/event0.txt");
			}
			if (p[1]==1){
				p[1]=2;
				game->article("./text/event1.txt");
			}
			if (checkPos(0,8,6,game) && p[2]==1 && p[54]==0){
				p[54]=1;
				game->article("./text/event0.txt");
			}
			if (p[55]==1){
				p[55]=2;
				game->article("./text/end.txt");
				game->calcScore();
			}
			break;
		}
		case 1:{
			if (checkPos(1,10,6,game) && p[2]==0){
				p[2]=1;
				game->article("./text/event2.txt");
			}
			if (checkPos(1,7,6,game) && p[3]==0){
				p[3]=1;
				game->article("./text/event3.txt");
			}
			if (checkPos(1,6,6,game) && p[4]==0){
				p[4]=1;
				game->article("./text/event4.txt");
			}
			if (checkPos(1,0,6,game)) teleport(2,11,6,1,game);
			if (checkPos(1,6,0,game)) teleport(3,6,11,0,game);
			if (checkPos(1,6,12,game)) teleport(4,6,1,2,game);
			if (checkPos(1,12,6,game)) teleport(11,1,6,3,game);
			break;
		}
		case 2:{
			if (checkPos(2,0,6,game)) teleport(5,11,6,1,game);
			if (checkPos(2,12,6,game)) teleport(1,1,6,3,game);
			if (checkPos(2,10,6,game) && p[5]==0){
				p[5]=1;
				game->article("./text/event5.txt");
			}
			if (checkPos(2,4,6,game) && p[6]==0){
				p[6]=1;game->mp.play("trap");
				game->mapnow.floors[2]->block[5][6]=new BlockDoor(5,6,2,9);
				game->mapnow.floors[2]->block[5][6]->animate(game,1);
			}
			if (getid(2,3,5,game)==0 && getid(2,3,7,game)==0 && p[7]==0){
				p[7]=1;game->mp.play("trap");
				game->mapnow.floors[2]->block[5][6]->animate(game);
				game->mapnow.floors[2]->block[2][6]->animate(game);
				game->mapnow.floors[2]->block[5][6]=new BlockFloor(5,6,2);
				game->mapnow.floors[2]->block[2][6]=new BlockFloor(2,6,2);
			}
			if (checkPos(2,1,2,game) && p[8]==0){
				p[8]=1;game->mp.play("trap");
				game->mapnow.floors[2]->block[1][2]->special(game);
				game->mapnow.floors[1]->block[6][1]=new BlockFloor(6,1,1);
			}
			if (checkPos(2,1,10,game) && p[9]==0){
				p[9]=1;game->mp.play("trap");
				game->mapnow.floors[2]->block[1][10]->special(game);
				game->mapnow.floors[1]->block[6][11]=new BlockFloor(6,11,1);
			}
			break;
		}
		case 3:{
			if (checkPos(3,6,12,game)) teleport(1,6,1,2,game);
			break;
		}
		case 4:{
			if (checkPos(4,6,0,game)) teleport(1,6,11,0,game);
			break;
		}
		case 5:{
			if (checkPos(5,12,6,game)) teleport(2,1,6,3,game);
			if (checkPos(5,1,6,game)) teleport(6,1,7,2,game);
			if (getid(5,3,9,game)==0 && getid(5,3,11,game)==0 && p[10]==0){
				p[10]=1;game->mp.play("trap");
				game->mapnow.floors[5]->block[2][10]->animate(game);
				game->mapnow.floors[5]->block[2][10]=new BlockFloor(2,10,5);
			}
			if (getid(5,5,9,game)==0 && getid(5,5,11,game)==0 && p[11]==0){
				p[11]=1;game->mp.play("trap");
				game->mapnow.floors[5]->block[4][10]->animate(game);
				game->mapnow.floors[5]->block[4][10]=new BlockFloor(4,10,5);
			}
			if (getid(5,7,9,game)==0 && getid(5,7,11,game)==0 && p[12]==0){
				p[12]=1;game->mp.play("trap");
				game->mapnow.floors[5]->block[8][10]->animate(game);
				game->mapnow.floors[5]->block[8][10]=new BlockFloor(8,10,5);
			}
			if (getid(5,9,9,game)==0 && getid(5,9,11,game)==0 && p[13]==0){
				p[13]=1;game->mp.play("trap");
				game->mapnow.floors[5]->block[10][10]->animate(game);
				game->mapnow.floors[5]->block[10][10]=new BlockFloor(10,10,5);
			}
			if (checkPos(5,10,6,game) && p[14]==0){
				p[14]=1;game->mp.play("trap");
				game->article("./text/event6.txt");
			}
			break;
		}
		case 6:{
			if (checkPos(6,1,6,game)) teleport(5,2,6,3,game);
			if (checkPos(6,1,4,game)) teleport(7,2,4,3,game);
			if (checkPos(6,11,11,game)) teleport(7,10,11,1,game);
			if (getid(6,4,8,game)==0 && getid(6,6,8,game)==0 && p[15]==0){
				p[15]=1;game->mp.play("trap");
				game->mapnow.floors[6]->block[5][9]->animate(game);
				game->mapnow.floors[6]->block[5][9]=new BlockFloor(5,9,6);
			}
			if (getid(6,8,8,game)==0 && getid(6,10,8,game)==0 && p[16]==0){
				p[16]=1;game->mp.play("trap");
				game->mapnow.floors[6]->block[9][9]->animate(game);
				game->mapnow.floors[6]->block[9][9]=new BlockFloor(9,9,6);
			}
			if ((checkPos(6,9,7,game) || checkPos(6,9,8,game)) && p[17]==0){
				p[17]=1;game->player->dir=2;
				game->article("./text/event7.txt");
			}
			break;
		}
		case 7:{
			if (checkPos(7,11,11,game)) teleport(6,11,10,0,game);
			if (checkPos(7,1,4,game)) teleport(6,2,4,3,game);
			if (checkPos(7,11,4,game)) teleport(8,10,4,1,game);
			if (checkPos(7,7,11,game)) teleport(8,8,11,3,game);
			if (getid(7,8,11,game)==0 && p[19]==0){
				p[19]=1;game->mp.play("trap");
				game->mapnow.floors[7]->block[8][10]->animate(game);
				game->mapnow.floors[7]->block[8][10]=new BlockFloor(8,10,7);
			}
			if (getid(7,1,1,game)==0 && p[20]==0){
				p[20]=1;game->mp.play("trap");
				game->mapnow.floors[7]->block[6][1]=new BlockKey(6,1,7,2);
			}
			if (getid(7,1,7,game)==0 && p[21]==0){
				p[21]=1;game->mp.play("trap");
				game->mapnow.floors[7]->block[6][7]=new BlockKey(6,7,7,2);
			}
			break;
		}
		case 8:{
			if (checkPos(8,11,4,game)) teleport(7,10,4,1,game);
			if (checkPos(8,7,11,game)) teleport(7,8,11,3,game);
			if (checkPos(8,11,2,game)) teleport(9,11,1,0,game);
			if (getid(8,9,11,game)==0 && p[22]==0){
				p[22]=1;game->mp.play("trap");
				game->mapnow.floors[8]->block[9][10]->animate(game);
				game->mapnow.floors[8]->block[9][10]=new BlockFloor(9,10,8);
			}
			if (getid(8,1,4,game)==0 && getid(8,2,2,game)==0 && getid(8,2,6,game)==0 && getid(8,4,1,game)==0 && 
				getid(8,4,7,game)==0 && getid(8,6,2,game)==0 && getid(8,6,6,game)==0 && getid(8,7,4,game)==0 && p[23]==0){
				p[23]=1;game->mp.play("trap");
				game->mapnow.floors[8]->block[2][4]->animate(game);
				game->mapnow.floors[8]->block[2][4]=new BlockFloor(2,4,8);
				game->mapnow.floors[8]->block[6][4]->animate(game);
				game->mapnow.floors[8]->block[6][4]=new BlockFloor(6,4,8);
				game->mapnow.floors[8]->block[4][2]->animate(game);
				game->mapnow.floors[8]->block[4][2]=new BlockFloor(4,2,8);
				game->mapnow.floors[8]->block[4][6]->animate(game);
				game->mapnow.floors[8]->block[4][6]=new BlockFloor(4,6,8);
			}
			break;
		}
		case 9:{
			if (checkPos(9,11,2,game)) teleport(8,11,1,0,game);
			if (checkPos(9,11,6,game)) teleport(10,10,6,1,game);
			break;
		}
		case 10:{
			if (checkPos(10,11,6,game)) teleport(9,10,6,1,game);
			if (checkPos(10,0,6,game)) teleport(21,11,6,1,game);
			if (getid(10,7,6,game)==0 && p[24]==0){
				p[24]=1;game->mp.play("trap");
				game->mapnow.floors[10]->block[5][6]->animate(game);
				game->mapnow.floors[10]->block[5][6]=new BlockFloor(5,6,8);
			}
			if (getid(10,8,1,game)==0 && getid(10,8,3,game)==0 && p[25]==0){
				p[25]=1;game->mp.play("trap");
				game->mapnow.floors[10]->block[7][2]->animate(game);
				game->mapnow.floors[10]->block[7][2]=new BlockFloor(7,2,10);
			}
			if (getid(10,10,3,game)==0 && getid(10,10,3,game)==0 && p[26]==0){
				p[26]=1;game->mp.play("trap");
				game->mapnow.floors[10]->block[9][2]->animate(game);
				game->mapnow.floors[10]->block[9][2]=new BlockFloor(9,2,10);
			}
			if (getid(10,8,9,game)==0 && getid(10,8,11,game)==0 && p[27]==0){
				p[27]=1;game->mp.play("trap");
				game->mapnow.floors[10]->block[7][10]->animate(game);
				game->mapnow.floors[10]->block[7][10]=new BlockFloor(7,10,10);
			}
			if (getid(10,10,9,game)==0 && getid(10,10,11,game)==0 && p[28]==0){
				p[28]=1;game->mp.play("trap");
				game->mapnow.floors[10]->block[9][10]->animate(game);
				game->mapnow.floors[10]->block[9][10]=new BlockFloor(9,10,10);
			}
			if (checkPos(10,10,6,game) && p[29]==0){
				p[29]=1;game->mp.play("trap");
				game->article("./text/event9.txt");
			}
			if (checkPos(10,3,5,game) && p[30]==0){
				p[30]=1;game->mp.play("trap");
				game->mapnow.floors[10]->block[3][5]->special(game);
				game->article("./text/event10.txt");
			}
			break;
		}
		case 11:{
			if (checkPos(11,0,6,game)) teleport(1,11,6,1,game);
			if (checkPos(11,12,6,game)) teleport(12,1,6,3,game);
			if (checkPos(11,6,0,game)) teleport(13,6,11,0,game);
			if (checkPos(11,6,12,game)) teleport(14,6,1,2,game);
			if (checkPos(11,3,6,game) && p[32]==0){
				p[32]=1;
				game->player->dir=2;
				game->player->soul=0;
				game->shopCost=1;
				game->article("./text/event12.txt");
			}
			break;
		}
		case 12:{
			if (checkPos(12,0,6,game)) teleport(11,11,6,1,game);
			if (checkPos(12,12,6,game)) teleport(15,11,6,1,game);
			if (checkPos(12,11,2,game) && p[33]==0){
				p[33]=1;game->mp.play("trap");
				game->mapnow.floors[12]->block[11][2]->special(game);
				game->mapnow.floors[11]->block[6][1]=new BlockFloor(6,1,11);
			}
			if (checkPos(12,11,10,game) && p[34]==0){
				p[34]=1;game->mp.play("trap");
				game->mapnow.floors[12]->block[11][10]->special(game);
				game->mapnow.floors[11]->block[6][11]=new BlockFloor(6,11,11);
			}
			if (checkPos(12,8,6,game) && p[35]==0){
				p[35]=1;game->mp.play("trap");
				game->mapnow.floors[12]->block[7][6]=new BlockDoor(7,6,12,9);
				game->mapnow.floors[12]->block[7][6]->animate(game,1);
			}
			if (getid(12,9,7,game)==0 && getid(12,9,5,game)==0 && p[36]==0){
				p[36]=1;game->mp.play("trap");
				game->mapnow.floors[12]->block[7][6]->animate(game);
				game->mapnow.floors[12]->block[10][6]->animate(game);
				game->mapnow.floors[12]->block[7][6]=new BlockFloor(7,6,12);
				game->mapnow.floors[12]->block[10][6]=new BlockFloor(10,6,12);
			}
			break;
		}
		case 13:{
			if (checkPos(13,6,12,game)) teleport(11,6,1,2,game);
			break;
		}
		case 14:{
			if (checkPos(14,6,0,game)) teleport(11,6,11,0,game);
			break;
		}
		case 15:{
			if (checkPos(15,12,6,game)) teleport(12,11,6,1,game);
			if (checkPos(15,1,6,game)) teleport(16,2,6,3,game);
			break;
		}
		case 16:{
			if (checkPos(16,11,1,game)) teleport(17,10,1,1,game);
			if (checkPos(16,11,11,game)) teleport(17,10,11,1,game);
			if (checkPos(16,1,6,game)) teleport(15,2,6,3,game);
			break;
		}
		case 17:{
			if (checkPos(17,11,1,game)) teleport(16,10,1,1,game);
			if (checkPos(17,11,11,game)) teleport(16,10,11,1,game);
			if (checkPos(17,1,6,game)) teleport(18,2,6,3,game);
			break;
		}
		case 18:{
			if (checkPos(18,1,6,game)) teleport(17,2,6,3,game);
			if (checkPos(18,11,1,game)) teleport(19,11,2,2,game);
			if (checkPos(18,11,11,game)) teleport(19,11,10,0,game);
			if (getid(18,8,5,game)==0 && getid(18,8,7,game)==0 && p[37]==0){
				p[37]=1;game->mp.play("trap");
				game->mapnow.floors[18]->block[7][6]->animate(game);
				game->mapnow.floors[18]->block[7][6]=new BlockFloor(7,6,18);
			}
			break;
		}
		case 19:{
			if (checkPos(19,11,1,game)) teleport(18,10,1,1,game);
			if (checkPos(19,11,11,game)) teleport(18,10,11,1,game);
			if (checkPos(19,11,6,game)) teleport(20,10,6,1,game);
			if (getid(19,9,5,game)==0 && getid(19,9,7,game)==0 && p[38]==0){
				p[38]=1;game->mp.play("trap");
				game->mapnow.floors[19]->block[8][6]->animate(game);
				game->mapnow.floors[19]->block[8][6]=new BlockFloor(8,6,18);
			}
			if (getid(19,4,2,game)==0 && p[43]==0){
				p[43]=1;game->mp.play("trap");
				game->mapnow.floors[19]->setBlock(game,4,10,9813);
			}
			break;
		}
		case 20:{
			if (checkPos(20,11,6,game)) teleport(19,10,6,1,game);
			if (getid(20,5,6,game)==0 && getid(20,7,6,game)==0 && 
				getid(20,6,5,game)==0 && getid(20,6,7,game)==0 &&
				getid(20,5,5,game)!=0 && getid(20,7,7,game)!=0 &&
				getid(20,7,5,game)!=0 && getid(20,5,7,game)!=0 && p[39]==0){
				p[39]=1;game->mp.play("trap");
				game->mapnow.floors[20]->setBlock(game,6,6,9928);
			}
			if (checkPos(20,8,6,game) && p[40]==0){
				p[40]=1;game->mp.play("trap");
				game->mapnow.floors[20]->block[9][6]=new BlockDoor(9,6,20,9);
				game->mapnow.floors[20]->block[9][6]->animate(game,1);
			}
			if (getid(20,6,6,game)==0 && p[41]==0){
				p[41]=1;game->mp.play("trap");
				game->mapnow.floors[20]->block[3][6]->animate(game);
				game->mapnow.floors[20]->block[9][6]->animate(game);
				game->mapnow.floors[20]->block[3][6]=new BlockFloor(3,6,20);
				game->mapnow.floors[20]->block[9][6]=new BlockFloor(9,6,20);
			}
			if (checkPos(20,1,6,game) && p[42]==0){
				p[42]=1;game->mp.play("trap");
				game->mapnow.floors[20]->block[1][6]->special(game);
				game->article("./text/event13.txt");
				game->mapnow.floors[10]->block[2][6]=new BlockFloor(2,6,10);
			}
			break;
		}
		case 21:{
			if (checkPos(21,12,6,game)) teleport(10,1,6,3,game);
			if (checkPos(21,0,6,game)) teleport(22,11,6,1,game);
			break;
		}
		case 22:{
			if (checkPos(22,11,6,game) && p[44]==0){
				p[44]=1;game->mp.play("trap");
				game->mapnow.floors[22]->setBlock(game,10,7,9704);
				game->mapnow.floors[11]->block[3][7]=new BlockFloor(3,7,11);
				game->refresh();
				game->article("./text/event14.txt");
			}
			if (checkPos(22,12,6,game)) teleport(21,1,6,3,game);
			if (checkPos(22,6,0,game)) teleport(23,6,11,0,game);
			if (checkPos(22,6,12,game)) teleport(24,6,1,2,game);	
			if (checkPos(22,0,6,game)) teleport(25,11,6,1,game);	
			if (getid(22,3,5,game)==0 && getid(22,3,7,game)==0 && p[45]==0){
				p[45]=1;game->mp.play("trap");
				game->mapnow.floors[22]->block[2][6]->animate(game);
				game->mapnow.floors[22]->block[2][6]=new BlockFloor(2,6,22);
			}
			break;
		}
		case 23:{
			if (checkPos(23,6,12,game)) teleport(22,6,1,2,game);
			break;
		}
		case 24:{
			if (checkPos(24,6,0,game)) teleport(22,6,11,0,game);
			break;
		}
		case 25:{
			if (checkPos(25,12,6,game)) teleport(22,1,6,3,game);
			if (checkPos(25,0,6,game)) teleport(26,10,6,1,game);		
			if (getid(25,5,2,game)==0 && getid(25,5,4,game)==0 && p[46]==0){
				p[46]=1;game->mp.play("trap");
				game->mapnow.floors[25]->block[4][3]->animate(game);
				game->mapnow.floors[25]->block[4][3]=new BlockFloor(4,3,25);
			}	
			if (getid(25,10,2,game)==0 && getid(25,10,4,game)==0 && p[47]==0){
				p[47]=1;game->mp.play("trap");
				game->mapnow.floors[25]->block[9][3]->animate(game);
				game->mapnow.floors[25]->block[9][3]=new BlockFloor(9,3,25);
			}	
			if (getid(25,5,8,game)==0 && getid(25,5,10,game)==0 && p[48]==0){
				p[48]=1;game->mp.play("trap");
				game->mapnow.floors[25]->block[4][9]->animate(game);
				game->mapnow.floors[25]->block[4][9]=new BlockFloor(4,9,25);
			}	
			if (getid(25,10,8,game)==0 && getid(25,10,10,game)==0 && p[49]==0){
				p[49]=1;game->mp.play("trap");
				game->mapnow.floors[25]->block[9][9]->animate(game);
				game->mapnow.floors[25]->block[9][9]=new BlockFloor(9,9,25);
			}
			break;
		}
		case 26:{
			if (checkPos(26,12,6,game)) teleport(25,1,6,3,game);
			if (checkPos(26,1,6,game)) teleport(27,2,6,3,game);
			if (getid(26,6,6,game)==0 && p[50]==0){
				p[50]=1;game->mp.play("trap");
				game->mapnow.floors[26]->block[2][6]->animate(game);
				game->mapnow.floors[26]->block[2][6]=new BlockFloor(2,6,26);
			}
			break;
		}
		case 27:{
			if (checkPos(27,1,6,game)) teleport(26,2,6,3,game);
			if (checkPos(27,10,6,game)) teleport(28,9,6,1,game);
			if (getid(27,5,4,game)==0 && getid(27,5,8,game)==0 &&
				getid(27,9,4,game)==0 && getid(27,9,8,game)==0 && p[51]==0){
				p[51]=1;game->mp.play("trap");
				game->mapnow.floors[27]->setBlock(game,12,6,1106);
			}
			break;
		}
		case 28:{
			if (checkPos(28,10,6,game)) teleport(27,9,6,1,game);
			if (checkPos(28,2,6,game)) teleport(29,1,6,1,game);
			break;
		}
		case 29:{
			if (checkPos(29,2,6,game)) teleport(28,3,6,3,game);
			if (checkPos(29,0,6,game)) teleport(30,11,6,1,game);
			break;
		}
		case 30:{
			if (checkPos(30,12,6,game)) teleport(29,1,6,3,game);
			if (checkPos(30,0,6,game)) teleport(31,11,6,1,game);
			break;
		}
		case 31:{
			if (checkPos(31,12,6,game)) teleport(30,1,6,3,game);
			if (checkPos(31,0,6,game)){
				game->mapnow.floors[0]->block[3][7]=new BlockFloor(3,7,0);
				game->mapnow.floors[0]->setBlock(game,3,6,9900);
				teleport(0,9,6,1,game);
			}
			if (getid(31,2,6,game)==0 && p[52]==0){
				p[52]=1;game->mp.play("trap");
				game->mapnow.floors[31]->block[1][6]->animate(game);
				game->mapnow.floors[31]->block[1][6]=new BlockFloor(1,6,31);
			}
			break;
		}
	}
}
