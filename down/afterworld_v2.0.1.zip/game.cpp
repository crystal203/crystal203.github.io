#include "game.h"
/* ��Ϸ������ʵ�� */
using namespace std;
void Game::refresh(){ // ��ͼ��ʾˢ��
	trig.work(this);
	cleardevice();
	/* ���� */
	if (gameEnd) cgList.draw(1,0,0);
	else cgList.draw(0,0,0);
	/* ��ͼ */
	if (visible==1 && !mbook) mapnow.floors[mapnow.floor]->draw(this);
	if (visible==0 && !gameEnd) uiList.draw(6,20,170);
	/* �����ֲ� */
	if (mbook){
		uiList.draw(5,20,170);
		mapnow.floors[mapnow.floor]->findMonster(this,1);
		int n=(mapnow.floors[mapnow.floor]->findMonster(this)-1)/6+1;
		string s=to_string(mpage+1)+"/"+to_string(n);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(s.c_str()),170+412-textwidth(s.c_str()),s);
	}
	/* ������ */
	if (tele){
		settextcolor(GREEN);
		setbkmode(TRANSPARENT);
		settextstyle(24*rate,0,font.c_str());
		drawText(20+412-32,170,"W/S �л�¥��");		
	}
	/* ���߲˵� */
	if (chooseWeapon || chooseAccessory || chooseTool){
		uiList.draw(5,20,170);
	}
	/* ���� */
	if (tele!=2 && visible==1 && !mbook && !chooseWeapon && !chooseAccessory && !chooseTool) player->drawPlayer(this);
	/* ״ֵ̬ */
	if (visible==1){
		uiList.draw(9,20,20);
		int atk=player->calcAtk();
		int def=player->calcDef();
		int hp=player->hp;
		int mag=player->calcMag();
		
		settextstyle(24*rate,0,font.c_str());
		settextcolor(WHITE);
		drawText(30,30,"������");
		drawText(60,30,"������");
		drawText(90,30,"������");
		drawText(120,30,"ħ����");
		drawText(280,30,"װ����");
		if (trig.p[32]==1){
			drawText(400,30,"��꣺");
		}
		player->weapon->drawWeapon(this,310,30);
		player->accessory->drawAccessory(this,310,100);
		settextstyle(24*rate,0,"Arial");
		if (player->poison) settextcolor(LIGHTGREEN);
		else settextcolor(LIGHTMAGENTA);
		int stnum=30+textwidth(_T("������"))/rate+5;
		drawText(30,stnum,to_string(hp));
		settextcolor(LIGHTRED);
		drawText(60,stnum,to_string(atk)+(player->weakness?"��":""));
		settextcolor(RGB(145,200,225));
		drawText(90,stnum,to_string(def)+(player->fragile?"��":""));
		settextcolor(LIGHTGREEN);
		drawText(120,stnum,to_string(mag));
		blockList.draw(4,150,30,0,1);
		blockList.draw(4,180,30,1,1);
		blockList.draw(4,210,30,2,1);
		blockList.draw(4,240,30,3,1);
		settextcolor(RGB(255,128,0));
		drawText(150,stnum,to_string(player->ykey));
		settextcolor(RGB(145,200,225));
		drawText(180,stnum,to_string(player->bkey));
		settextcolor(LIGHTRED);
		drawText(210,stnum,to_string(player->rkey));
		settextcolor(LIGHTGREEN);
		drawText(240,stnum,to_string(player->gkey));
		if (trig.p[32]==1){
			settextcolor(RGB(145,200,225));
			drawText(400,stnum,to_string(player->soul));
		}
	}
	/* �Ի��� */
	setbkmode(TRANSPARENT);
	settextcolor(BLACK);
	settextstyle(16*rate,0,font.c_str());
	drawText(460,170,info);
	if (dialog.visible){
		dialog.printDialog(this);
	}
	if (!chooseWeapon && !chooseAccessory && !chooseTool) FlushBatchDraw();	
}
void Game::article(string s){ // ����
	bool event0=(s=="./text/event1.txt");
	bool event1=(s=="./text/end.txt");
	ifstream txt(s);
	int n;txt>>n;bool fast=0;
	for (int i=1;i<=n;++i){
		if (event0 && i==5){
			visible=0;
			player->wBag.clear();
			player->wBag.push_back(new Weapon(0,0,0,0));
			player->weapon=player->wBag.back();
			player->aBag.clear();
			player->aBag.push_back(new Accessory(0,0,0,0));
			player->accessory=player->aBag.back();
			mp.play("lose");
		}
		if (event0 && i==3){
			mp.play("wrong");
			mapnow.floors[0]->block[3][6]=new BlockFloor(3,6,0);
			mapnow.floors[0]->block[3][7]=new Monster(3,7,0,1,MonAtk[1],MonDef[1],MonHp[1],MonSpc[1]);
		}
		if (event1 && i==7){
			visible=0;
			gameEnd=1;
			refresh();
		}
		int c,e=-1;string cn;
		txt>>c;if (c!=-1) txt>>e;
		getline(txt,cn);
		getline(txt,cn);
		dialog.showDialog(this,cn,c,e);
		while (!debug && !fast && !press(' ') && !press(VK_ESCAPE));
		if (press(VK_ESCAPE)) fast=1;
		while (press(' '));
	}
	visible=1;
	if (event0){
		mapnow.floor=player->nowf=1;
		player->nowx=10;
		player->nowy=6;
		player->atk=10;player->def=10;player->mag=player->lvl=0;
		player->hp=1000;
		refresh();
		takeScreenShot();
		save("./save/quicksave.sav");
	}
	dialog.hideDialog(this);
	txt.close();
}
void Game::takeScreenShot(int tp){ // ����
	if (tp==0) getimage(&screenshot,170*rate,20*rate,412*rate,412*rate);
	else{
		saveimage(("./screenshot/"+getTime(1)+".png").c_str());
		mp.play("item");
		info="�ѽ���";
	}
}
void Game::loadAsset(){ // ��ȡͼƬ��Դ
	/* UI ��ȡ */
	uiList.game=this;
	loadImage(&uiList,"./img/ui/dialogL.png",32,64,"./img/ui/dialogL_x.png");
	loadImage(&uiList,"./img/ui/dialogM.png",16,64,"./img/ui/dialogM_x.png");
	loadImage(&uiList,"./img/ui/dialogR.png",16,64,"./img/ui/dialogR_x.png");
	loadImage(&uiList,"./img/ui/frame.png",86,79,"./img/ui/frame_x.png");
	loadImage(&uiList,"./img/ui/dialogN.png",32,64,"./img/ui/dialogN_x.png");
	loadImage(&uiList,"./img/ui/book.png",416,416);
	loadImage(&uiList,"./img/ui/black.png",416,416);
	loadImage(&uiList,"./img/ui/choose.bmp",64,64);
	loadImage(&uiList,"./img/ui/unchoose.bmp",64,64);
	loadImage(&uiList,"./img/ui/sidebar.bmp",150,416);
	loadImage(&uiList,"./img/ui/score.bmp",250,250);
	/* �����ȡ */
	emotionList.game=this;
	loadImage(&emotionList,"./img/emotion/hana_normal.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_angry.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_climax.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_confused.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_curious.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_embarrassed.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_evasive.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_excited.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_glad.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_happy.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_hot.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_insidious.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_love.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_sad.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_scared.png",64,64);
	loadImage(&emotionList,"./img/emotion/hana_shocked.png",64,64);
	loadImage(&emotionList,"./img/emotion/chief.png",64,64);
	loadImage(&emotionList,"./img/emotion/yuna_normal.png",64,64);
	loadImage(&emotionList,"./img/emotion/yuna_smile.png",64,64);
	/* ��ɫ��ȡ */
	charList.game=this;
	loadImage(&charList,"./img/character/left.bmp",32,34,"./img/character/left_x.bmp");
	loadImage(&charList,"./img/character/back.bmp",32,34,"./img/character/back_x.bmp");
	loadImage(&charList,"./img/character/right.bmp",32,34,"./img/character/right_x.bmp");
	loadImage(&charList,"./img/character/front.bmp",32,33,"./img/character/front_x.bmp");
	loadImage(&charList,"./img/character/yuna_left.bmp",32,38,"./img/character/yuna_left_x.bmp");
	loadImage(&charList,"./img/character/yuna_right.bmp",32,38,"./img/character/yuna_right_x.bmp");
	/* �����ȡ */
	blockList.game=this;
	loadImage(&blockList,"./img/tier/floor.bmp",32,32,"",-1,32);
	loadImage(&blockList,"./img/tier/wall.bmp",128,32,"",-1,32);
	loadImage(&blockList,"./img/tier/gem.bmp",416,32,"./img/tier/gem_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/hp.bmp",128,32,"./img/tier/hp_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/key.bmp",128,32,"./img/tier/key_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/ydoor.bmp",128,32,"./img/tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/bdoor.bmp",128,32,"./img/tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/rdoor.bmp",128,32,"./img/tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/gdoor.bmp",128,32,"./img/tier/door_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/fdoor.bmp",128,32,"./img/tier/fdoor_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/idoor.bmp",128,32,"./img/tier/idoor_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/stair.bmp",224,32,"./img/tier/stair_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/button.bmp",64,32,"./img/tier/button_x.bmp",-1,32);
	loadImage(&blockList,"./img/tier/arrow.bmp",128,32,"./img/tier/arrow_x.bmp",-1,32);
	/* ���˶�ȡ */
	enemyList.game=this;
	loadImage(&enemyList,"./img/enemy/chief.bmp",64,39,"./img/enemy/chief_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/chief2.bmp",192,86,"./img/enemy/chief2_x.bmp",-1,96);
	loadImage(&enemyList,"./img/enemy/slime0.bmp",64,32,"./img/enemy/slime0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/slime1.bmp",64,32,"./img/enemy/slime1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/skeleton0.bmp",64,32,"./img/enemy/skeleton0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/guard0.bmp",64,32,"./img/enemy/guard0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/skeleton1.bmp",64,32,"./img/enemy/skeleton1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/bat0.bmp",64,32,"./img/enemy/bat0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/bat1.bmp",64,32,"./img/enemy/bat1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/mage0.bmp",64,32,"./img/enemy/mage0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/slime2.bmp",64,32,"./img/enemy/slime2_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/zombie0.bmp",64,32,"./img/enemy/zombie0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/skeleton2.bmp",64,32,"./img/enemy/skeleton2_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/stone.bmp",64,32,"./img/enemy/stone_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/zombie1.bmp",64,32,"./img/enemy/zombie1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/mage1.bmp",64,32,"./img/enemy/mage1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/guard1.bmp",64,32,"./img/enemy/guard1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/slime4.bmp",64,32,"./img/enemy/slime4_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/bat3.bmp",64,32,"./img/enemy/bat3_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/skeleton3.bmp",64,32,"./img/enemy/skeleton3_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/swordman.bmp",64,32,"./img/enemy/swordman_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/warrior0.bmp",64,32,"./img/enemy/warrior0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/warrior1.bmp",64,32,"./img/enemy/warrior1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/warrior2.bmp",64,32,"./img/enemy/warrior2_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/slime3.bmp",64,32,"./img/enemy/slime3_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/bat2.bmp",64,32,"./img/enemy/bat2_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/witch0.bmp",64,32,"./img/enemy/witch0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/witch1.bmp",64,32,"./img/enemy/witch1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/demon0.bmp",64,32,"./img/enemy/demon0_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/demon1.bmp",64,32,"./img/enemy/demon1_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/warrior3.bmp",64,32,"./img/enemy/warrior3_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/guard2.bmp",64,32,"./img/enemy/guard2_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/great.bmp",64,32,"./img/enemy/great_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/tower_red.bmp",64,58,"./img/enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/tower_blue.bmp",64,58,"./img/enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/tower_green.bmp",64,58,"./img/enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/tower_purple.bmp",64,58,"./img/enemy/tower_x.bmp",-1,32);
	loadImage(&enemyList,"./img/enemy/slime5.bmp",64,32,"./img/enemy/slime0_x.bmp",-1,32);
	/* CG ��ȡ */
	cgList.game=this;
	loadImage(&cgList,"./img/cg/cover.png",640,480);
	loadImage(&cgList,"./img/cg/final.png",640,480);
	/* ������ȡ */
	weaponList.game=this;
	loadImage(&weaponList,"./img/item/empty.bmp",64,64,"./img/item/empty_x.bmp");
	loadImage(&weaponList,"./img/item/weapon1.bmp",64,64,"./img/item/weapon_x.bmp");
	loadImage(&weaponList,"./img/item/weapon2.bmp",64,64,"./img/item/weapon_x.bmp");
	loadImage(&weaponList,"./img/item/weapon3.bmp",64,64,"./img/item/weapon_x.bmp");
	loadImage(&weaponList,"./img/item/weapon4.bmp",64,64,"./img/item/weapon4_x.bmp");
	loadImage(&weaponList,"./img/item/weapon5.bmp",64,64,"./img/item/weapon5_x.bmp");
	/* ��Ʒ��ȡ */
	accessoryList.game=this;
	loadImage(&accessoryList,"./img/item/empty.bmp",64,64,"./img/item/empty_x.bmp");
	loadImage(&accessoryList,"./img/item/accessory1.bmp",64,64,"./img/item/accessory1_x.bmp");
	loadImage(&accessoryList,"./img/item/accessory2.bmp",64,64,"./img/item/accessory2_x.bmp");
	loadImage(&accessoryList,"./img/item/accessory3.bmp",64,64,"./img/item/accessory3_x.bmp");
	loadImage(&accessoryList,"./img/item/accessory4.bmp",64,64,"./img/item/accessory4_x.bmp");
	loadImage(&accessoryList,"./img/item/accessory5.bmp",64,64,"./img/item/accessory5_x.bmp");
	/* ���߶�ȡ */
	toolList.game=this;
	loadImage(&toolList,"./img/item/pickaxe.bmp",64,64,"./img/item/pickaxe_x.bmp");
	loadImage(&toolList,"./img/item/coin.bmp",64,64,"./img/item/coin_x.bmp");
	loadImage(&toolList,"./img/item/saint.bmp",64,64,"./img/item/saint_x.bmp");
	loadImage(&toolList,"./img/item/metal_red.bmp",64,64,"./img/item/metal_x.bmp");
	loadImage(&toolList,"./img/item/metal_blue.bmp",64,64,"./img/item/metal_x.bmp");
	loadImage(&toolList,"./img/item/potion.bmp",64,64,"./img/item/potion_x.bmp");
	loadImage(&toolList,"./img/item/immune.bmp",64,64,"./img/item/immune_x.bmp");
	/* �������ȡ */
	itemList.game=this;
	loadImage(&itemList,"./img/item/empty.bmp",32,32,"./img/item/empty_x.bmp");
	loadImage(&itemList,"./img/item/weapon1.bmp",32,32,"./img/item/weapon_x.bmp");
	loadImage(&itemList,"./img/item/weapon2.bmp",32,32,"./img/item/weapon_x.bmp");
	loadImage(&itemList,"./img/item/weapon3.bmp",32,32,"./img/item/weapon_x.bmp");
	loadImage(&itemList,"./img/item/weapon4.bmp",32,32,"./img/item/weapon4_x.bmp");
	loadImage(&itemList,"./img/item/weapon5.bmp",32,32,"./img/item/weapon5_x.bmp");
	loadImage(&itemList,"./img/item/accessory1.bmp",32,32,"./img/item/accessory1_x.bmp");
	loadImage(&itemList,"./img/item/accessory2.bmp",32,32,"./img/item/accessory2_x.bmp");
	loadImage(&itemList,"./img/item/accessory3.bmp",32,32,"./img/item/accessory3_x.bmp");
	loadImage(&itemList,"./img/item/accessory4.bmp",32,32,"./img/item/accessory4_x.bmp");
	loadImage(&itemList,"./img/item/accessory5.bmp",32,32,"./img/item/accessory5_x.bmp");
	loadImage(&itemList,"./img/item/saint.bmp",32,32,"./img/item/saint_x.bmp");
	loadImage(&itemList,"./img/item/pickaxe.bmp",32,32,"./img/item/pickaxe_x.bmp");
	loadImage(&itemList,"./img/item/coin.bmp",32,32,"./img/item/coin_x.bmp");
	loadImage(&itemList,"./img/item/metal_red.bmp",32,32,"./img/item/metal_x.bmp");
	loadImage(&itemList,"./img/item/metal_blue.bmp",32,32,"./img/item/metal_x.bmp");
	loadImage(&itemList,"./img/item/potion.bmp",32,32,"./img/item/potion_x.bmp");
	loadImage(&itemList,"./img/item/immune.bmp",32,32,"./img/item/immune_x.bmp");
}
int Game::calcDamage(Player* player,Monster* enemy,int assume){ // �����˺�
	int atk=assume==-1?player->calcAtk():assume;
	int imp=10000000;
	if ((enemy->spc>>9)&1) return (player->hp-1)*(player->immune?0.1:1);
	int me_to_enemy=atk-enemy->def;
	if (me_to_enemy>1 && ((enemy->spc>>0)&1)) me_to_enemy=1;
	if (me_to_enemy<=0) return imp;
	int enemy_to_me=enemy->atk-player->calcDef();
	if ((enemy->spc>>1)&1) enemy_to_me=enemy->atk;
	if (enemy_to_me<=0) return 0;
	int turn=(enemy->hp-1)/me_to_enemy;
	if ((enemy->spc>>2)&1) turn*=2;
	if ((enemy->spc>>3)&1) turn*=4;
	int dmg=turn*enemy_to_me-player->calcMag();
	if (dmg<0) dmg=0;
	return dmg;
}
int Game::calcNextAtk(Player* player,Monster* enemy){ // �����ٽ�ֵ
	int org=Game::calcDamage(player,enemy);
	if (org==0) return 0;
	int imp=10000000,l=player->calcAtk(),r=imp,ans=imp;
	while (l<=r){
		int mid=(l+r)/2;
		if (Game::calcDamage(player,enemy,mid)<org){
			ans=mid;r=mid-1;
		}else l=mid+1;
	}
	if (ans==imp) return imp;
	else return ans-player->calcAtk();
}
string getrar(string s){ // �ַ���ȥ�ո�
	if (s=="") return "_";
	for (int i=0;i<(int)s.size();++i){
		if (s[i]==' ') s[i]='_';
	}
	return s;
}
string derar(string s){ // �ַ�����ԭ�ո�
	if (s=="_") return "";
	for (int i=0;i<(int)s.size();++i){
		if (s[i]=='_') s[i]=' ';
	}
	return s;
}
string Game::getTime(int tp){ // ��ȡʱ��
	time_t now=time(0);
	tm *ltm=localtime(&now);
	string res;
	if (tp==0){
		res=to_string(1900+ltm->tm_year)+"/"+to_string(1+ltm->tm_mon)+"/"+to_string(ltm->tm_mday)+"-"+
				   to_string(ltm->tm_hour)+":"+to_string(ltm->tm_min)+":"+to_string(ltm->tm_sec);		
	}else{
		res=to_string(1900+ltm->tm_year)+"-"+to_string(1+ltm->tm_mon)+"-"+to_string(ltm->tm_mday)+"-"+
				   to_string(ltm->tm_hour)+"-"+to_string(ltm->tm_min)+"-"+to_string(ltm->tm_sec);		
	}
	return res;
}
int getmax(int x,int y){
	return x>y?x:y;
}
int getmin(int x,int y){
	return x<y?x:y;
}
void Game::workTool(){ // ���߲˵�
	/* ץȡ���еĵ����嵥 */
	vector <string> txt;txt.clear();
	vector <int> tid;tid.clear();
	vector <int> num;num.clear();
	vector <string> name;name.clear();
	if (player->pickaxe){
		txt.push_back("�� 1 �Ƴ���ǰ��һ��ǽ");
		tid.push_back(0);
		num.push_back(player->pickaxe);
		name.push_back("��ǽ��");
	}
	if (player->gold){
		txt.push_back("��ʼ�տ��Ի��˫�������");
		tid.push_back(1);
		num.push_back(-1);
		name.push_back("�����");
	}
	if (player->saint){
		txt.push_back("�� 5 ʹ�������ֵ����");
		tid.push_back(2);
		num.push_back(player->saint);
		name.push_back("ʥˮ");
	}
	if (player->metal){
		txt.push_back("�� 2 ���������������");
		tid.push_back(3);
		num.push_back(player->metal);
		name.push_back("ħ������");
	}
	if (player->crystal){
		txt.push_back("�� 3 �������������Ʒ");
		tid.push_back(4);
		num.push_back(player->crystal);
		name.push_back("ħ��ˮ��");
	}
	if (player->potion){
		txt.push_back("�� 4 ������и���Ч��");
		tid.push_back(5);
		num.push_back(player->potion);
		name.push_back("���ܽ�ҩ");		
	}
	if (player->immune){
		txt.push_back("���мл�/����/�綾�˺�����90%");
		tid.push_back(6);
		num.push_back(-1);
		name.push_back("�������");		
	}
	if (tid.empty()){
		info="��û���κε���";
		return;
	}
	/* ���߲˵� UI */
	int nsave=tid.size();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		refresh();
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			if (i==msave) uiList.draw(7,xpos,ypos);
			toolList.draw(tid[i],xpos,ypos,-1,1);
			settextstyle(16*rate,0,font.c_str());
			settextcolor(WHITE);
			setbkmode(TRANSPARENT);
			int h=textheight(_T("����"));
			drawText(xpos,ypos+110,name[i]+(num[i]!=-1?" ("+to_string(num[i])+")":""));
			drawText(xpos+h,ypos+110,txt[i]);
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;
				break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);
				break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE) || press('T')) break;
		}
		if (press(VK_ESCAPE) || press(' ') || press('T')) return;
	}	
}
void Game::workWeapon(){ // �����˵�
	int nsave=player->wBag.size();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		refresh();
		for (int i=0;i<nsave;++i){
			if (player->wBag[i]==player->weapon) msave=i,mpage=i/5;
		}
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			player->wBag[i]->drawWeapon(this,xpos,ypos,1);
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE) || press('Q')) break;
		}
		mp.play("equip");
		player->weapon=player->wBag[msave];
		if (press(VK_ESCAPE) || press(' ') || press('Q')) return;
	}	
}
void Game::workAccessory(){ // ��Ʒ�˵�
	int nsave=player->aBag.size();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		refresh();
		for (int i=0;i<nsave;++i){
			if (player->aBag[i]==player->accessory) msave=i,mpage=i/5;
		}
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			player->aBag[i]->drawAccessory(this,xpos,ypos,1);
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE) || press('E')) break;
		}
		mp.play("equip");
		player->accessory=player->aBag[msave];
		if (press(VK_ESCAPE) || press(' ') || press('E')) return;
	}	
}
void Game::workSave(){ // �浵�˵�
	takeScreenShot();
	/* ץȡ���д浵 */
	ifstream all("./save/savelist.ini");
	int nsave;all>>nsave;
	vector <string> saves;saves.resize(nsave);
	vector <string> times;times.resize(nsave);
	for (int i=0;i<nsave;++i){
		all>>saves[i];
		ifstream cur(saves[i]);
		cur>>times[i];
		cur.close();
	}
	saves[0]="./save/save"+to_string(nsave)+".sav";
	times[0]="?/?/?-??:??:??";
	all.close();
	/* �浵 UI */
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		cleardevice();
		cgList.draw(0,0,0);
		uiList.draw(5,20,170);
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			if (msave==i) uiList.draw(7,xpos,ypos);
			else uiList.draw(8,xpos,ypos);
			IMAGE tmp;
			if (i!=0){
				loadimage(&tmp,(saves[i]+".png").c_str(),60*rate,60*rate);
				putimage((ypos+2)*rate,(xpos+2)*rate,&tmp);				
			}
			settextstyle(24*rate,0,font.c_str());
			settextcolor(WHITE);
			setbkmode(TRANSPARENT);
			int h=textheight(_T("����"));
			drawText(xpos,ypos+110,times[i]);
			if (i==0){
				settextcolor(LIGHTGREEN);
				drawText(xpos+h,ypos+110,"�½��浵");
			}
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE)) break;
		}
		if (press(VK_ESCAPE)) return;
		if (press(' ')){
			ofstream all("./save/savelist.ini");
			all<<nsave+(msave==0)<<endl;
			all<<"./save/quicksave.sav"<<endl;
			for (int i=(msave!=0);i<nsave;++i){
				all<<saves[i]<<endl;
			}
			all.close();
			save(saves[msave]);
			return;
		}
	}	
}
void Game::workLoad(){ // �����˵�
	ifstream all("./save/savelist.ini");
	int nsave;all>>nsave;
	vector <string> saves;saves.resize(nsave);
	vector <string> times;times.resize(nsave);
	for (int i=0;i<nsave;++i){
		all>>saves[i];
		ifstream cur(saves[i]);
		cur>>times[i];
		cur.close();
	}
	all.close();
	int npage=(nsave-1)/5+1,mpage=0,msave=0;
	while (1){
		cleardevice();
		cgList.draw(0,0,0);
		uiList.draw(5,20,170);
		for (int i=mpage*5;i<getmin(nsave,(mpage+1)*5);++i){
			int cur=i-mpage*5,xpos=cur*76+48,ypos=202;
			if (msave==i) uiList.draw(7,xpos,ypos);
			else uiList.draw(8,xpos,ypos);
			IMAGE tmp;
			loadimage(&tmp,(saves[i]+".png").c_str(),60*rate,60*rate);
			putimage((ypos+2)*rate,(xpos+2)*rate,&tmp);
			settextstyle(24*rate,0,font.c_str());
			settextcolor(WHITE);
			setbkmode(TRANSPARENT);
			int h=textheight(_T("����"));
			drawText(xpos,ypos+110,times[i]);
			if (i==0){
				settextcolor(LIGHTGREEN);
				drawText(xpos+h,ypos+110,"��ȡ���ٴ浵");
			}
		}
		string spage=to_string(mpage+1)+"/"+to_string(npage);
		settextstyle(16*rate,0,"Arial");
		settextcolor(WHITE);
		drawText(20+412-textheight(spage.c_str()),170+412-textwidth(spage.c_str()),spage);
		
		FlushBatchDraw();
		while (press('A') || press('D') || press('W') || press('S') || press(VK_UP) || press(VK_DOWN) || press(VK_LEFT) || press(VK_RIGHT));
		while (1){
			if (press('A') || press(VK_LEFT)){
				if (mpage>0) mpage--,msave-=5;break;
			}
			if (press('D') || press(VK_RIGHT)){
				if (mpage<npage-1) mpage++,msave=min(msave+5,nsave-1);break;
			}
			if (press('W') || press(VK_UP)){
				if (msave>0){
					msave--;
					if (msave%5==4) mpage--;
				}
				break;
			}
			if (press('S') || press(VK_DOWN)){
				if (msave<nsave-1){
					msave++;
					if (msave%5==0) mpage++;
				}
				break;
			}
			if (press(' ') || press(VK_ESCAPE)) break;
		}
		if (press(VK_ESCAPE)) return;
		if (press(' ')){
			load(saves[msave]);
			return;
		}
	}	
}
int Game::load(string s){ // �����ľ���ʵ��
	mapnow.loadMap(this);
	ifstream dat(s);
	if (!dat.is_open()){
		cerr<<"Load Failed"<<endl;
		return 0;
	}
	string times;dat>>times;
	int ver;dat>>ver;
	dat>>player->atk>>player->def>>player->hp>>player->mag;
	dat>>player->lvl>>player->star;
	dat>>player->nowf>>player->nowx>>player->nowy>>player->dir;
	dat>>player->ykey>>player->bkey>>player->rkey>>player->gkey;
	dat>>player->metal>>player->crystal>>player->upgrade;
	if (ver>=5) dat>>player->soul>>shopCost; else player->soul=0,shopCost=1;
	if (ver>=6) dat>>player->gold>>player->pickaxe; else player->gold=player->pickaxe=0;
	if (ver>=7) dat>>player->saint; else player->saint=0;
	if (ver>=8) dat>>player->poison>>player->weakness>>player->fragile; else player->poison=player->weakness=player->fragile=0;
	if (ver>=9) dat>>player->potion>>player->immune; else player->potion=player->immune=0;
		int wsize,asize,w,a;
		dat>>wsize;player->wBag.clear();player->wBag.resize(wsize);
		for (int i=0;i<wsize;++i){
			int id,atk,def,mag,lvl;string name;
			dat>>id>>name>>atk>>def>>mag>>lvl;name=derar(name);
			player->wBag[i]=new Weapon(id,atk,def,mag,name,lvl);
		}
		dat>>w;player->weapon=player->wBag[w];
		dat>>asize;player->aBag.clear();player->aBag.resize(asize);
		for (int i=0;i<asize;++i){
			int id,atk,def,mag,lvl;string name;
			dat>>id>>name>>atk>>def>>mag>>lvl;name=derar(name);
			player->aBag[i]=new Accessory(id,atk,def,mag,name,lvl);
		}	
		dat>>a;player->accessory=player->aBag[a];
	/*map*/
	int fsize;dat>>fsize;
	dat>>mapnow.floor;
	for (int i=0;i<fsize;++i){
		dat>>mapnow.floors[i]->explored;
		for (int j=0;j<13;++j){
			for (int k=0;k<13;++k){
				int id;dat>>id;
				mapnow.floors[i]->setBlock(this,j,k,id);
			}
		}
	}
	/*event*/
	int esize;dat>>esize;
	for (int i=0;i<esize;++i) dat>>trig.p[i];
	dat.close();
	mp.play("floor");
	info="�ɹ�����";
	return 1;
}
void Game::save(string s){ // �浵�ľ���ʵ��
	ofstream dat(s);
	dat<<getTime()<<endl;
	int ver=9;
	dat<<ver<<endl;;
	/*player*/
	dat<<player->atk<<" "<<player->def<<" "<<player->hp<<" "<<player->mag<<endl;
	dat<<player->lvl<<" "<<player->star<<endl;
	dat<<player->nowf<<" "<<player->nowx<<" "<<player->nowy<<" "<<player->dir<<endl;
	dat<<player->ykey<<" "<<player->bkey<<" "<<player->rkey<<" "<<player->gkey<<endl;
	dat<<player->metal<<" "<<player->crystal<<" "<<player->upgrade<<endl;
	dat<<player->soul<<" "<<shopCost<<endl;
	dat<<player->gold<<" "<<player->pickaxe<<endl;
	dat<<player->saint<<endl;
	dat<<player->poison<<" "<<player->weakness<<" "<<player->fragile<<endl;
	dat<<player->potion<<" "<<player->immune<<endl;
		/*weapon*/
		int wsize=player->wBag.size(),w=0,a=0;
		dat<<wsize<<endl;
		for (int i=0;i<wsize;++i){
			dat<<player->wBag[i]->id<<" "<<getrar(player->wBag[i]->name)<<" "<<player->wBag[i]->atk<<" "<<player->wBag[i]->def<<" "<<player->wBag[i]->mag<<" "<<player->wBag[i]->lvl<<endl;
			if (player->wBag[i]==player->weapon) w=i;
		}
		dat<<w<<endl;
		int asize=player->aBag.size();
		dat<<asize<<endl;
		for (int i=0;i<asize;++i){
			dat<<player->aBag[i]->id<<" "<<getrar(player->aBag[i]->name)<<" "<<player->aBag[i]->atk<<" "<<player->aBag[i]->def<<" "<<player->aBag[i]->mag<<" "<<player->aBag[i]->lvl<<endl;
			if (player->aBag[i]==player->accessory) a=i;
		}	
		dat<<a<<endl;
	/*map*/
	int fsize=mapnow.floors.size();
	dat<<fsize<<endl;
	dat<<mapnow.floor<<endl;
	for (int i=0;i<fsize;++i){
		dat<<mapnow.floors[i]->explored<<endl;
		for (int j=0;j<13;++j){
			for (int k=0;k<13;++k){
				dat<<mapnow.floors[i]->block[j][k]->getid()<<" ";
			}
			dat<<endl;
		}
	}
	/*event*/
	int esize=trig.p.size();
	dat<<esize<<endl;
	for (int i=0;i<esize;++i) dat<<trig.p[i]<<" ";
	dat<<endl;
	dat.close();
	saveimage((s+".png").c_str(),&screenshot);
	mp.play("floor");
	info="�Ѵ浵";
}
bool Game::canUseTele(){ // �жϴ������Ƿ񱻽���
	if (trig.p[6]==1 && trig.p[7]==0) return 0;
	if (trig.p[35]==1 && trig.p[36]==0) return 0;
	if (trig.p[40]==1 && trig.p[41]==0) return 0;
	return 1;
}
void Game::calcScore(){ // ��Ϸ��������
	settextstyle(16*rate,0,font.c_str());
	settextcolor(BLACK);
	setbkmode(TRANSPARENT);
	cleardevice();
	cgList.draw(1,0,0);
	int xpos=240-125,ypos=320-125;
	uiList.draw(10,xpos,ypos);
	string diff="����";
	if (player->gkey==1) diff="��";
	if (player->gkey==2) diff="��ͨ";
	drawText(xpos+20,ypos+20,"�Ѷȣ�"+diff);
	string dat=to_string(player->hp);
	drawText(xpos+50,ypos+20,"������"+dat);
	dat=to_string(player->calcAtk())+"/"+to_string(player->calcDef())+"/"+to_string(player->calcMag());
	drawText(xpos+80,ypos+20,"��/��/ħ��"+dat);
	string key=to_string(player->ykey)+"/"+to_string(player->bkey)+"/"+to_string(player->rkey);
	drawText(xpos+110,ypos+20,"Կ�� ��/��/�죺"+key);
	string ending="NE";
	drawText(xpos+140,ypos+20,"��֣�"+ending);
	string version="Beta v1.0";
	drawText(xpos+170,ypos+20,"�汾��"+version);
	FlushBatchDraw();
	while (1);
}
void Game::init(int mode){ // ��Ϸ��ֵ����
	loadAsset();
	player=new Player();player->dir=1;
	player->wBag.push_back(new Weapon(5,160,40,250,"���ƽ���"));
	player->aBag.push_back(new Accessory(5,40,160,250,"��ѩŮ��ָ��"));
	player->weapon=player->wBag.back();
	player->accessory=player->aBag.back();
	trig.init();
	visible=0;
	gameEnd=0;
	debug=0;
	BeginBatchDraw();setbkcolor(WHITE);
	mapnow.loadMap(this,0);
	if (mode==1){
		visible=2;
		article("./text/start.txt");
		visible=1;
	}else{
		visible=1;
		workLoad();
	}
}
void dpress(char c,int tp=0){ // �жϰ����Ƿ�̧��
	int st=clock();
	while ((tp==0 || 1.0*(clock()-st)/CLOCKS_PER_SEC<0.15) && press(c));
}
void Game::monsterBook(Game *game){ // ����ͼ���˵�
	if (press('X') && press(VK_CONTROL)){
		showTag=!showTag;
		refresh();
		dpress('X');dpress(VK_CONTROL);
		return;
	}
	if (press('X')){
		mbook=1;
		int n=(mapnow.floors[mapnow.floor]->findMonster(game)-1)/6+1;mpage=0;
		info="����˹����ֲᡣ�� X/ESC/�ո� ����";
		refresh();
		dpress('X');
		while (!press('X') && !press(VK_ESCAPE) && !press(' ')){
			if ((press('A') || press(VK_LEFT)) && mpage>0){
				mpage--;refresh();dpress('A');dpress(VK_LEFT);
			}
			if ((press('D') || press(VK_RIGHT)) && mpage<n-1){
				mpage++;refresh();dpress('D');dpress(VK_RIGHT);
			}
		}
		mbook=0;
		info="";
		refresh();
		dpress('X');dpress(VK_ESCAPE);dpress(' ');
	}
}
void Game::run(){ // ��Ϸ����
	int st=clock();
	refresh();
	while (1){
		mapnow.floors[mapnow.floor]->explored=1;
		if (press(VK_CONTROL) && press('Z')){
			load("./save/quicksave.sav");
			refresh();
			dpress(VK_CONTROL);dpress('Z');
		}
		if (press(VK_CONTROL) && press('S')){
			workSave();
			refresh();
			dpress(VK_CONTROL);dpress('S');
		}
		if (press(VK_CONTROL) && press('L')){
			workLoad();
			refresh();
			dpress(VK_CONTROL);dpress('L');
		}
		if (press(VK_CONTROL) && press('A')){
			takeScreenShot(1);
			refresh();
			dpress(VK_CONTROL);dpress('A');	
		}
		if (!mbook && !press(VK_CONTROL)){ // ����˶��ٿ�
			char c[4]={'A','W','D','S'};
			char cc[4]={VK_LEFT,VK_UP,VK_RIGHT,VK_DOWN};
			int dx[4]={0,-1,0,1};
			int dy[4]={-1,0,1,0};
			for (int i=0;i<4;++i){
				if (!press(c[i]) && !press(cc[i])) continue;
				if (mapnow.floors[mapnow.floor]->block[player->nowx][player->nowy]->id==13 && 
					mapnow.floors[mapnow.floor]->block[player->nowx][player->nowy]->tp!=i) continue;
				info="";
				int newx=player->nowx+dx[i];
				int newy=player->nowy+dy[i];
				bool flag=1;
				if (newx>=0 && newx<=12 && newy>=0 && newy<=12){
					int sta=mapnow.floors[mapnow.floor]->block[newx][newy]->encounter(this);
					if (sta==1){
						player->nowx=newx;
						player->nowy=newy;
						mapnow.floors[mapnow.floor]->calcPinch(this);
						int dmg=mapnow.floors[mapnow.floor]->block[newx][newy]->dmg;
						if (player->poison) dmg+=10;
						if (player->immune) dmg*=0.1;
						player->hp-=dmg;
						if (dmg!=0) info="���ܵ��˼л�/����/�綾�˺�"+to_string(dmg)+"��",mp.play("zone");
						if (player->hp<0){
							visible=0;
							mp.play("lose");
							dialog.showDialog(this,"�����ˡ����ո��ȡ���ٴ浵");
							while (!press(' '));
							dialog.hideDialog(this);
							while (press(' '));
							visible=1;flag=0;
							load("./save/quicksave.sav");
							refresh();
						}
					}
				}
				if (flag){
					player->dir=i;
					refresh();
				}
				dpress(c[i],1);dpress(cc[i],1);			
			}			
		}
		if (press('G')){ // ������
			if (press(VK_CONTROL)) tele=2;
			else tele=0;
			if (tele==2 || mapnow.floors[mapnow.floor]->canTele){
				if (tele==2 || canUseTele()){
					vector <int> cand;int now=0;
					for (int i=0;i<(int)mapnow.floors.size();++i){
						if (tele==2 || (mapnow.floors[i]->canTele && mapnow.floors[i]->explored)){
							cand.push_back(i);
							if (i==mapnow.floor){
								now=cand.size()-1;
							}
						}
					}
					int n=cand.size();
					int tmpf=mapnow.floor,tmpx=player->nowx,tmpy=player->nowy;
					if (tele==2){
						info="�����ͼ���� ESC/G/�ո� ȡ��";
						player->nowx=player->nowy=-1;
					}else info="�� ESC/G ȡ�����ո� ��ʼ���ͣ�",tele=1;
					refresh();
					dpress('G');
					while (1){
						if (press('W') || press(VK_UP) || press('S') || press(VK_DOWN)){
							if (press('W') || press(VK_UP)){
								if (now>=n-1) continue;
								now++;
							}
							if (press('S') || press(VK_DOWN)){
								if (now<=0) continue;
								now--;
							}
							mapnow.floor=player->nowf=cand[now];
							if (tele==1){
								player->nowx=mapnow.floors[cand[now]]->spx;
								player->nowy=mapnow.floors[cand[now]]->spy;								
							}
							refresh();
							dpress('W');dpress(VK_UP);dpress('S');dpress(VK_DOWN);
						}
						if (press('G') || press(VK_ESCAPE) || press(' ')) break;
						monsterBook(this);
					}
					if (press('G') || press(VK_ESCAPE) || (tele==2 && press(' '))){
						player->nowf=mapnow.floor=tmpf;
						player->nowx=tmpx;
						player->nowy=tmpy;
						refresh();
					}
					mp.play("floor");
					tele=0;
				}else{
					info="����ʱ�޷�ʹ�ô�����";
					mp.play("wrong");
					refresh();					
				}
			}else{
				info="�����޷�ʹ�ô�����";
				mp.play("wrong");
				refresh();
			}
			dpress('G');dpress(VK_ESCAPE);dpress(' ');dpress(VK_CONTROL);
		}
		monsterBook(this);
		if (press('1') && player->pickaxe){
			int dx[4]={0,-1,0,1};
			int dy[4]={-1,0,1,0};
			int newx=player->nowx+dx[player->dir];
			int newy=player->nowy+dy[player->dir];
			if (newx<0 || newy<0 || newx>12 || newy>12) continue;
			if (mapnow.floors[mapnow.floor]->block[newx][newy]->id==1 && 
				mapnow.floors[mapnow.floor]->block[newx][newy]->tp==0 || mapnow.floors[mapnow.floor]->block[newx][newy]->tp==3){
				player->pickaxe--;
				mapnow.floors[mapnow.floor]->block[newx][newy]=new BlockFloor(newx,newy,mapnow.floor);
				mp.play("pickaxe");
				info="��ʹ���˸���";
			}
			refresh();
			dpress('1');
		}
		if (press('2') && player->metal){
			if (player->weapon->id!=5){
				info="��װ����������";
				mp.play("wrong");
			}else{
				player->metal--;
				player->weapon->lvl++;
				player->weapon->calc();
				mp.play("equip");
				info="��������õ���ǿ��";
			}
			refresh();
			dpress('2');
		}
		if (press('3') && player->crystal){
			if (player->accessory->id!=5){
				info="��װ��������Ʒ";
				mp.play("wrong");
			}else{
				player->crystal--;
				player->accessory->lvl++;
				player->accessory->calc();
				mp.play("equip");
				info="�����Ʒ�õ���ǿ��";
			}
			refresh();
			dpress('3');
		}
		if (press('4') && player->potion){
			player->poison=player->fragile=player->weakness=0;
			mp.play("equip");
			info="��������и���Ч��";
			player->potion--;
			refresh();
			dpress('4');
		}
		if (press('5') && player->saint){
			player->saint--;player->hp*=2;
			mp.play("equip");
			info="��ʹ����ʥˮ";
			refresh();
			dpress('5');
		}
		if (press('V') && trig.p[32]){
			if (trig.p[44]) mapnow.floors[22]->block[10][7]->encounter(this);
			else mapnow.floors[11]->block[3][7]->encounter(this);
			dpress('V');
		}
		if (press('Z') && !press(VK_CONTROL)){
			player->dir=(player->dir+1)%4;
			refresh();
			dpress('Z');
		}
		if (press('P') && press(VK_CONTROL)){
			pause=1;info="����ͣ���� Ctrl-P ���";
			refresh();
			dpress('P');dpress(VK_CONTROL);
			while (!press('P') && !press(VK_CONTROL));
			pause=0;info="";
			refresh();
			dpress('P');
		}
		if (press('Q') && !mbook){
			chooseWeapon=1;
			info="W/S �� ����� ѡ���������� Q/ESC/�ո� ����";
			dpress('Q');
			workWeapon();
			chooseWeapon=0;
			refresh();
			dpress('Q');
		}
		if (press('E') && !mbook){
			chooseAccessory=1;
			info="W/S �� ����� ѡ����Ʒ���� E/ESC/�ո� ����";
			dpress('E');
			workAccessory();
			chooseAccessory=0;
			refresh();
			dpress('E');
		}
		if (press('T') && !mbook){
			chooseTool=1;
			info="W/S �� ����� �鿴���ߣ��� T/ESC/�ո� ����";
			dpress('T');
			workTool();
			chooseTool=0;
			refresh();
			dpress('T');
		}
		if (1.0*(clock()-st)/CLOCKS_PER_SEC>0.3){
			st=clock();
			mapnow.floors[mapnow.floor]->doAnimate(this);
			refresh();
		}
	}
	EndBatchDraw();
}
