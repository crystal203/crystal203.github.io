#include "game.h"
using namespace std;
void Player::drawPlayer(Game *game){
	game->charList.drawBlock(dir,nowx,nowy);
}
void Weapon::calc(){ 
	int natk[6]={160,180,200,220,240,280};
	int ndef[6]={40,45,50,55,60,70};
	int nmag[6]={250,280,320,370,430,500};
	atk=natk[lvl];
	def=ndef[lvl];
	mag=nmag[lvl];
}
void Weapon::drawWeapon(Game *game,int xpos,int ypos,int tp){ // ��������
	if (tp==1){
		if (this==game->player->weapon) game->uiList.draw(7,xpos,ypos);
		game->weaponList.draw(id,xpos,ypos,-1,1);
		settextstyle(16*game->rate,0,game->font.c_str());
		settextcolor(WHITE);
		setbkmode(TRANSPARENT);
		int h=textheight(_T("����"));
		game->drawText(xpos+2*h,ypos+110,name+(lvl>0?(" +"+to_string(lvl)):""));
		game->drawText(xpos,ypos+110,"����");
		game->drawText(xpos+h,ypos+110,"����");
		game->drawText(xpos+h,ypos+220,"ħ��");
		settextstyle(14*game->rate,0,"Arial");
		LOGFONT f;gettextstyle(&f);f.lfWeight=900;settextstyle(&f);
		settextcolor(LIGHTRED);
		game->drawText(xpos,ypos+155,to_string(atk));
		settextcolor(RGB(145,199,215));
		game->drawText(xpos+h,ypos+155,to_string(def));
		settextcolor(LIGHTGREEN);
		game->drawText(xpos+h,ypos+265,to_string(mag));
		gettextstyle(&f);f.lfWeight=0;settextstyle(&f);
	}else{
		game->weaponList.draw(id,xpos,ypos,-1,1);
	}
}
void Accessory::calc(){
	int ndef[6]={160,180,200,220,240,280};
	int natk[6]={40,45,50,55,60,70};
	int nmag[6]={250,280,320,370,430,500};
	atk=natk[lvl];
	def=ndef[lvl];
	mag=nmag[lvl];
}
void Accessory::drawAccessory(Game *game,int xpos,int ypos,int tp){ // ������Ʒ
	if (tp==1){
		if (this==game->player->accessory) game->uiList.draw(7,xpos,ypos);
		game->accessoryList.draw(id,xpos,ypos,-1,1);
		settextstyle(16*game->rate,0,game->font.c_str());
		settextcolor(WHITE);
		setbkmode(TRANSPARENT);
		int h=textheight(_T("����"));
		game->drawText(xpos+2*h,ypos+110,name+(lvl>0?(" +"+to_string(lvl)):""));
		game->drawText(xpos,ypos+110,"����");
		game->drawText(xpos+h,ypos+110,"����");
		game->drawText(xpos+h,ypos+220,"ħ��");
		settextstyle(14*game->rate,0,"Arial");
		LOGFONT f;gettextstyle(&f);f.lfWeight=900;settextstyle(&f);
		settextcolor(LIGHTRED);
		game->drawText(xpos,ypos+155,to_string(atk));
		settextcolor(RGB(145,199,215));
		game->drawText(xpos+h,ypos+155,to_string(def));
		settextcolor(LIGHTGREEN);
		game->drawText(xpos+h,ypos+265,to_string(mag));
		gettextstyle(&f);f.lfWeight=0;settextstyle(&f);
	}else{
		game->accessoryList.draw(id,xpos,ypos,-1,1);
	}
}